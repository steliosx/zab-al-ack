# Review — Zab-al-ack 0.1.0a13 (2026-09-12)

Input: `zabalack-0.1.0a12-reviewed-complete.zip` (SHA-256
`5010bb5e7d752e1ec08dacdcacb4dd3d5e2029227703812c254bd55b126f846e`), an
independent review of my a12 candidate: review commit `81a41f73…` on
`af035902…`, prepared in a disposable Ubuntu 24.04 QEMU guest with source-built
PostgreSQL 18.3, PgBouncer 1.24.1 and Zabbix 7.0.30 and 7.0.10. Reviewer
environment here: Ubuntu 24.04, Python 3.12.3, Node 22, source-built
PostgreSQL 18.3 + PgBouncer 1.24.1, source-built Zabbix 7.0.10 (two instances)
on PostgreSQL 16 + PHP 8.3, headless Chromium; no Docker daemon with registry
access. Output: this candidate, commit `a4ccf3a2bae61f76a1621d365ff1c83405302c58` on branch
`candidate/0.1.0a13`.

## Verdict

The review is correct, and its central finding is a real defect in my lab
harness that six candidates of green service runs had not exposed. It is
adopted unchanged. I reproduced the finding independently before adopting it,
and extended the same requirement to the one fixture path the review did not
cover. Ready to push to a private repository as the thirteenth alpha candidate.
No runtime Python or SQL change; no product defect was found by any of it.

## The review, verified

| Check | Result |
|---|---|
| Outer `SHA256SUMS` (544 entries), `dist/SHA256SUMS` (4) | All OK |
| Retained `original-input/zabalack-0.1.0a12-complete.zip` | `c94a059e…` — byte-identical to my a12 deliverable |
| Review bundle, branch `review/a12-zabbix-7-0-lts` | `81a41f73…` on `af035902…` (my a12); tree identical to its `plugin/source` |
| Wheel `685475df…` | The a12 wheel unchanged, as claimed; `tools/verify_release.py` PASS and `tools/public_audit.py` 297 files / 0 findings against its `dist/` |
| Reference, quality, SQL, webhook, quickstart, mutation, property, capture on its tree in a fresh pinned environment | 818/22/0, PASS, 8, 15, PASS, 12/12 and 20/20, 46, PASS |
| Its diff | `lab/zabbix_roles.py`, effective read-back before user/token creation, staged-context dependency, bounded lab RPC timeout, full projection-predicate wait, ten regressions, docs and manifests; runtime Python and SQL untouched |

## Finding A4, reproduced here before adoption

On a separate 7.0.10 instance, with the **original a12** rule set
(`actions.default_access: 0` plus a two-action list):

| Request | Result |
|---|---|
| `role.get` read-back | **all eleven** User-type actions enabled |
| `event.acknowledge` action 32 (suppress) | **ACCEPTED** — the capability the fixture claimed to deny |
| actions 1 and 8 (close, severity) | -32500 "No permissions to referred object" — host rights, not the role |
| Same three with the corrected enumerated rules | -32602 "no permissions to suppress/close problems / change problem severity"; `verify_role` accepted the read-back |
| A role enabling `acknowledge_problems`, action 16 | **ACCEPTED** — acknowledge and unacknowledge share one upstream capability; `src/zabalack/rpc.py` permits only actions 2 and 6, so the client refuses it |

The reproduction script is `reviews/0.1.0a13/a4_reproduction.py`; it creates and
deletes its own throwaway role, user and token on the disposable instance.

F2 is also real: my a12 compatibility manifest still carried a11's
`documentation_visuals` block saying browser capture was NOT_RUN, after a12 had
taken the captures. The correction is adopted.

## What a13 adds

1. The review's corrections, unchanged, with its ten regressions.
2. **A4 extended to the operator-provisioned real-Zabbix fixture**, which the
   review did not cover: its instruction was the same "grant only the required
   actions", and this lab's own worker and witness roles were found carrying
   `execute_scripts`, `manage_api_tokens`, `invoke_execute_now`,
   `edit_dashboards`, `edit_maps` and `change_problem_ranking` — contained in
   practice only by the API method allowlist. `lab/real_zabbix.md` now requires
   enumeration and effective read-back and names the `role_rules` constructor
   for the worker and witness shapes; two regressions pin those shapes; and
   `tests/real_zabbix/test_contract.py::test_A4_restricted_token_excluded_actions_denied_by_role_permission`
   proves the boundary on the live server, requiring the specific suppression
   denial and explicitly refusing a host-rights rejection as evidence. The lab
   fixture roles were re-provisioned with enumerated rules and verified first.
3. The A4 addendum and amendment R18 recording the independent reproduction.

## Executed on the final tree

| Suite | Result |
|---|---|
| Reference | **820 passed / 23 skipped / 0 failed** (791 unit/mock/property/offline + 29 WASM; 843 collected, all selected) |
| Native PostgreSQL 18.3 + PgBouncer 1.24.1 | **42 passed** (`postgres` 24, `delivery_faults` 5, `worker` 4, `alerta` 7, `performance` 2); cleanup exit 0 per phase |
| Real Zabbix 7.0.10 through `tools/record_real_zabbix.py --run` | **6 passed**, including the new A4 case |
| Deployment-path lab from the installed a13 wheel `6c44abd9…` | **4 passed, 13/13 observations**, with the corrected read-back and projection wait |
| Quality, SQL, webhook, quickstart, property, mutation, capture | PASS, 8, 15, PASS, 46, 12/12 and 20/20, PASS |
| pip-audit / npm audit / export audit / wheel smoke / SBOM / release verifier | 58 packages 0 advisories / 0 / 0 findings / PASS / CycloneDX 1.6 61 components / PASS |

## Verified from the packaged zip

| Check | Result |
|---|---|
| Outer `SHA256SUMS`, `plugin/RELEASE_SHA256SUMS`, `plugin/dist/SHA256SUMS` | All OK (nested lists included) |
| Wheel `6c44abd9…` `zabalack/` vs `src/zabalack/`; vs the a12 wheel | Byte-identical to the source; differs from a12 only in `__version__`; identical across two builds and to the deployment-lab runner wheel |
| Bundle restore, `verify_release.py --dist ../dist`, `public_audit.py` from the clone | Tree identical; PASS; PASS with every run record bound to the clone |
| Fresh venv from the clone: quality, fast suites, bare collection | See `verification/handoff-checks.json` |
| Identifier sweep | No lab paths, tokens, private keys, sandbox identifiers, personal names or e-mail addresses beyond synthetic `.invalid` fixtures, schema examples and placeholder author identities |
| Website | No scripts or forms; 17 pages, 402 local references resolve; copy states a13 results and keeps the review's own article |

## Residual observations (not blockers)

- G5 is unchanged by any of this: a passing disposable fixture does not
  establish effective-role read-back or permission tests on the approved
  installed account.
- The review's Zabbix 7.0.30 contract and supplemental API layers, its failed
  attempts and its intermediate harnesses are retained as received in
  `reviews/0.1.0a12-independent-review/` and are not rebound to this tree. The
  full notification pipeline remains pinned to 7.0.10 here.
- A2 (webhook transport does not authenticate TLS peers and follows redirects)
  is unresolved; the Docker Compose forms, hosted workflows, CodeQL, Gitleaks,
  signed attestation, an Alerta Web UI capture and external security review
  remain open. No in-place Ackline upgrade exists.
