"""Reproduce review finding A4 on the reviewer-independent local Zabbix 7.0.10 lab.

Creates the ORIGINAL a12 restricted role (actions.default_access=0 with only
add_problem_comments/acknowledge_problems listed), reads back its effective rules,
then creates a user + token with that role and attempts a real suppression.
Cleans up everything it creates. Isolated lab instance only.
"""
import json, sys, time
import httpx

URL = 'http://127.0.0.1:8080/api_jsonrpc.php'
c = httpx.Client(timeout=30, trust_env=False)
seq = 0
def call(method, params, auth=None):
    global seq; seq += 1
    h = {'Content-Type': 'application/json-rpc'}
    if auth: h['Authorization'] = 'Bearer ' + auth
    r = c.post(URL, json={'jsonrpc': '2.0', 'method': method, 'params': params, 'id': seq}, headers=h).json()
    if 'error' in r: raise RuntimeError(json.dumps(r['error']))
    return r['result']

admin = call('user.login', {'username': 'Admin', 'password': 'zabbix'})
ORIGINAL_RULES = {
    "ui.default_access": 0, "ui": [{"name": "monitoring.problems", "status": 1}],
    "modules.default_access": 0, "api.access": 1, "api.mode": 1,
    "api": ["event.get", "event.acknowledge", "host.get"],
    "actions.default_access": 0,
    "actions": [{"name": "add_problem_comments", "status": 1},
                {"name": "acknowledge_problems", "status": 1}],
}
created = {}
try:
    role_id = call('role.create', {'name': 'A4 repro original rules', 'type': 1, 'rules': ORIGINAL_RULES}, admin)['roleids'][0]
    created['role'] = role_id
    back = call('role.get', {'roleids': [role_id], 'output': ['roleid', 'type'],
                             'selectRules': ['actions.default_access', 'actions', 'ui.default_access', 'ui', 'api', 'api.access', 'api.mode']}, admin)
    actions = {row['name']: row['status'] for row in back[0]['rules']['actions']}
    print('actions.default_access =', back[0]['rules']['actions.default_access'])
    print('effective action rules :', json.dumps(actions))
    enabled = sorted(k for k, v in actions.items() if str(v) == '1')
    print('EFFECTIVELY ENABLED    :', enabled)
    # find a live problem on the deployment host to attempt suppression on
    hosts = call('host.get', {'output': ['hostid', 'host'], 'filter': {'host': ['zabalack-deployment-synthetic']}}, admin)
    events = call('event.get', {'hostids': [h['hostid'] for h in hosts], 'output': ['eventid', 'value', 'acknowledged'],
                                'sortfield': 'eventid', 'sortorder': 'DESC'}, admin) if hosts else []
    problems = [e for e in events if e['value'] == '1']
    group = call('hostgroup.get', {'output': ['groupid'], 'hostids': [h['hostid'] for h in hosts]}, admin)[0]['groupid'] if hosts else None
    if not problems:
        print('no synthetic problem event available for the write attempt'); raise SystemExit(0)
    event_id = problems[0]['eventid']
    ug = call('usergroup.create', {'name': 'A4 repro readers', 'gui_access': 1,
                                   'hostgroup_rights': [{'id': group, 'permission': 2}]}, admin)['usrgrpids'][0]
    created['usergroup'] = ug
    uid = call('user.create', {'username': 'a4-repro-user', 'passwd': 'A4-repro-synthetic-only!', 'roleid': role_id,
                               'usrgrps': [{'usrgrpid': ug}]}, admin)['userids'][0]
    created['user'] = uid
    tok = call('token.create', {'name': 'a4-repro-token', 'userid': uid}, admin)['tokenids'][0]
    created['token'] = tok
    secret = call('token.generate', [tok], admin)[0]['token']
    for label, payload in (('suppress (action 32)', {'eventids': event_id, 'action': 32, 'suppress_until': int(time.time()) + 300}),
                           ('close (action 1)', {'eventids': event_id, 'action': 1}),
                           ('severity (action 8)', {'eventids': event_id, 'action': 8, 'severity': 4})):
        try:
            res = call('event.acknowledge', payload, secret)
            print(f'  {label}: ACCEPTED -> {json.dumps(res)}')
        except RuntimeError as err:
            print(f'  {label}: rejected -> {str(err)[:220]}')
finally:
    for kind, key in (('token', 'token'), ('user', 'user'), ('usergroup', 'usergroup'), ('role', 'role')):
        if key in created:
            try: call({'token': 'token.delete', 'user': 'user.delete', 'usergroup': 'usergroup.delete', 'role': 'role.delete'}[kind], [created[key]], admin)
            except RuntimeError as err: print('cleanup', kind, 'failed', str(err)[:120])
    print('cleanup done')
