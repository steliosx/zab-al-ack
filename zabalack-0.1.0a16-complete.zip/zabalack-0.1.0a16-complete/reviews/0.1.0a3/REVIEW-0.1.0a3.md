# Review — Ackline 0.1.0a3 handoff (2026-09-10)

Scope: the packaged `ackline-website-and-plugin-0.1.0a3.zip` (SHA-256
`f4d890472fa36578a21ed466787b93089d11d68aed63305fe1d639425a607b21`), reviewed
from a fresh unzip in the same sandbox that prepared it. Reviewer environment:
Ubuntu 24.04, Python 3.12.3, Node 22.22.2, source-built PostgreSQL 18.3 and
PgBouncer 1.24.1, source-built Zabbix 7.0.10 on PostgreSQL 16 + PHP 8.3; no
Docker daemon with registry access, no Go toolchain.

## Verdict

Ready to push to a private repository as the third alpha candidate. The
identity is frozen as `ackline` and every automated suite the project defines
has now been executed at least once on this exact code, including the native
database phases and the real Zabbix API contract that all earlier packets had
to skip. What remains before a `0.1.0b1` tag is owner-side (`docs/BETA_READINESS.md`):
the ten publication inputs, a first hosted CI run (Docker-form native job and
Gitleaks), media-type/notification behaviour on a production-like Zabbix, and
an external security review. No code defect is open.

## Verified from the zip

| Check | Result |
|---|---|
| Top-level `SHA256SUMS` (218 entries), `plugin/source/RELEASE_SHA256SUMS` (211), `plugin/source/dist/SHA256SUMS` (4) | All OK |
| Wheel `ackline-0.1.0a3-py3-none-any.whl` `ackline/` vs `src/ackline/` | Byte-identical (13 modules); wheel hash `20a1f52d…` stable across three builds |
| Nested `dist/ackline-0.1.0a3-source.zip` vs source tree | Identical, handoff metadata excluded (the a2 defect is fixed) |
| Git bundle `candidate/v0.1.0a3` | One commit `afdfb858…`, `Ackline release preparation <release-preparation@localhost>`, dated `2026-09-10 00:00:00 +0000`, 202 tracked files, tree identical to source |
| `pip install --no-deps -e .` on `requirements.lock`; `pip check` | Clean |
| `pytest tests/unit tests/security tests/release tests/alerta tests/rpc` | 202 passed, 0 failed, 6 skipped (native-only) |
| `tools/run_reference_suite.py --wasm` (evidence in tree) | 214 passed, 12 skipped, 0 failed; 7 SQL groups; quickstart exit 0 |
| Native PostgreSQL 18.3 + PgBouncer 1.24.1, database `alerta`, fresh cluster per phase (evidence in tree) | 20 passed, 0 failed, 0 skipped, incl. the a2-review T14/T38 native assertions |
| Real Zabbix 7.0.10 API contract (evidence in tree) | 4 passed, 0 failed, 0 skipped: T13 exact-event read, T33 approved hosts, T11a restricted-token negative visibility, T1/T25 explicit synthetic acknowledgement with `[ackline]` comment and read-back |
| `zabbix/v1/test_webhook.cjs` | 12 passed (echo detector recognises the `[ackline]` prefix) |
| `tools/public_audit.py --publication` | PASS, 202 files, 0 findings, ten publication inputs pending |
| Acceptance matrix | 38 PASS / 2 MANUAL_GATE_PENDING (T2, T27 procedural); native and real-Zabbix columns populated from executed reports |
| pip-audit 2.9.0 (hash-verified install) / npm audit | 50 packages, 0 advisories / 0 vulnerabilities |
| Clean-venv wheel install with `[alerta]` extra | Both `ackline_zabbix_*` entry points load; `ackline --config … config-check` exit 0 |
| SBOM | Validates against the CycloneDX 1.6 schema bundled with cyclonedx-python-lib |
| Rename integrity | `src/` and `sql/` byte-identical to the a2 review commit after the recorded mechanical substitution (`evidence/implementation-integrity.json`) |
| Identifier sweep of the whole handoff | No `msp`, `alerta-ack`, `alerta_capture_probe`, lab token, lab paths, `+05:00`, kernel/glibc strings outside historical changelog/amendment text; no IPs beyond documentation ranges, no keys, no `.env`, no TODOs |
| Website | HTML well-formed, no `<script>`, no external assets beyond the canonical URL and the two upstream project links; `styles.css` and logo byte-identical to the published a2 site; local links and anchors resolve |

## Findings in this pass (all corrected before packaging)

1. `docs/DESIGN.md` §4.3 read "administrative cross-customer operators,
   cross-customer write-back" after the rename; reworded to "administrative
   operators, cross-customer write-back".
2. `evidence/README.md` did not name the executed-run records; it now indexes
   `native-run.json`, `real-zabbix-run.json` and the others.

Earlier in the same preparation, two defects were found and fixed with
regressions (see `CHANGELOG.md`): `tools/public_audit.py` selected `.lab/`
PostgreSQL data files into the public export on a host that had run the local
lab, and `lab/local_runtime.py` failed when a lab port was held in `TIME_WAIT`.

## Residual observations (not blockers)

- `classifiers` still says `Development Status :: 3 - Alpha`; flip to `4 - Beta`
  only with the `v0.1.0b1` tag.
- The real-Zabbix run used 7.0.10 (reference pin 7.0.0); the client already
  accepts `7.0.x`, the fixture records the observed version (R6).
- `requirements.lock` / `requirements-runtime.lock` remain version-pinned without
  `--hash` so they stay installable off the CI platform; only the scanner lock is
  hash-verified.
- The Docker Compose forms of both labs (`lab/compose.postgres.yml`,
  `lab/compose.zabbix.yml`) have still not been executed anywhere; the hosted
  `native` job is the first place that will happen.
