# Ackline 0.1.0a3 — independent build, test and improvement review

**a3 builds reproducibly, but its delivery coordination needs the supplied
correction before beta.** The attached review build fixes the demonstrated
unknown-outcome defect and release-evidence defects. It is an unreleased
proposal for isolated evaluation, not a production approval or new public tag.

## What was found and corrected

| Priority | Finding in supplied a3 | Correction |
|---|---|---|
| High | A response after lease expiry records `late_response` but leaves the action eligible for another send. Replacement-worker shutdown can also clear uncertainty inherited from the previous worker. | New migration 006 preserves unresolved attempts across callbacks, abandonment, shutdown and expiry; repairs affected existing active work; retains fencing and explicit settlement/retry. |
| Medium | Native startup or cleanup failure can preserve an earlier PASS run and its XML. | Invalidate current-run outputs before Docker access, write a RUNNING record and persist startup/cleanup failures. |
| Medium | Acceptance mapping accepts a failed native run/phase if pytest returned zero. | Require consistent successful run, phase, cleanup and nonempty passing JUnit; reject count mismatch. |
| Medium | All 11 SQL-manifest digests still match a2 bytes rather than renamed a3 files. | Refresh all digests; add 006; make stale, incomplete, duplicate or unsafe manifests stop export/build. |

The delivery defect is inherited from a2, not introduced by the rename. The
reproducer authorizes a second SQL `start_attempt`; it does not perform a real
duplicate Zabbix write. Mandatory pre-read helps when an earlier acknowledgement
is already visible, but does not settle a still-outstanding request.

The corrected seven-scenario SQL group covers late unknown/success/error replies,
replacement generation and shutdown, in-flight retry/pause, duplicate replies
after success, and explicit no-effect settlement followed by a separate retry.
It fails on unmodified a3 and passes after correction. Two existing 005→006
upgrade scenarios also pass, including damage caused by the old replacement
shutdown path. The original five migration files remain byte-identical.

Migration 006 requires database schema 2 and does not silently reseal readiness.
Worker/probe/operator direct access to its helper is denied. Function replacement
retains existing ownership/permissions; the private helper uses a controlled
search path and revoked PUBLIC execution, consistent with the inspected
[PostgreSQL 18 function interface](https://www.postgresql.org/docs/18/sql-createfunction.html).

## Executed evidence

| Check | Result | What it establishes |
|---|---|---|
| Supplied archive | Listed hashes and ZIP CRC valid | Integrity, not authenticity; outer checksum omitted two nested checksum files |
| Clean supplied a3 build | Wheel, normalized sdist and source ZIP each built twice identically and matched supplied artifacts exactly | Independent source build under Python 3.12.14/setuptools 83.0.0 |
| Original reference suite | **214 passed, 0 failed, 12 skipped** | 202 unit/mocked + 12 PostgreSQL WASM tests; all 226 collected cases accounted for |
| Corrected reference suite | **250 passed, 0 failed, 12 skipped** | 236 unit/mocked + 14 PostgreSQL WASM tests |
| SQL groups | **8 passed** | Actual PostgreSQL 18.3 WASM, Alerta composite history, role-selected SQL and upgrade behavior |
| Release regressions | **72 passed, 0 failed, 0 skipped** | Includes 34 new evidence/manifest tests; focused final rerun after CSV line-ending normalization |
| Synthetic webhook | **12 groups passed** | Node contract fixtures, not real macro/notification behavior |
| Quickstart | Exit 0 before and after fixes | Actual Alerta HTTP and PostgreSQL WASM; mocked Zabbix; repeats excluded from totals |
| Rebuilt installed wheels | Original and corrected smoke checks passed | Non-editable imports, both Alerta entry points, CLI, inert configuration and pip check |
| Python advisory scan | **50 packages, 0 advisories, 0 skipped** | Fresh pip-audit on exact unchanged lock |
| Node advisory scan | **0 vulnerabilities** | Fresh npm audit |
| SBOM | **53 components; schema valid** | CycloneDX 1.6 shape, not licence clearance |
| Corrected build | Wheel/sdist/source ZIP each twice byte-identical | Final CRC, hashes, wheel modules and complete source tree verified |
| Static website | 26 local references/anchors valid; 4 assets preserved | Static source check only; not republished or browser-tested |

The twelve skips are eight native-only checks and four real-Zabbix checks.
PostgreSQL WASM is not native multi-session concurrency, login authentication,
PgBouncer, TLS/cancellation, failover or HA evidence. No skipped check is a pass.
The acceptance catalogue was regenerated with per-layer attribution; its
reference PASS cells do not satisfy G1–G8.

**Not rerun here:** native PostgreSQL/PgBouncer (Docker unavailable and the
workspace cannot switch to the required non-root identity), real Zabbix (no
disposable backend/fixture), hosted CI, Gitleaks (no executable/Go), Ansible or
systemd deployment, media import/macro expansion/update notifications and
external security review. Supplied a3 contains 20 native and 4 real-Zabbix passes;
these remain separately attributed to the original archive and never validate 006.

The offline npm install command was declined before execution. The lab instead
used existing local packages after comparing their exact locked dependency
entries and installed versions; no lifecycle scripts ran. Fresh registry-tarball
file verification was not repeated. Python dependencies came from local wheels
at their exact required versions. Node 24.19.0 was used here; hosted CI selects 22.

One intermediate source-ZIP integrity check failed because its temporary file
was incomplete. That file was discarded. The final build was regenerated and
validated sequentially before assembly; the cause of the transient workspace
file change was not established. It is not counted as a passing check.

## Next improvements, in priority order

1. Run migration 006, both upgrade scenarios and the current native runner on an
   isolated PostgreSQL/PgBouncer host. Then run a full Alerta→ledger→worker→real
   Zabbix case and actual media/update-operation checks before beta.
2. Bind every evidence run to a source/test digest. This review removes stale
   service reports from current inputs; source identity would prevent future
   cross-commit evidence mixing more generally.
3. Strengthen the real-Zabbix outside-scope fixture with independent positive
   existence/association evidence. A nonexistent event, wrong filter or generic
   request error must not masquerade as a proved permission boundary.
4. Measure retained-ledger query plans and consider narrow indexes on attempts
   and outcomes after EXPLAIN/ANALYZE. Small 50/200 lab batches do not establish
   performance with a large retained history.
5. Flag ambiguous licence labels such as python-dateutil's `Dual License` for
   publisher review. The SBOM is schema-valid, but its empty ambiguity list is
   too optimistic; ownership and licence obligations remain open.

The real-Zabbix README and beta-readiness notes were corrected. The consolidated
archive checksum covers every file except the manifest itself, including nested
checksum files. No domain, repository, production service or package publication
was changed by this review.

## Handoff and reproduction

Original candidate commit: `afdfb858909f113a0138b2fe23bb1b3f9d471eb6`.
Corrected review commit: `9a22f93493194e183a9da8fd7f8f3f842614cc0b` on `review/a3-corrections`.
The candidate tag still points to original a3. Package version remains 0.1.0a3;
assign a new version before publishing the corrected artifacts.

`source/` is the complete corrected tree. `dist/` holds the corrected wheel,
sdist, source ZIP, provenance and Git bundle. `baseline-build/` holds the
independently rebuilt original artifacts. `baseline-evidence/` and
`review-evidence/` contain separately labelled evidence. `supplied-a3/` retains
the exact input ZIP. `website/` contains its unchanged static page.

From the extracted archive root:

```bash
sha256sum -c SHA256SUMS
git clone --branch review/a3-corrections dist/ackline-a3-review.git.bundle reviewed
git -C reviewed remote remove origin
cd reviewed
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements.lock
.venv/bin/python -m pip install --no-deps --no-build-isolation -e .
.venv/bin/python -m pip check
npm ci --prefix lab --legacy-peer-deps --ignore-scripts --no-audit --no-fund
.venv/bin/python tools/run_reference_suite.py --wasm
node lab/pglite_checks.mjs --isolated-lab
node zabbix/v1/test_webhook.cjs
.venv/bin/python tools/native_ci.py --isolated-lab
.venv/bin/python tools/public_audit.py
.venv/bin/python tools/build_release.py
```

The native command must run on a suitable isolated local Docker host; it returns
NOT_RUN here. For database changes use `source/docs/deployment.md`; migration
ownership and installation/reseal authority remain separate. Rollback holds work
and retains 006/schema 2; never rewrite migration checksums, delete evidence or
unacknowledge Zabbix to undo this patch. Old schema 1 binaries fail health after006.

All deployment inputs remain consolidated in `source/docs/INPUTS_REQUIRED.md`:
installed versions/routing/owners, redacted source payload/media/update evidence,
tenant permissions/cohorts, staging and protected secret references, measured
native/HA/batch acceptance, named responders, records policy and approved change
records. The separate ten publication inputs remain in
`source/config/publication.pending.json`. No live secrets are requested in chat.
