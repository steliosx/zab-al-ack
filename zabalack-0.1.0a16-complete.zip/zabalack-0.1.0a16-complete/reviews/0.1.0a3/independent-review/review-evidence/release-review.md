# Ackline a3 release/tooling review

Reviewed the supplied a3 source and nested release artifacts against the a2
review checkout. The source was kept read-only. Reproductions used local
temporary files and mocked subprocesses; no Docker, database, Zabbix endpoint,
Git remote, production service or notification was contacted by this reviewer.

The main a2 review corrections survive the rename: the pinned Gitleaks linker
symbol, exact test-and-layer acceptance aggregation, handoff metadata exclusions,
TCP-only local PostgreSQL startup, and T14/T38 SQL assertions are present. Package
metadata and installable entry points consistently use `ackline`; historical
`msp_*` names remain in the historical changelog as expected.

## Findings fixed in the supplied tooling patch

### P2 — Native startup/cleanup failures can retain an earlier passing run

Supplied `tools/native_ci.py:53–59,68–82,96–109` clears XML only after successful
Compose startup, and writes the run record only after cleanup. The cleanup
`subprocess.run()` is outside an exception handler. Reproduction: seed a prior
PASS run and passing XML; mock Compose `up` to raise `CalledProcessError`, then
mock `stop` to raise `TimeoutExpired`. The runner raises, and both the prior
PASS run and its passing XML remain unchanged. A later acceptance update can
consume that stale run. If cleanup returns normally, stale XML still survives
startup failure and is selected by the CI artifact upload wildcard, although
the new failure record prevents normal acceptance mapping.

The patch invalidates all XML owned by the native runner and records `RUNNING`
before checking Docker. It records explicit unavailability, catches cleanup
errors/timeouts, persists failure outcomes, and refuses to treat malformed JUnit
as completed execution. Previous evidence is retained in the immutable supplied
packet; current-run output is replaced deliberately.

Reproduction records: `release-agent/runner-repros.json` and
`release-agent/native-cleanup-stale-repro.json`.

### P2 — Acceptance mapping ignores failed native run/phase status

Supplied `tools/update_acceptance.py:35–45` checks `exit_code == 0`, but ignores
the run and phase `status` and cleanup outcome. Native pytest can succeed while
Compose shutdown fails; the runner correctly marks the phase FAIL without
changing pytest's zero exit code. Reproduction: a run with `status: FAIL`, a
phase with `status: FAIL`, `shutdown_exit_code: 1`, `exit_code: 0`, and a passing
JUnit file reaches the mapper and returns zero.

The patch requires a completed PASS native run and PASS phases, successful
cleanup, nonempty passing JUnit, and agreement with recorded counts where those
are supplied. A valid `NOT_RUN` record with no phases contributes no native
evidence. Malformed, failed, interrupted and internally inconsistent reports
are rejected. This does not make native results deployment acceptance.

## Validation of the tooling patch

- Patched files: `tools/native_ci.py`, `tools/update_acceptance.py`,
  `tests/release/test_a2_regressions.py` (fixture metadata), and new
  `tests/release/test_native_evidence_failures.py`.
- All `tests/release` tests executed in the isolated fix checkout: **58 passed,
  0 failed, 0 skipped**. Twenty new cases exercise service startup/cleanup
  failures, malformed XML, failed and incomplete reports, count disagreement,
  explicit unavailability and successful fresh evidence.
- These are mocked runner/unit regressions, not native database tests.
- `git diff --check` passed.
- Patch: `release-agent/native-evidence-fixes.patch`.
- Fresh focused JUnit: `release-agent/focused-release.xml` (raw local test
  output; apply the existing evidence redactor before public redistribution).

## Packaging and evidence observations

1. Every listed hash in all four supplied checksum files verified. The 202-file
   nested source ZIP matches its corresponding source tree byte for byte; all
   installable wheel module files match `source/src/ackline/`.
2. The outer `SHA256SUMS` omits the two nested files named `SHA256SUMS`, despite
   the outer README promising every file except itself. The middle checksum
   file also omits the nested `dist/SHA256SUMS`. This is a minor coverage/wording
   issue: the plugin `RELEASE_SHA256SUMS` fully covers its tree, and the omitted
   dist checksum is covered there. New packaging should exclude only the exact
   manifest being generated, not every file sharing its basename.
3. `dist/SHA256SUMS` is the builder's four-artifact manifest; the Git bundle and
   SBOM validation added afterward are covered by the broader release checksum.
   Document this scope instead of describing it as every final dist artifact.
4. Supplied real-Zabbix evidence describes four source-built 7.0.10 API-contract
   passes and explicitly excludes macro expansion, notification behavior,
   production tenant boundaries and G1–G8. The native report likewise identifies
   its local source-built runner rather than claiming the Docker job ran.
5. `tests/real_zabbix/README.md` still says the four tests were collected but not
   executed. That sentence is stale against `evidence/real-zabbix-run.json` and
   the a3 changelog; update it to distinguish the supplied executed API contract
   from the unexecuted Compose/media/notification coverage.

## Further improvements

- Strengthen `tests/real_zabbix/test_contract.py:73–85`: the outside-scope
  negative read accepts both an empty result and the client's generic
  `api_permission_or_request_rejected` error. That error also covers malformed
  requests; wrong group filters or a nonexistent event can also return empty.
  Require independent positive existence/association evidence for the exact
  outside fixture and reject generic request errors as permission proof. The
  current lab report asserts the fixture was independently created, so this is
  a reproducibility/test-strength improvement, not evidence that its four
  recorded runs failed or that the production worker bypasses permissions.
- `tools/dependency_inventory.py:33–38` treats any short License string as
  unambiguous. The SBOM includes `python-dateutil` with `license.name` equal to
  `Dual License`, while `dependency-review.json` has an empty ambiguity list.
  Preserve the declared metadata but flag ambiguous labels for publisher review
  or add a reviewed SPDX mapping backed by packaged license text. This is a
  metadata quality issue; schema-valid JSON alone cannot resolve obligations.
- Pin an immutable source identifier in fresh run records (and preferably a
  digest of the selected source/tests), so a future locally edited tree cannot
  silently combine previously committed native evidence with a fresh unit run.
- The beta-readiness plan should keep product-level Zabbix macro/media and
  notification checks explicit, alongside hosted Docker and Gitleaks execution.
  The current four API tests do not cover the complete Alerta→ledger→worker→real
  Zabbix path; adding one isolated end-to-end case would materially strengthen
  the next candidate beyond separately passing contract layers.

No independent production acceptance, deployment gate, real-Zabbix rerun or
native PostgreSQL rerun is claimed by this release-tooling review.

## Follow-up: SQL manifest identity guard

Independently confirmed **11 of 11** hashes in the supplied a3
`docs/sql_manifest.json` mismatch the shipped bytes. Every recorded hash instead
matches the a2 review checkout. This is a concrete rename regression in the
compatibility manifest, although the outer release checksums and supplied
package contents are internally consistent.

`release-agent/supplied-sql-manifest-check.json` records each expected/observed
digest. The additional `release-agent/sql-manifest-audit.patch` makes
`public_audit.py` (and therefore `build_release.py`) require the current complete
set of executable SQL and Python files under `sql/`, exact known paths, no
duplicate entries, valid digests and matching source bytes. It does not hardcode
a schema version. It rejects malformed/missing manifest data and includes a
regression proving the builder refuses drift before launching a build.

After this patch, the complete release-test directory executed **72 passed,
0 failed, 0 skipped**, including 14 additional manifest regressions. The supplied
manifest is intentionally unchanged in the reviewer checkout; the runtime
correction owns its regeneration alongside migration 006.

## Independent review of the runtime correction

Read the final `runtime-fix` migration 006 and its SQL/pytest regressions without
editing runtime files. Approved the bounded correction for integration, subject
to the final executed test run. Independently compared migrations 001–005 with
the supplied a3 bytes: all five are unchanged.

Two additional cases identified during this review were incorporated by the
runtime author before approval:

- A replacement worker can hold a delivery lease for the previous owner's
  unresolved send. Its shutdown previously inferred safety from the absence of
  its own attempts and reset uncertainty. The final function preserves existing
  uncertainty or any unsettled attempt across owners, and leaves terminal
  states intact. Replacement shutdown regressions now assert no blind reclaim.
- An existing pre-006 database may already contain that damaged state: an older
  generation has a late response, while the current replacement lease has no
  attempt and the action is pending/non-uncertain. The initial repair joined
  only the current lease generation and missed it. The final fenced migration
  quarantines active unsettled late-response attempts across generations, while
  excluding terminal and explicitly settled cases. The upgrade fixture now
  seeds both original and replacement-shutdown damage.

The private helper uses schema-qualified tables and a fixed search path; PUBLIC
EXECUTE is revoked, with worker/probe/operator denial assertions included. The
function replacement retains the established public callable interfaces and
does not add application table grants or trigger authority. Late responses
remain audit evidence; duplicate callbacks do not overwrite committed success
or explicit no-effect settlement/settled retry. The migration changes readiness
fingerprints and schema version; it does not silently reseal the installation.

This was an independent source/logic review. Runtime execution is recorded by
the runtime author and the final integrated root run; no additional native or
real-Zabbix execution is claimed here. Sequential PGlite tests cannot establish
native concurrency, site failover, transport fencing or remote side effects.

A later measured performance improvement is worth tracking: the existing
attempt/outcome tables lack secondary indexes on action/attempt lookup keys.
The helper makes those lookups explicit. Test realistic retained-ledger sizes
with query plans before selecting narrow indexes in a future forward migration;
small synthetic batches do not establish that scale behavior.
