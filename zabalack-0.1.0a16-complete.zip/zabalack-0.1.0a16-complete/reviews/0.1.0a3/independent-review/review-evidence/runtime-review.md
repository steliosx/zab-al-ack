# Runtime, SQL and deployment review of proposed Ackline 0.1.0a3

Reviewed the supplied source against the reviewed a2 source, development contract, design revision1.2, final-review interpretations and source amendmentA1. Work remained local and synthetic. The supplied source was not edited.

## Confirmed defect: expired-lease completion can authorize another write (HIGH)

**Location:** shipped `sql/migrations/003_worker.sql:173–179`, with abandonment checks at `153–155` and the `reconcile_due` branch. Inherited from a2; it is not caused by the rename.

A callback arriving after its delivery lease expires inserts an outcome with `state=late_response, uncertain=true`, but leaves the action `delivery_claimed, uncertain=false`. The later abandonment checks interpret the existence of any outcome as sufficient to stop treating the attempt as abandoned. Another worker can therefore claim the action and receive a new permitted `start_attempt`, without first resolving the unknown external outcome. The required pre-read reduces duplicate risk when the source already shows acknowledgement; it does not settle an outstanding earlier request that has not yet become visible.

The operator `retry` command can also move an in-flight action to pending, and a paused claim can move it to held. A correction that guards only `delivery_claimed` misses that state transition. Separately, a replacement worker can inherit an abandoned attempt, then lose its uncertainty on shutdown because the shipped `worker_stopped` code only looks for attempts owned by that replacement. Both transitions are corrected and tested.

**Executed reproducer:** `repro-late-response.mjs`, result `repro-late-response.json`: fresh PostgreSQL18.3 WASM bootstrap, synthetic trusted-ledger fixture, recorded first attempt, test-only lease-time advancement, late unknown completion, reconcile and reclaim. Result: `second_write_allowed=true`. This proves SQL permission to send again. It is not a real Zabbix duplicate-write or native HA experiment.

**Correction supplied:** `runtime-fix.patch`, adding forward migration `006_late_response_fencing.sql` while retaining001–005 byte-for-byte. The private helper distinguishes genuinely unresolved attempts from definitive attempt outcomes and later explicit operator no-effect settlement. A late callback keeps a still-current unresolved action unknown across queued/held states, preserves replacement generations and settled/terminal states, and records immutable late evidence. The migration repairs existing active unsettled late-response rows across generations, including rows damaged by replacement-worker shutdown. The same helper is used by abandonment, reconciliation and expiry checks; shutdown preserves inherited uncertainty and terminal results. Schema version2 prevents corrected plugin/worker health checks from accepting the old SQL implementation; existing readiness must be explicitly re-sealed by the installation principal after migration validation. No new runtime grants, trigger changes or external calls are added.

**Executed correction evidence:** seven-case SQL group fails on supplied a3, passes on corrected a3. Covers late unknown/success/definite-failure callbacks, replacement generation, in-flight retry plus pause, duplicate callback after success, duplicate callback after explicit settlement, and settlement plus separate retry. Both existing005→006 upgrade scenarios pass (expired-lease callback and prior-generation callback plus replacement shutdown): action becomes unknown, reclaim is refused, schema reports2, health rejects unsealed definitions and succeeds after explicit owner reseal. Twelve health unit tests pass. These are supplemental PostgreSQLWASM and unit results, not native concurrency, authentication, PgBouncer, real Zabbix or G1–G8 acceptance. Root owns full-suite rerun and native availability reporting.

## Confirmed release metadata defect: SQL manifest hashes stale (MEDIUM)

**Location:** `docs/sql_manifest.json:7–50` in supplied a3. All eleven listed hashes disagree with their actual a3 SQL/script bytes. Names were updated for Ackline, but hashes were not regenerated with the renamed content. This breaks that manifest as a reproducible verification input, even though the outer archive checksum manifest can be correct.

**Reproduction:** calculate SHA256 of every listed path and compare to its stored value. The runtime patch regenerates the eleven entries, adds006 and records `database_schema_version:2`. Root independently checks the full release provenance.

## Checked boundaries; no further concrete defect established

After applying the documented identifier mapping, application and SQL changes from reviewed a2 are confined to package version, HMAC domain name, neutral comment prefix and identity substitutions. Source endpoint resolution still follows MAC verification. SQL role/function calls, plugin config variable, worker/reconciler units, CLI and Ansible paths consistently use Ackline. Production examples remain inert; deployment playbooks require explicit target/opt-in/change context and do not start services. The normalizer continues stripping the protected Alerta attribute namespace and the signer still requires its privacy adapter and audited effective route.

The rename deliberately provides no in-place a2 migration or dual-prefix verifier. R5 states it is for disposable labs before tracked/public installation. That is a documented compatibility restriction, not an unreported supported-upgrade failure. An engineer discovering any tracked old-schema installation must stop and produce its separate forward-migration plan; do not reset an operational database or alter its migration ledger.

No new permissions, production gate satisfaction or actual installed compatibility is inferred from these checks.
