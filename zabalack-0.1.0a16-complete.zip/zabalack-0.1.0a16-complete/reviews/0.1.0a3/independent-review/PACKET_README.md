# Ackline a3 independent review handoff

Start with ACKLINE_A3_REVIEW.md and CHANGELOG.md.

- source/: complete corrected source and current test evidence.
- dist/: corrected wheel, sdist, source ZIP, provenance and review Git bundle.
- baseline-build/ and baseline-evidence/: original a3 independently built/tested.
- review-evidence/: targeted defect, upgrade, integrity and environment records.
- supplied-a3/: unchanged original input archive and its supplied service evidence.
- website/: unchanged static HTML site; open website/index.html locally.

Use SHA256SUMS from this directory to verify every other file. Both builds retain
version0.1.0a3; corrected artifacts are an unreleased review, not a public release.
Only website/ belongs in a static host's public document root. No code or site
was pushed or published. Native/real-Zabbix validation and G1-G8 remain open.
