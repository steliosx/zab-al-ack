# Reproduce the a14 handoff

Use Python 3.12 on an isolated supported Linux host. Restore `plugin/source/`
or clone `plugin/dist/zabalack-0.1.0a14.bundle` with branch
`candidate/0.1.0a14`. Run commands inside the restored checkout with `TZ=UTC`.
Use the declared reference pins and install quality tools with their hash lock:

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements.lock
.venv/bin/python -m pip install --require-hashes --only-binary=:all: -r requirements-quality.lock
.venv/bin/python -m pip install --no-deps -e .
npm ci --prefix lab --ignore-scripts --legacy-peer-deps
export TZ=UTC
.venv/bin/python tools/run_review.py --plan
.venv/bin/python tools/run_review.py --isolated-lab \
  --phase quality --phase sql --phase reference --phase mutation-pr \
  --phase mutation-nightly --phase property-nightly --phase quickstart
node zabbix/v1/test_webhook.cjs
```

The reference lock has exact versions, not inline hashes; the quality lock
contains hashes. This review additionally recorded the 50 observed wheel hashes
used for its offline clean-venv smoke in `wheel-input-hashes.json` and
`wheel-smoke-install.lock`. Those observed hashes are not publisher attestations.
Do not install the optional scanner dependencies into the reference environment.

For native PostgreSQL/PgBouncer and real Zabbix, follow `docs/local-services.md`,
`docs/RELEASING.md` and `lab/real_zabbix.md`. Only use explicitly disposable
synthetic services. Native unavailable runners return 2; the real-Zabbix recorder
can write an honest NOT_RUN reason. None of these results closes G1–G8. A2
transport remediation remains required before any approved deployment.

After all affected runs finish, regenerate acceptance and inventories, inspect
security results, and build/verify:

```bash
.venv/bin/python tools/update_acceptance.py
.venv/bin/python tools/dependency_inventory.py
.venv/bin/python tools/public_audit.py --write-report
.venv/bin/python tools/build_release.py
.venv/bin/python tools/verify_release.py
```

Do not run independent evidence writers concurrently in the same checkout.
Use a fresh run identity after an interrupted attempt. Never modify an old
report's source/harness digests to match a changed tree. A new run supersedes,
but does not erase, an older failure.

## Independent task inputs

E1–E4 start from intermediate commit `7de183946b33ae08372055dd77b2b2b455b0389b`,
with exact per-file input hashes and requests in each `input.json`. E1 has one
seeded README typo; E2 has the ordinary customer's membership predicate removed;
E3 carries inherited a13 evidence; E4 adds a synthetic interrupted record (no
process had been launched). E5 records its provided source/artifact overlay by
hash. See each result and parent review, not an assumed ideal response. Use a
separate copy and an independent context for each task. These are qualitative
observations, not statistical quality or speed improvements.

## Deployment and rollback

Use `plugin/source/docs/INPUTS_REQUIRED.md` as the consolidated open-input
register. Installation and non-destructive rollback instructions remain in
`docs/deployment.md` and `docs/rollback.md`. No migration is added in a14; SQL is
byte-identical to a13. Do not drop capture/ledger data or automatically
unacknowledge source events. The pending publication register and publishing
template remain inactive. No remote push, website update or production operation
was performed for this handoff.
