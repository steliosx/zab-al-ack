# Zab-al-ack 0.1.0a14 — agent workflows and retained review evidence

This candidate starts from the last delivered a13 archive, verified against its
863 checksum entries and its 297-file source/Git bundle. The original archive is
included byte-for-byte under `previous-release/` in the complete handoff. Runtime
Python differs only in the version constant; SQL and schema version 3 are
unchanged. There is no migration or new acknowledgement route in a14.

## Implemented in the requested order

1. **Task-specific AGENTS.md:** concise task routes retain the frozen trust,
   tenant, transaction, delivery and production boundaries.
2. **Three repository skills:** release review, isolated lab and migration review,
   each linking the maintained references needed for its task.
3. **Completion examples:** practical requests include implementation, repair,
   verification and handoff under the already authorised local scope.
4. **Retained review runs:** unique private attempt directories, nonblocking
   checkout locks, serial phases, changed-evidence snapshots and explicit
   interruption/cleanup limits. PR and nightly mutation profiles retain separate
   reports and attempts as well as a compatibility latest pointer.
6. **Packaging:** source ZIP and sdist include the skills and evaluation cases;
   build and release verification compare a separate 16-file guidance fingerprint.
   The installed wheel contains the runtime plugin, not agent instructions.
5. **Independent forward-tests:** five qualitative tasks in disposable copies,
   with exact requests, input hashes, actual observations and parent review in
   the complete handoff's `review/agent-evaluations/`. These are not comparative
   model benchmarks or evidence that a ZIP upload automatically loads skills.

## Current execution evidence

The complete handoff's `review/FINAL_VERIFICATION.json` records the final source,
artifact identities and packaging checks. Earlier failed and successful attempts
remain separately labelled in `review/attempts/`; no earlier digest was rewritten.

| Check | Result and scope |
|---|---|
| Reference suite | 853 passed / 23 skipped / 0 failed: 824 unit/mock/property/offline passes and 29 PostgreSQL WASM passes |
| Supplemental SQL | 8 groups passed, actual PGlite 0.5.8 PostgreSQL 18.3 engine; not native permission/concurrency evidence |
| Synthetic webhook | 15 Node groups passed; not a real notification pipeline |
| PR / nightly mutations | 12/12 and 20/20 killed by assertion failures; profiles retained separately |
| Property nightly | 46 passed; overlaps the reference suite and is not added to its total |
| Quality and quickstart | Ruff, gradual strict mypy, pip check and isolated quickstart passed |
| Python / Node advisory queries | 58 exact Python pins, no skipped packages or known advisories; npm zero vulnerabilities |
| Native PostgreSQL / PgBouncer | NOT_RUN for a14: no Docker runtime, native service layout or permitted unprivileged service startup |
| Real Zabbix contract / full installed-wheel service path | NOT_RUN for a14; no prepared disposable real Zabbix instance |

The four native-only cases skipped in the WASM selection and nineteen optional
service cases remain skipped. A package import/entrypoint smoke test is distinct
from the unavailable full installed-wheel service path. Local scanner, SBOM and
artifact verification records are supplied with their actual scope; none is a
signed attestation or independent external security review.

## Review findings and boundaries

The first full run found two audit-fixture failures: newly mandatory guidance
files had not been added to the required-file list used by those fixtures. The
list was repaired without weakening validation or tests. The independent
read-only evaluation correctly rejected twelve historical evidence records in
its input. Final review also corrected stale version references in the pending
publication register and inactive publishing template and clarified the real
Zabbix README's historical count. Evidence-bound suites were rerun after those
harness edits. See `docs/RELEASE_AMENDMENTS.md` R19 and the full cumulative
`CHANGELOG.md` for reasoning.

Supplied a13 native (42 passes), real Zabbix (6) and installed-wheel pipeline (4)
records remain historical evidence inside the exact prior archive. They are not
fresh a14 results. The website and screenshots are the supplied a13 assets with
their original version labels; no new website publication or capture occurred.

**G1–G8 remain MANUAL_GATE_PENDING; amendment A2 remains unresolved.** The
reference webhook's transport authentication and redirect containment need the
approved installed remediation and negative tests before deployment. Hosted
Actions/CodeQL, Docker Compose execution, signed attestations and Alerta Web UI
capture remain unexecuted. Public ownership, contacts and rights review remain
pending. Production configuration is disabled with empty cohorts and endpoints.

## Reproduce and hand off

Follow `docs/agent-workflows.md`, `docs/RELEASING.md` and `docs/local-services.md`.
Run `python tools/run_review.py --plan` before selecting phases; execution requires
`--isolated-lab`. Review `docs/deployment.md` and `docs/rollback.md` before any
separately authorised rollout. Schema-3 zabalack installations need no migration
for this code-only alpha; an in-place legacy Ackline upgrade remains unsupported.
Use `docs/INPUTS_REQUIRED.md` as the consolidated deployment/publication register.
Never provide live secrets in chat or use synthetic fixtures to close gates.
