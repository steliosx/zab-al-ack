# Environment attempts retained honestly

- The initial clone of the supplied bundle without an explicit branch had no
  checked-out HEAD. Selecting `candidate/0.1.0a13` restored the correct baseline;
  all 297 source files then matched the bundle. No source mismatch is asserted.
- The first offline dependency installation could not find the four newer pinned
  pytest/pytest-asyncio/setuptools/wheel distributions. Their exact versions were
  downloaded and the installation completed; project pins were unchanged.
- The first reference review failed two strict audit-fixture tests. The mandatory
  guidance-file list was repaired, and later fresh attempts passed. See retained
  attempt records and their redacted JUnit failures.
- The first clean-wheel installation incorrectly supplied `--require-hashes` to
  the reference lock, which contains only exact versions. Pip refused it. The
  successful retry used a derived lock for all 50 actual cached wheel hashes;
  no package requirement or hash requirement was removed from a supplied lock.
- Docker was unavailable. Starting a native service as an unprivileged identity
  was also blocked (`runuser` could not set groups). The PostgreSQL root guard was
  not bypassed. Native/real-Zabbix/full installed-wheel service runs are NOT_RUN.
- The documentation evaluation's Git command could not inspect a repository
  because that copy was an archive with no Git metadata. Subsequent file hashes
  established the intended changes; no clean Git status was invented.

Local raw setup/scanner/test logs remain private and are excluded. The handoff
includes redacted outcomes, input hashes and actual failures sufficient to review
the conclusions. Supplied historical evidence stays inside the exact a13 ZIP.
