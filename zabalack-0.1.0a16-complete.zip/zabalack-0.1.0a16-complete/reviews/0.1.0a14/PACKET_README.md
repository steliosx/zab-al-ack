# Zab-al-ack 0.1.0a14 complete handoff

Fresh implementation from the supplied a13 release. This one ZIP includes the
complete plugin source, installable wheel, sdist, source ZIP, unsigned provenance,
UTC Git bundle, cumulative changelog/justification, website/screenshots, executable
tests, deployment/rollback tooling, review evidence and the exact prior archive.
No plugin source was pushed remotely and no website or production service was
changed by this handoff.

## Start here

- `plugin/source/ALPHA_REPORT.md`: implemented items 1–4, 6, then 5; actual results.
- `plugin/source/docs/agent-workflows.md`: practical contributor commands and skills.
- `plugin/source/CHANGELOG.md` and `plugin/source/docs/RELEASE_AMENDMENTS.md` R19: full history and reasons.
- `review/REVIEW-0.1.0a14.md` and `review/FINAL_VERIFICATION.json`: fresh review and artifact checks.
- `review/REPRODUCE.md`: restore, install, test and build commands.
- `DEPLOYMENT_INPUTS_REQUIRED.md`: one consolidated publication/deployment register.
- `plugin/source/docs/deployment.md` and `plugin/source/docs/rollback.md`: non-destructive rollout/rollback instructions.

The reference suite has 853 passes, 23 skips, no failures. SQL (8 groups),
webhook (15 groups), PR/nightly mutations (12/20 assertion kills), nightly
properties (46 overlapping passes), quality and quickstart passed. Native
PostgreSQL/PgBouncer, real Zabbix and the full installed-wheel service path are
NOT_RUN for a14 in this restarted environment. A clean wheel import/entrypoint
smoke is a separate successful check. G1–G8 and A2 remain unresolved.

`previous-release/zabalack-0.1.0a13-complete.zip` is the byte-identical supplied
baseline, preserving historical reviews/evidence. The website and screenshots
are preserved from that archive with their original version labels. They are
not recaptured or relabelled as current test evidence. The source includes all
previous plugin features and the new maintenance controls.

## Verify and restore

From this directory:

```bash
sha256sum -c SHA256SUMS
git clone --branch candidate/0.1.0a14 plugin/dist/zabalack-0.1.0a14.bundle checkout
```

The outer checksum list covers every file except itself, including nested
checksum lists and the Git bundle. It establishes consistency, not authenticity
or a signed attestation. The standalone source ZIP and sdist include the three
repository skills; the wheel remains the Alerta/runtime package. Check all
publication-owner inputs before any separately authorised upload. Production
examples remain disabled with no active cohort or endpoint.
