# Review of Zab-al-ack 0.1.0a14

The supplied a13 archive is the authoritative input for this fresh a14 build.
Its 863 checksum entries and all 297 source/Git-bundle files were verified before
implementation. No unavailable later artifact or conversational pass count was
used as current evidence. The exact a13 ZIP is retained in the handoff.

## Implemented and justified

Items 1–4 and 6 precede the five behavioural tasks in item 5. The project now has
a task-specific AGENTS.md, three focused repository skills, practical completion
examples, retained serial review attempts, separate PR/nightly mutation records,
and a 16-file instruction fingerprint checked in the source ZIP and sdist.
The full cumulative CHANGELOG and amendment R19 explain each change. Runtime
Python changes only the version string; SQL is byte-identical to a13 and no
migration is added. All previous plugin, worker, ledger, collector, deployment,
rollback and media artifacts remain included.

## Fresh verification

| Layer | Actual result |
|---|---|
| Reference | 853 passed, 23 skipped, 0 failed; 824 unit/mock/offline and 29 actual PostgreSQL WASM passes |
| SQL / synthetic webhook | 8 SQL groups and 15 Node groups passed |
| PR / nightly mutation | 12/12 and 20/20 assertion kills, no other outcomes |
| Nightly property | 46 passes, overlapping reference coverage |
| Quality / quickstart | Ruff, gradual strict mypy, pip check and isolated quickstart passed |
| Clean installed wheel | Two Alerta entrypoints load; 13 runtime modules match source; CLI help and inert config-check pass |
| Dependencies / scans | 58 exact Python pins, zero known advisories or skips; npm zero vulnerabilities; final source/Git Gitleaks zero findings |
| SBOM / export | 61-component CycloneDX 1.6 structural validation; public audit zero findings on 301 selected files |
| Artifacts | Paired builds byte-identical; wheel/source/sdist/guidance verified; restored bundle matches all 301 source files including evidence and executable modes; 13 SQL manifest hashes match |
| Native / real Zabbix / full service pipeline | NOT_RUN in this restarted workspace; explicit unavailable records replace no historical truth |

The final evidence-bound attempt is `a14-reference-03`. The first attempt's two
strict audit-fixture failures and the superseded second successful attempt are
retained. Adding mandatory guidance files to the audit's required-file list
fixed the actual fixture problem without weakening its checks. Version/template
corrections changed the harness and triggered fresh runs. Later instruction/prose
feedback changed only separately fingerprinted guidance and documentation, so
builds and artifact verification were repeated without relabelling prior tests.

## Independent qualitative tasks

| Task | Observed outcome |
|---|---|
| E1 documentation typo | Corrected one seeded spelling error, verified page links/paths/Bash syntax; only README changed |
| E2 customer-scope regression | Seeded defect first produced 14 failures/122 passes; focused repair produced 136 passes; no patch adopted into the already-correct candidate runtime |
| E3 evidence review | Correctly rejected twelve stale records and preserved all 307 input files; found inherited release status requiring correction |
| E4 interrupted run | Preserved synthetic RUNNING bytes, created a fresh quality run, changed only quality evidence, and distinguished process evidence from native cleanup |
| E5 artifact review | Verified supplied artifact/source/guidance bytes; found a stale attestation example and implicit read-only scope; both corrected, with same-reviewer follow-up passing on all 306 final input files |

Exact requests, input hashes, reports and parent checks are retained. E1–E4 used
recorded intermediate inputs; E5 has separately identified initial/final sets.
These are qualitative forward-tests, not a statistical model or speed benchmark.
No model API or alert-to-model pipeline was added. Skill files being packaged does
not prove a host automatically discovers them after a ZIP upload.

## Remaining limits

G1–G8, A2 transport remediation and the ten publication-owner inputs remain
open. Native PostgreSQL/PgBouncer, real Zabbix and the complete installed-wheel
service path were not run for a14; supplied a13 native 42 / real 6 / pipeline 4
records stay historical inside its exact archive. Hosted CI/CodeQL, Compose,
signed attestation issuance and independent external security review are not
established. Production examples stay disabled with empty cohorts/endpoints.

The supplied website and screenshots retain their original labels and bytes;
no live site update occurred. The consolidated input register, deployment and
non-destructive rollback instructions are included. No source was pushed and no
production access, migration, acknowledgement, notification, restart or
credential change was performed.

The expanded handoff scan returned exit 1 with fourteen generic-key matches in
input/source hash maps. Every match was independently recomputed as the SHA-256
of `docs/PYTHON_API.md` or `docs/sql_api.md`; all fourteen are file digests, with
zero confirmed secrets or unresolved findings. No broad suppression was added.
This reviewed outcome is distinct from the zero-finding current source/Git scans;
see `packet-secret-scan.json`. Nested historical ZIPs are preserved as supplied,
not recursively scanned by the expanded-directory invocation.
