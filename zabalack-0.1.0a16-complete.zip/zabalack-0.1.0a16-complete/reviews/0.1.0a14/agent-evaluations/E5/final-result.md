# E5 — same reviewer's bounded follow-up

**PASS: the revised 0.1.0a14 artifacts match the supplied final source and guidance; both original findings are addressed.** No remaining concrete inconsistency was found within this follow-up's scope. This is a follow-up by the original E5 reviewer, not another independent experiment.

## Scope and execution

Reviewed only `<workspace>/evaluations/E5/final-source` and its `../final-input.json`, ID `E5-followup`, created `2026-09-13T13:40:05.864449+00:00`. The metadata declares base commit `c2b7fb58ebbf4ba4523bc43584467cfd35b0fb34`; Git identity was not verified in this archive copy.

Read the final copy's root `AGENTS.md`, revised release-review skill, and corrected consumer-verification example. The previously inspected `verify_release.py`, `public_audit.py`, `agent_guidance.py`, and `evidence_utils.py` have unchanged SHA-256 values. Used the supplied Python 3.12.14 with the following prefix for every Python invocation, abbreviated as `PY` below:

```bash
env TZ=UTC PYTHONPATH=<workspace>/evaluations/E5/final-source/src:<workspace>/evaluations/E5/final-source/tools <workspace>/venv/bin/python -B
```

| Actual command/check | Observed result |
|---|---|
| `PY tools/verify_release.py` | Exit 0; `PASS`, `unsigned_release_consistency`, version `0.1.0a14`, `signed_attestation: false`, `ci_context: null`. |
| `PY tools/public_audit.py` | Exit 0; `PASS`, 301 selected files, no findings; publication unauthorized and deployment gates pending. No report-writing flag was used. |
| `PY - <<'PY'` — SHA-256 comparison of all final-copy files with `final-input.json` | Exit 0; all 306 paths/hashes matched exactly, with no missing, changed, or extra files. |
| `PY - <<'PY'` — in-memory ZIP/tar inspection and direct public-file comparison | Exit 0; source ZIP's 301 files equalled the complete public selection, including all 33 evidence files. Sdist contained 308 regular files; wheel contained 20 files. |
| Same inline archive inspection: `code_digests(root)`, `agent_guidance.inspect(root)`, and per-guidance-file hashes | Source/harness and the complete 16-file guidance manifest equalled final-input metadata and build provenance. Every guidance file matched both source ZIP and sdist. Wheel contained no agent guidance. |

The additional direct source comparison included `evidence/`, which the default local verifier omits from its checkout-equality check. No archive member was extracted or executed.

## Verified final identities

| Subject | SHA-256 |
|---|---|
| `dist/BUILD_PROVENANCE.json` | `c58091e904ea5390046629d8f3c1f703c054b1aae6a5ae3f1407b08014d3ca75` |
| `dist/pypi/zabalack-0.1.0a14-py3-none-any.whl` | `e0c27cdfce7821fc15263e0aa3d88d4616bc4d9e72f432d414c2b9d201b91840` |
| `dist/pypi/zabalack-0.1.0a14.tar.gz` | `1624bbbcb36b461ca0ffa4aa8777c764f75aff1c2440721c24276a6dd1aa4c88` |
| `dist/zabalack-0.1.0a14-source.zip` | `dcb28cb283ef85dfd775cec4325f687e001dd739b618228dca372e10b724464e` |

- Source: `be456613206164e76fd39da875abc455844d1581ad76bacfe235021e5ef8652a`.
- Harness: `d67e766c4b25a4a075c4a2f1bab66e7f50439a3924bc7270cdefa96842fb3f46`.
- Revised guidance: `620305b58a16c104d6d925e7a02d2730a793342bede1f0e92fea1c6bb7d0b32b`.

## Resolution of the original findings

| Original finding | Follow-up observation |
|---|---|
| Stale a13 attestation command | Addressed. `docs/release-provenance.md` now uses `dist/pypi/zabalack-0.1.0a14-py3-none-any.whl` and `refs/tags/v0.1.0a14`. The referenced wheel exists in this artifact set. The corrected document matches both source archives. The attestation command itself was not executed. |
| Release-review skill ambiguous for inspection-only work | Addressed. The skill now explicitly instructs read-only verification and findings for inspection-only requests, prohibits tests/rebuilds/repairs/replacement records/release ZIP creation outside requested scope, and limits subsequent preparation steps to candidate exports. This resolves the prior workflow ambiguity. The revised skill is included in the updated guidance manifest and both source archives. |

## Limits and preservation

This follow-up did not rerun the broad evidence analysis in the initial `result.md`. It establishes local consistency of supplied bytes and the two specific guidance fixes. It does not independently reproduce paired builds, execute test suites, prove recorded test execution, verify signatures or hosted CI, authenticate publisher/commit ownership, or close unavailable service and deployment gates. The public audit still reports `MANUAL_GATE_PENDING` and `publication_authorized: false`.

No rebuilds, tests, services, network access, dependency changes, publication, source/evidence writes, or changes to the original E5 source/report were performed. The only new output is this `final-result.md` outside both source copies. A final complete path/hash check confirmed that all 306 final-source files still exactly match `final-input.json`.
