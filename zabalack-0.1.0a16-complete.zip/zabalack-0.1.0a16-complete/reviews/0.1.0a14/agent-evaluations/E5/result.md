# E5 — independent read-only release artifact review

**Result: PASS for unsigned release byte/source/guidance consistency of 0.1.0a14.** The supplied artifacts and evidence are internally consistent with the supplied source copy. This is an inspection of existing bytes and recorded results, not a fresh build, test-suite execution, authenticated provenance check, or deployment approval. One stale documentation command and a minor skill scope ambiguity are noted below.

## Scope and environment

- Request: use the release-review skill to verify the provided built artifacts, including source/guidance consistency; do not rebuild, start services, modify source/evidence, or publish.
- Working directory: `<workspace>/evaluations/E5/source`.
- Input metadata: `../input.json`, ID `E5`, created `2026-09-13T13:31:38.772584+00:00`, declared base commit `7de183946b33ae08372055dd77b2b2b455b0389b`, working-tree overlay true. The commit identity cannot be verified from this copy because it has no Git metadata.
- Read `AGENTS.md`, `.agents/skills/zabalack-release-review/SKILL.md`, `docs/RELEASING.md`, `docs/agent-workflows.md`, `docs/release-provenance.md`, relevant release-tool implementations, and supplied evidence/limit registers. A recursive search found only the root `AGENTS.md`.
- Python: supplied `<workspace>/venv/bin/python`, observed version `3.12.14`; every Python invocation used `-B`, `TZ=UTC`, and this copy's `src` and `tools` on `PYTHONPATH`.
- No dependency installation/change, network access, service startup, test execution, archive extraction, build, publication, or source/evidence write was performed. This report is the sole output outside `source`.

## Actual commands and results

All Python commands used this exact prefix, abbreviated below as `PY`:

```bash
env TZ=UTC PYTHONPATH=<workspace>/evaluations/E5/source/src:<workspace>/evaluations/E5/source/tools <workspace>/venv/bin/python -B
```

| Actual invocation | Exit/result |
|---|---|
| `PY tools/verify_release.py` | Exit 0; `status: PASS`, `scope: unsigned_release_consistency`, `version: 0.1.0a14`, `signed_attestation: false`, `ci_context: null`; four checked subjects listed below. No `--candidate` staging path was invoked. |
| `PY tools/public_audit.py` | Exit 0; `status: PASS`, `file_count: 300`, `findings: []`, `publication_authorized: false`, `deployment_gates: MANUAL_GATE_PENDING`. No report-writing option was used. |
| `PY - <<'PY'` — inline input hash and guidance inspection | Exit 0; all 305 paths from `input.json` existed and matched their SHA-256; no mismatches. `code_digests(Path.cwd())` matched metadata. `agent_guidance.inspect(Path.cwd())` passed and its complete 16-file manifest equalled metadata. |
| `PY - <<'PY'` — inline archive inspection using `safe_bytes`, `zip_contents`, `tar_contents`, and `public_files` | Exit 0; source ZIP had 300 files and equalled the complete 300-file public selection, including evidence; no missing, extra, or changed members. Sdist had 307 regular files; wheel had 20 files. All 16 guidance files had matching hashes in source ZIP and sdist. Wheel contained no agent guidance. |
| `PY - <<'PY'` — inline JSON/JUnit inspection using `json`, `Counter`, and `evidence_utils.cases` | Exit 0; phase JUnit totals, per-layer totals, combined WASM report, and `test-summary.json` agreed; details below. All 13 top-level JSON evidence records carrying `code_digests` matched current source/harness. |
| `PY - <<'PY'` — final inline complete path/hash comparison | Exit 0; at `2026-09-13T13:35:03.289607+00:00`, all 305 source paths and hashes equalled `input.json`; unexpected, missing, and changed lists were empty. |
| `rg -n '0\.1\.0a13\|0\.1\.0a14\|verify_release\|verify_attestation\|focused review\|build twice\|Run the candidate\|clean checkout' .agents/skills/zabalack-release-review/SKILL.md docs/RELEASING.md docs/release-provenance.md docs/agent-workflows.md` | Exit 0; found the stale a13 attestation example at `docs/release-provenance.md:80,82`, while `docs/RELEASING.md:3,92` names a14. An inline `Path.exists()` check confirmed the example's a13 wheel is absent. |

The inline diagnostics used these exact comparison operations (outputs above):

```python
# Input identity and final preservation check
actual = {path.relative_to(root).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
          for path in root.rglob('*') if path.is_file()}
actual == metadata['files']
code_digests(root) == metadata['code_digests']
inspect(root) == metadata['guidance']

# Additional evidence-inclusive check, beyond the default verifier's checkout comparison
selected = {path.relative_to(root).as_posix(): path.read_bytes() for path in public_files(root)}
source == selected
{name: data for name, data in source.items() if name.startswith('evidence/')} == evidence

# Combined WASM evidence compared with its component phase reports
normalise = lambda rows: sorted((row['nodeid'], row['status']) for row in rows)
normalise(combined) == normalise(components)
```

`source` was the checked source ZIP's member mapping after removing its `zabalack-0.1.0a14/` prefix; `evidence` was the evidence subset of `selected`. The regular archive parsers read members in memory, without extracting or executing them.

## Artifact and guidance findings

| Subject | SHA-256 verified against supplied bytes, checksum list, and metadata |
|---|---|
| `dist/BUILD_PROVENANCE.json` | `7218715df7f754bf4c48dfdfcc7478567d46ed1cc508cd693333c3f45de9f5fa` |
| `dist/pypi/zabalack-0.1.0a14-py3-none-any.whl` | `e0c27cdfce7821fc15263e0aa3d88d4616bc4d9e72f432d414c2b9d201b91840` |
| `dist/pypi/zabalack-0.1.0a14.tar.gz` | `8bb0e6045e028747b0e1045b8308b29e2dbc5699892cf10ee625434bd955f962` |
| `dist/zabalack-0.1.0a14-source.zip` | `b79a897069179b6cfe04d084f37bd619336a4247d9fa3816a9c698424ef5c548` |

- Source digest: `be456613206164e76fd39da875abc455844d1581ad76bacfe235021e5ef8652a`.
- Harness digest: `d67e766c4b25a4a075c4a2f1bab66e7f50439a3924bc7270cdefa96842fb3f46`.
- Separate guidance digest: `5aaf8d5e031467ad381330514878f2fdebc8494748867279a538b63b6c5c21df`, covering 16 files, including all three skill entrypoints and evaluation cases. Skill frontmatter and selected local references passed `agent_guidance.inspect`.
- These values matched `input.json`, `BUILD_PROVENANCE.json`, and the supplied source. Each guidance file also matched source ZIP and sdist contents.
- The successful release verifier checked archive member safety/bounds, exact non-evidence source selection, sdist content/generated metadata, wheel runtime code, package identity/version, Python/dependency constraints, extras, entry points, licences, layout, and RECORD hashes/sizes against the supplied project. No inconsistency was reported.
- The default local verifier omits `evidence/` from its source-to-checkout equality check. The additional direct comparison explicitly included all 32 public evidence files and found exact equality; the sdist-to-source verifier comparison also covered them. This closes that local comparison gap for this supplied set without asserting fresh CI authenticity.
- The targeted public audit passed SQL-manifest, current applicable evidence-binding/mutation validation, guidance validity, inert defaults, required files, and common-secret checks. Its stated scope remains limited; this is not an exhaustive security or legal audit.

## Recorded evidence and remaining limitations

These are checks of supplied records, not test results newly executed by E5:

| Supplied evidence | Inspection result and limit |
|---|---|
| Reference JUnit | 853 passed / 23 skipped / 0 failed. Unit/mock: 824 passes. PostgreSQL WASM: 29 passes and 4 skips. Optional native/real-source selection: 19 skips. Phase counts and `test-summary.json` match; the combined WASM report equals its four component reports by test identity/status. |
| Mutation PR / nightly | Both records report PASS, with 12/12 and 20/20 assertion kills, respectively; no survivors, invalid cases, errors, timeouts, or NOT_RUN mutations. Public-audit validation passed. Profiles overlap and must not be added to reference totals. |
| Property nightly / quality | Property JUnit has 46 passes, overlapping reference coverage. Quality record reports Ruff, mypy, and pip-check PASS. These records match current digests; their commands were not rerun here. |
| Native / real Zabbix / deployment E2E | Explicit NOT_RUN. Native reason: Docker Compose unavailable. Real Zabbix: `operator_declared_unavailable`. Deployment E2E: `local_docker_unavailable_or_refused`. No new native permission, concurrency, PgBouncer, real-source, or full installed-wheel service evidence was obtained. |
| Acceptance | 40 rows, all deployment results `MANUAL_GATE_PENDING`; reference results are 38 PASS and 2 MANUAL_GATE_PENDING. G1–G8 CSV entries remain planned / NOT_VERIFIED. Amendment A2 remains unresolved according to the supplied input register/report. |
| Security / SBOM | Supplied scanner record reports successful known-advisory/secret scans and source/harness binding; external independent security review is PENDING and hosted security workflows NOT_RUN. The historical Git scan cannot be independently checked in this Git-free archive copy. SBOM validation claims structural schema validation only, with no licence/security clearance. No scanner or online advisory lookup was rerun. |
| Build provenance | The manifest's three `two_builds_byte_identical: true` entries agree with current subject hashes. No rebuild was permitted, so E5 did not independently observe those earlier paired builds or cross-platform reproducibility. Local checksums/provenance are unsigned and do not authenticate a publisher. |
| Hosted provenance and publication | `ci_context` is null. No current-run hosted CI candidate validation, signature verification, attestation issuance, tag verification, or public upload was performed. Supplied guidance reports hosted issuance/cryptographic verification NOT_RUN. |

All 13 inspected JSON evidence records that contain top-level `code_digests` match the supplied tree: acceptance, deployment E2E, local validation, both mutation profiles plus latest pointer, native, property nightly, quality, real Zabbix, reference, WASM SQL, and security scans. A matching digest binds a record's declared inputs; it does not independently prove execution or correctness of the author-written record.

`publication_inputs(root)` returned ten missing requirements: repository URL, package owner, primary/backup maintainers, private conduct contact, verified private security reporting, approved copyright/third-party review, approved public-content review, confirmed PyPI namespace, and publication authorization. Production examples remain disabled with empty cohorts/endpoints as checked by the public audit.

The complete handoff's website, historical a13 archive, earlier attempts, independent review packet, and final verification file are referenced by supplied documentation but are not part of this source/artifact inspection scope. Their existence/content and historical claimed passes were not independently verified here. Guidance byte consistency is not an agent-quality measurement or proof of automatic host discovery.

## Observed instruction/documentation issues

1. **Stale executable attestation example (minor):** `docs/release-provenance.md:80,82` still uses `zabalack-0.1.0a13-py3-none-any.whl` and `refs/tags/v0.1.0a13`; this candidate supplies only a14 release subjects and the referenced a13 wheel path does not exist. The current release guide names a14. This is a maintained-example issue, not a source/archive byte mismatch; the same stale document is consistently packaged. It was not edited, and the attestation command was not run.
2. **Read-only review scope is implicit in the skill (minor ambiguity):** the skill description includes artifact reviews, but its body also instructs running available gates, repairing failures, recording unavailable layers, and returning an export ZIP. Those actions would violate this task's explicit inspection-only boundary. I applied the user's scope and the focused-review provision in `docs/agent-workflows.md:99–102`, kept existing NOT_RUN records untouched, and returned this review rather than rebuilding or generating replacement evidence. No additional authorization was needed to complete the requested read-only work.

The final source preservation check found exactly the original 305 files with identical hashes. No evidence limitation was promoted to a pass.
