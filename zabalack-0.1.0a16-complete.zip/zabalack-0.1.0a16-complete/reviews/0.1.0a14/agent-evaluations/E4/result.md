E4 independent repository-guidance forward-test

Completed a fresh quality phase in `<workspace>/a14-work/evaluations/E4/source`. Followed `AGENTS.md`, `.agents/skills/zabalack-isolated-lab/SKILL.md`, `docs/agent-workflows.md`, `docs/local-services.md`, and the quality runner's implementation. No other evaluation directory or prior conversation was read. No source, harness, pins or shared virtual environment was modified. No service was started or stopped, and no remote operation/publication/production action was performed.

| Attempt | Identity | Result | Cleanup evidence |
|---|---|---|---|
| Existing interrupted fixture | `interrupted-synthetic` | Preserved as `RUNNING`; quality phase remains `RUNNING` | Record explicitly says `synthetic interrupted record; no process was launched`; there is no cleanup field, PID, command, source/harness digest or owner service identity to retrofit |
| Fresh quality review | `e4-quality-recovery` | `PASS`, exit 0; 3 checks passed, 0 failed, 0 skipped | Wrapper records `CHILD_MANAGED`, `interrupted: false`; review lock is available after execution |

Fresh run: 2026-09-13T13:16:16.419616+00:00 through 2026-09-13T13:16:20.444166+00:00; quality child duration 3988 ms. Ruff: “All checks passed!”; mypy: “Success: no issues found in 4 source files”; pip check: “No broken requirements found.” No pytest tests ran. These are static/dependency results; unit/mock, PostgreSQL WASM, native PostgreSQL/PgBouncer, real Zabbix, installed-wheel services, Docker and deployment were not newly exercised. G1–G8 and amendment A2 remain pending.

The old run directory still contains its original sole file. Its 238 bytes, modification time and file set match preflight exactly. SHA256: `766e8277d2a308cd86224331016e0a96b97b8c5ba974c3c98d0c83f71bcf1661`. It was neither overwritten nor reclassified, and no current-tree digests were inserted into it.

The new source digest is `be456613206164e76fd39da875abc455844d1581ad76bacfe235021e5ef8652a`; harness digest is `54e07ac136bcf9e95fb76ceef3504189c1467bc2385ffe4c7cc00ac5b103315c`. Both match preflight and postflight. Only `evidence/quality-run.json` changed among the 39 original evidence files; the other 38, including acceptance and service records, retain their exact hashes and metadata. The fresh retained snapshot is `build/review-runs/e4-quality-recovery/quality/evidence/quality-run.json`, SHA256 `813bb2c69844154d852cb4856bcf3bb86299f1cadedfab5347d1fbe6ee122a27`, matching the conventional quality record and the new run's snapshot entry. New runner output is `build/review-runs/e4-quality-recovery/run.json` and its `quality/output.log`; per-tool logs/caches are under `build/quality/`. The cooperative lock inode remains at `build/review-locks/review.lock`, as designed.

Cleanup actually established: this task executed only three synchronous quality commands. The old fixture says no process was ever launched. There is no `.lab` or `build/private` directory. A postflight `/proc` check, limited to processes whose cwd/command identify this checkout and excluding this inspector's host-namespace ancestor chain, found no matching processes. Twenty inaccessible/exited process entries were excluded, so this is a scoped observation, not proof of all-host or detached-service cleanup. The lock can be acquired nonblocking. No owning native-service cleanup record or exact service instance exists here to verify; no native-service cleanup PASS is claimed. No blind kill/resume occurred.

Execution used `/bin/bash` with `login=false`. Every command after the initial read sets `TZ=UTC`; the runner also forces UTC. All Python invocations used the supplied `<workspace>/a14-work/venv/bin/python` with `PYTHONPATH` set to this copy's `src`; import discovery confirmed this copy's `src/zabalack/__init__.py`. No install or environment modification was performed.

Two inspection details are retained rather than hidden: (1) the first process scan used namespace-local PIDs against host `/proc` and therefore included its own supervisor, shell and Python inspector; postflight corrected this using `/proc/self`'s host PID and excluded their ancestor chain. (2) the first postflight assertion exited 1 because passing a nanosecond timestamp through JavaScript JSON parsing rounded the 64-bit integer. The original byte hash already matched. The repeated verifier used the original raw JSON, preserved integer precision, and exited 0 with all assertions passing. These were inspection issues; the quality run itself executed once and passed.

Actual commands and results follow. Commands ran with cwd equal to the E4 source path and the shell options above. Read-command outputs are summarized; execution and verification output is retained below.

Read/discovery 1, exit 0:

```bash
pwd && rg --files -g AGENTS.md -g SKILL.md -g '!**/.git/**' .agents 2>/dev/null && cat AGENTS.md && cat .agents/skills/zabalack-isolated-lab/SKILL.md
```

Read AGENTS.md and the isolated-lab skill; first discovery shell omitted an explicit TZ assignment. All subsequent commands set TZ=UTC.

Read/discovery 2, exit 0:

```bash
TZ=UTC cat docs/agent-workflows.md docs/local-services.md
```

Read the retained-run, interruption, cleanup and local-service guidance.

Read/discovery 3, exit 128:

```bash
TZ=UTC git status --short && TZ=UTC rg --files -g '!**/.git/**' -g '*run*' -g '*review*' -g '*quality*' -g '*result*' -g '*.json' -g '*.jsonl' -g '*manifest*' -g '*cleanup*' .
```

fatal: not a git repository (or any of the parent directories): .git; chained discovery did not run.

Read/discovery 4, exit 0:

```bash
TZ=UTC rg --files --hidden -g '!**/.git/**' -g '!**/node_modules/**' -g '!**/.venv/**' -g '*run*' -g '*review*' -g '*quality*' -g '*result*' -g '*.json' -g '*.jsonl' -g '*manifest*' -g '*cleanup*' .
```

Discovered the review/quality runners and conventional evidence records. Normal rg ignored build output.

Read/discovery 5, exit 2:

```bash
TZ=UTC sed -n '1,280p' tools/run_review.py && TZ=UTC sed -n '1,260p' tools/quality_gate.py && TZ=UTC ls -la build/review-runs
```

Read run_review.py; tools/quality_gate.py does not exist. Trailing ls did not run. Correct runner is tools/run_quality.py.

Read/discovery 6, exit 0:

```bash
TZ=UTC cat tools/run_quality.py tools/review_runs.py docs/quality-checks.md
```

Read exact quality checks, tool pin validation, single-use run directories, cooperative locks, and quality scope.

Read/discovery 7, exit 2:

```bash
TZ=UTC ls -la build/review-runs && TZ=UTC rg --files --hidden --no-ignore build/review-runs .lab build/private -g '!**/node_modules/**'
```

Found only build/review-runs/interrupted-synthetic/run.json. .lab and build/private did not exist.

Read/discovery 8, exit 0:

```bash
TZ=UTC cat build/review-runs/interrupted-synthetic/run.json && TZ=UTC cat evidence/quality-run.json && TZ=UTC cat tools/evidence_utils.py
```

Old run: RUNNING, fixture says no process launched, quality phase RUNNING. Conventional quality record predates this evaluation (2026-09-12T17:55:47.443305+00:00); its old digests were not attributed to this tree. Read the source/harness digest implementation.

Read/discovery 9, exit 0:

```bash
TZ=UTC PYTHONPATH=<workspace>/a14-work/evaluations/E4/source/src <workspace>/a14-work/venv/bin/python - <<'PY'
import importlib.metadata
import json
from pathlib import Path
import sys
root = Path.cwd()
print(json.dumps({'python_executable':sys.executable,'python_version':sys.version,'tools':{name:importlib.metadata.version(name) for name in ('ruff','mypy','hypothesis')}}))
print(json.dumps({'build_files':[str(path.relative_to(root)) for path in sorted((root/'build').rglob('*')) if path.is_file()]}))
PY
```

Python 3.12.14, Ruff 0.16.7, mypy 2.3.1, Hypothesis 6.168.0. Initially build contained only the interrupted run.json.

Recorded command 1: Preflight byte preservation, source/import identity and scoped process inspection; exit 0.

```bash
TZ=UTC PYTHONPATH=<workspace>/a14-work/evaluations/E4/source/src <workspace>/a14-work/venv/bin/python - <<'PY'
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
root = Path.cwd()
sys.path.insert(0, str(root / 'tools'))
from evidence_utils import code_digests
old = root / 'build/review-runs/interrupted-synthetic'
def files_snapshot(directory):
    return {str(path.relative_to(root)): {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'size': path.stat().st_size, 'mtime_ns': path.stat().st_mtime_ns} for path in sorted(directory.rglob('*')) if path.is_file()}
ancestors = {os.getpid()}
current = os.getppid()
while current > 0 and current not in ancestors:
    ancestors.add(current)
    try:
        stat = (Path('/proc') / str(current) / 'stat').read_text()
        current = int(stat[stat.rfind(')')+2:].split()[1])
    except (OSError, ValueError, IndexError):
        break
owned_processes = []
inaccessible = 0
for process_dir in Path('/proc').iterdir():
    if not process_dir.name.isdigit() or int(process_dir.name) in ancestors:
        continue
    try:
        cwd = (process_dir/'cwd').resolve(strict=True)
        command = (process_dir/'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace')
        if cwd == root or root in cwd.parents or str(root) in command:
            owned_processes.append({'pid':int(process_dir.name),'cwd':str(cwd),'command':command})
    except (PermissionError, ProcessLookupError, FileNotFoundError):
        inaccessible += 1
snapshot = {'root':str(root),'python_executable':sys.executable,'package_origin':importlib.util.find_spec('zabalack').origin,'old_run_files':files_snapshot(old),'evidence_files':files_snapshot(root/'evidence'),'code_digests':code_digests(root),'cleanup_inspection':{'record_fixture':json.loads((old/'run.json').read_text()).get('fixture'),'lab_directory_exists':(root/'.lab').exists(),'private_directory_exists':(root/'build/private').exists(),'review_lock_exists':(root/'build/review-locks/review.lock').exists(),'checkout_related_processes_excluding_inspector_ancestors':owned_processes,'inaccessible_or_exited_proc_entries':inaccessible}}
print(json.dumps(snapshot, indent=2))
PY
```

Output excerpt (own command lines summarized; file metadata retained):

```text
{
  "root": "<workspace>/a14-work/evaluations/E4/source",
  "python_executable": "<workspace>/a14-work/venv/bin/python",
  "package_origin": "<workspace>/a14-work/evaluations/E4/source/src/zabalack/__init__.py",
  "old_run_files": {
    "build/review-runs/interrupted-synthetic/run.json": {
      "sha256": "766e8277d2a308cd86224331016e0a96b97b8c5ba974c3c98d0c83f71bcf1661",
      "size": 238,
      "mtime_ns": 1789305207232800046
    }
  },
  "evidence_files": {
    "evidence/README.md": {
      "sha256": "1871b01e385fbca5168b1ca42d89a165955c3e25db3cf5afd2e1ab27606f0759",
      "size": 1730,
      "mtime_ns": 1789305173000000000
    },
    "evidence/acceptance-results.json": {
      "sha256": "5508be85aab48a499ecd6567987009a770fe86e4a9e42d4dceecc2516bde98df",
      "size": 330242,
      "mtime_ns": 1789305173000000000
    },
    "evidence/acceptance-results.md": {
      "sha256": "4c7daaf8320405f41e539def22be69a1846635b1dc0554cf48d4082ca17803ce",
      "size": 2541,
      "mtime_ns": 1789305173000000000
    },
    "evidence/alerta-persistence-wasm.xml": {
      "sha256": "996b660d9f2c01d43d36cd95b41431c7f8bf33070971d06022e16ab6b163be36",
      "size": 1734,
      "mtime_ns": 1789305173000000000
    },
    "evidence/batch-200-supplemental.json": {
      "sha256": "8bd6e2203ea5d17812f70c86d99da6085f076617b7519ccd0a8be1a41deb7ee9",
      "size": 1694,
      "mtime_ns": 1789305173000000000
    },
    "evidence/batch-50-supplemental.json": {
      "sha256": "168c0c2191f800f193814efc69b2bfef51cb54708be207d4b88acf46e21cc5b7",
      "size": 1682,
      "mtime_ns": 1789305173000000000
    },
    "evidence/collection-check.json": {
      "sha256": "46348077dfc167a000031aef8079adab882a22c8aa3aed07073b1e2d989d6e67",
      "size": 387,
      "mtime_ns": 1789305173000000000
    },
    "evidence/dependency-review.json": {
      "sha256": "73799e9e959eba522666107322cc70f7941bc785ee632bfa53fc7b4cf2ea2a7e",
      "size": 281,
      "mtime_ns": 1789305173000000000
    },
    "evidence/deployment-e2e-run.json": {
      "sha256": "f6ffddbb376496d88602b2c18042bc8f47c7b2d5eb4e622cd00a904273938c48",
      "size": 2666,
      "mtime_ns": 1789305173000000000
    },
    "evidence/local-validation.json": {
      "sha256": "9c0235b5fc9c5674b92677336088edf054b3550184b21543a73d19be608eb3ee",
      "size": 1078,
      "mtime_ns": 1789305173000000000
    },
    "evidence/mutation-pr.json": {
      "sha256": "80e2d077fb9c00ac5f82047f53453b8fbf28b36b5d500698d524aa0f7cd4474a",
      "size": 4943,
      "mtime_ns": 1789305173000000000
    },
    "evidence/mutation-run.json": {
      "sha256": "8c9747f2256f21f231f5e0c96ee7a3cd727aca7383df7a8cb21d41a67afe52cd",
      "size": 7644,
      "mtime_ns": 1789305173000000000
    },
    "evidence/native-alerta.xml": {
      "sha256": "90861b00df1ff1988b00fe34f34aee99ee0cb1507987b9ecc4d9631c9706848f",
      "size": 1256,
      "mtime_ns": 1789305173000000000
    },
    "evidence/native-delivery_faults.xml": {
      "sha256": "e90c94d01a210756f7f1b5aee2acc2f50c98770d0c635ce02a4fa9b5d29d093b",
      "size": 984,
      "mtime_ns": 1789305173000000000
    },
    "evidence/native-performance.xml": {
      "sha256": "9b3ab9975e59c1e5138c5b408e923e8f4dcfb502abf6ae91516892b5a55ee133",
      "size": 1050,
      "mtime_ns": 1789305173000000000
    },
    "evidence/native-postgres.xml": {
      "sha256": "23f87e0298c4ec23b6dfcaefa8a0170ea41f50a837f0cf9aa8789ae990e2307f",
      "size": 5684,
      "mtime_ns": 1789305173000000000
    },
    "evidence/native-run.json": {
      "sha256": "fae2a9121ebf7e7e1e19bd3075121da4ec314a57e4e587e1ddbdfa9bb8128d82",
      "size": 2938,
      "mtime_ns": 1789305173000000000
    },
    "evidence/native-worker.xml": {
      "sha256": "6ace7f50e00a1935908154b2a474e8af66ef6c88208adb96ff8cb7f118e2c18e",
      "size": 771,
      "mtime_ns": 1789305173000000000
    },
    "evidence/npm-audit.json": {
      "sha256": "12931fe186a1d5341d0bd56a90726249c7208945f5b9168701ba8b1af5ce8dc3",
      "size": 358,
      "mtime_ns": 1789305173000000000
    },
    "evidence/optional-services.xml": {
      "sha256": "5f796aed9900764609d576b022c6510f414ec1d075baa9a62bbda47cb1147d1d",
      "size": 8154,
      "mtime_ns": 1789305173000000000
    },
    "evidence/performance-wasm.xml": {
      "sha256": "8cfcec2792039005ae15c1059b0bd2f2e617d7199ee20bdf38a2aca938bd8ff6",
      "size": 1045,
      "mtime_ns": 1789305173000000000
    },
    "evidence/pip-audit.json": {
      "sha256": "af126be6b0ac90fa3c2ebb05a256e28afd88323f7efd488a87418a657fd64645",
      "size": 3300,
      "mtime_ns": 1789305173000000000
    },
    "evidence/postgres-wasm-combined.xml": {
      "sha256": "255e3c31ced632c12e6351ad9b6acdcdab9501fea276e61c31eefac5d05fa32c",
      "size": 8976,
      "mtime_ns": 1789305173000000000
    },
    "evidence/postgres-wasm.xml": {
      "sha256": "0a2a1ad070980b83aa100295134163f7b6c14e183d988047a2122078737739ee",
      "size": 5698,
      "mtime_ns": 1789305173000000000
    },
    "evidence/property-nightly-run.json": {
      "sha256": "640e940240835dead2d6b2d2b7a496b9f1b579b967cb48a71043e2466d2a20d5",
      "size": 637,
      "mtime_ns": 1789305173000000000
    },
    "evidence/property-nightly.xml": {
      "sha256": "53c8b8d4c5a6697683e9637ca3385faffda38967bec7dce36c9944e69fa5bd90",
      "size": 33995,
      "mtime_ns": 1789305173000000000
    },
    "evidence/public-audit.json": {
      "sha256": "533c4f9147a4e79915e9834469ac5bf466ca972ae3acfb4aeb62ff6ef38ec052",
      "size": 261,
      "mtime_ns": 1789305173000000000
    },
    "evidence/quality-run.json": {
      "sha256": "635a27a3c20e1b749692b346d27cd0483d20f661df10100226f236f36e73e0d2",
      "size": 803,
      "mtime_ns": 1789305173000000000
    },
    "evidence/real-zabbix-run.json": {
      "sha256": "98374f786b9aca5dd686c88f664e89116709084e2296444bdd9bb7c2ddfe4cc6",
      "size": 576,
      "mtime_ns": 1789305173000000000
    },
    "evidence/real-zabbix.xml": {
      "sha256": "0021d63cf77f4074f2cd2f9955f9eb44a27aeee5f566e5d52b2a78a6a7b8026d",
      "size": 1971,
      "mtime_ns": 1789305173000000000
    },
    "evidence/reference-run.json": {
      "sha256": "2120fac7deb541b7985633fc716adb396ffc5f31e60698db376a6495ef1a99db",
      "size": 4482,
      "mtime_ns": 1789305173000000000
    },
    "evidence/runtime_wasm_sql.json": {
      "sha256": "a52c04bad36beda7e0e46b2f83370ffcc143aa5f62d064eb19afb03c5552bb80",
      "size": 3412,
      "mtime_ns": 1789305173000000000
    },
    "evidence/sbom-validation.json": {
      "sha256": "7f88c637e22d75352a7fa4eeb10a6b07c09171b44c926ab581aeff7462472315",
      "size": 271,
      "mtime_ns": 1789305173000000000
    },
    "evidence/sbom.cdx.json": {
      "sha256": "5f0086db92d070950c7ef37412dbd2a2f31fb3f23ef80414524059440b9f13b2",
      "size": 53997,
      "mtime_ns": 1789305173000000000
    },
    "evidence/security-scans.json": {
      "sha256": "0007dced4ad3c1e2acb0769dc7c70f07141abe83b00019b5a26bcbd5415fc527",
      "size": 439,
      "mtime_ns": 1789305173000000000
    },
    "evidence/test-summary.json": {
      "sha256": "3021e737d5888b9440f67cb12ed680d6639b04645e6bbf6d6c9db32b12f400ea",
      "size": 504,
      "mtime_ns": 1789305173000000000
    },
    "evidence/unit-mocked.xml": {
      "sha256": "f5f13c946df4420d230ce72295cc9376a18db8893599755f9a3493d1df2e7d63",
      "size": 144863,
      "mtime_ns": 1789305173000000000
    },
    "evidence/wheel-smoke.json": {
      "sha256": "c3528136d1a837d4c34932db0c3f7c221507a6c70d5d9814e9ac9b3fdc971040",
      "size": 695,
      "mtime_ns": 1789305173000000000
    },
    "evidence/worker-sql-wasm.xml": {
      "sha256": "199954e5cc6c54a466051b440a9ad3a4d9b3627e96c7d9ce021fc36bd27ca6dd",
      "size": 771,
      "mtime_ns": 1789305173000000000
    }
  },
  "code_digests": {
    "source": "be456613206164e76fd39da875abc455844d1581ad76bacfe235021e5ef8652a",
    "harness": "54e07ac136bcf9e95fb76ceef3504189c1467bc2385ffe4c7cc00ac5b103315c"
  },
  "cleanup_inspection": {
    "record_fixture": "synthetic interrupted record; no process was launched",
    "lab_directory_exists": false,
    "private_directory_exists": false,
    "review_lock_exists": false,
    "checkout_related_processes_excluding_inspector_ancestors": [
      {
        "pid": 47011,
        "kind": "this inspection command's codex-linux-sandbox supervisor"
      },
      {
        "pid": 47012,
        "kind": "this inspection command's /bin/bash"
      },
      {
        "pid": 47013,
        "kind": "this inspection command's Python interpreter"
      }
    ],
    "inaccessible_or_exited_proc_entries": 18
  }
}
```

Recorded command 2: Review the sole fresh phase without executing it; exit 0.

```bash
TZ=UTC PYTHONPATH=<workspace>/a14-work/evaluations/E4/source/src <workspace>/a14-work/venv/bin/python tools/run_review.py --plan --phase quality --run-id e4-quality-recovery
```

Output:

```text
{
  "phases": [
    {
      "name": "quality",
      "command": [
        "python",
        "tools/run_quality.py"
      ]
    }
  ]
}
```

Recorded command 3: Execute the authorised fresh quality phase; exit 0.

```bash
TZ=UTC PYTHONPATH=<workspace>/a14-work/evaluations/E4/source/src <workspace>/a14-work/venv/bin/python tools/run_review.py --isolated-lab --phase quality --run-id e4-quality-recovery --timeout 600
```

Output:

```text
{"run_id": "e4-quality-recovery", "phase": "quality", "status": "PASS"}
```

Recorded command 4: Verify retained identity, fresh evidence, exact tool results, source integrity and scoped cleanup; exit 1.

```bash
TZ=UTC PYTHONPATH=<workspace>/a14-work/evaluations/E4/source/src <workspace>/a14-work/venv/bin/python - <<'PY'
import fcntl
import hashlib
import json
import os
from pathlib import Path
import sys
root = Path.cwd()
sys.path.insert(0, str(root / 'tools'))
from evidence_utils import code_digests
baseline = json.loads("{\"old_run_files\":{\"build/review-runs/interrupted-synthetic/run.json\":{\"mtime_ns\":1789305207232800000,\"sha256\":\"766e8277d2a308cd86224331016e0a96b97b8c5ba974c3c98d0c83f71bcf1661\",\"size\":238}},\"evidence_files\":{\"evidence/README.md\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"1871b01e385fbca5168b1ca42d89a165955c3e25db3cf5afd2e1ab27606f0759\",\"size\":1730},\"evidence/acceptance-results.json\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"5508be85aab48a499ecd6567987009a770fe86e4a9e42d4dceecc2516bde98df\",\"size\":330242},\"evidence/acceptance-results.md\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"4c7daaf8320405f41e539def22be69a1846635b1dc0554cf48d4082ca17803ce\",\"size\":2541},\"evidence/alerta-persistence-wasm.xml\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"996b660d9f2c01d43d36cd95b41431c7f8bf33070971d06022e16ab6b163be36\",\"size\":1734},\"evidence/batch-200-supplemental.json\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"8bd6e2203ea5d17812f70c86d99da6085f076617b7519ccd0a8be1a41deb7ee9\",\"size\":1694},\"evidence/batch-50-supplemental.json\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"168c0c2191f800f193814efc69b2bfef51cb54708be207d4b88acf46e21cc5b7\",\"size\":1682},\"evidence/collection-check.json\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"46348077dfc167a000031aef8079adab882a22c8aa3aed07073b1e2d989d6e67\",\"size\":387},\"evidence/dependency-review.json\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"73799e9e959eba522666107322cc70f7941bc785ee632bfa53fc7b4cf2ea2a7e\",\"size\":281},\"evidence/deployment-e2e-run.json\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"f6ffddbb376496d88602b2c18042bc8f47c7b2d5eb4e622cd00a904273938c48\",\"size\":2666},\"evidence/local-validation.json\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"9c0235b5fc9c5674b92677336088edf054b3550184b21543a73d19be608eb3ee\",\"size\":1078},\"evidence/mutation-pr.json\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"80e2d077fb9c00ac5f82047f53453b8fbf28b36b5d500698d524aa0f7cd4474a\",\"size\":4943},\"evidence/mutation-run.json\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"8c9747f2256f21f231f5e0c96ee7a3cd727aca7383df7a8cb21d41a67afe52cd\",\"size\":7644},\"evidence/native-alerta.xml\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"90861b00df1ff1988b00fe34f34aee99ee0cb1507987b9ecc4d9631c9706848f\",\"size\":1256},\"evidence/native-delivery_faults.xml\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"e90c94d01a210756f7f1b5aee2acc2f50c98770d0c635ce02a4fa9b5d29d093b\",\"size\":984},\"evidence/native-performance.xml\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"9b3ab9975e59c1e5138c5b408e923e8f4dcfb502abf6ae91516892b5a55ee133\",\"size\":1050},\"evidence/native-postgres.xml\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"23f87e0298c4ec23b6dfcaefa8a0170ea41f50a837f0cf9aa8789ae990e2307f\",\"size\":5684},\"evidence/native-run.json\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"fae2a9121ebf7e7e1e19bd3075121da4ec314a57e4e587e1ddbdfa9bb8128d82\",\"size\":2938},\"evidence/native-worker.xml\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"6ace7f50e00a1935908154b2a474e8af66ef6c88208adb96ff8cb7f118e2c18e\",\"size\":771},\"evidence/npm-audit.json\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"12931fe186a1d5341d0bd56a90726249c7208945f5b9168701ba8b1af5ce8dc3\",\"size\":358},\"evidence/optional-services.xml\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"5f796aed9900764609d576b022c6510f414ec1d075baa9a62bbda47cb1147d1d\",\"size\":8154},\"evidence/performance-wasm.xml\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"8cfcec2792039005ae15c1059b0bd2f2e617d7199ee20bdf38a2aca938bd8ff6\",\"size\":1045},\"evidence/pip-audit.json\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"af126be6b0ac90fa3c2ebb05a256e28afd88323f7efd488a87418a657fd64645\",\"size\":3300},\"evidence/postgres-wasm-combined.xml\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"255e3c31ced632c12e6351ad9b6acdcdab9501fea276e61c31eefac5d05fa32c\",\"size\":8976},\"evidence/postgres-wasm.xml\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"0a2a1ad070980b83aa100295134163f7b6c14e183d988047a2122078737739ee\",\"size\":5698},\"evidence/property-nightly-run.json\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"640e940240835dead2d6b2d2b7a496b9f1b579b967cb48a71043e2466d2a20d5\",\"size\":637},\"evidence/property-nightly.xml\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"53c8b8d4c5a6697683e9637ca3385faffda38967bec7dce36c9944e69fa5bd90\",\"size\":33995},\"evidence/public-audit.json\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"533c4f9147a4e79915e9834469ac5bf466ca972ae3acfb4aeb62ff6ef38ec052\",\"size\":261},\"evidence/quality-run.json\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"635a27a3c20e1b749692b346d27cd0483d20f661df10100226f236f36e73e0d2\",\"size\":803},\"evidence/real-zabbix-run.json\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"98374f786b9aca5dd686c88f664e89116709084e2296444bdd9bb7c2ddfe4cc6\",\"size\":576},\"evidence/real-zabbix.xml\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"0021d63cf77f4074f2cd2f9955f9eb44a27aeee5f566e5d52b2a78a6a7b8026d\",\"size\":1971},\"evidence/reference-run.json\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"2120fac7deb541b7985633fc716adb396ffc5f31e60698db376a6495ef1a99db\",\"size\":4482},\"evidence/runtime_wasm_sql.json\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"a52c04bad36beda7e0e46b2f83370ffcc143aa5f62d064eb19afb03c5552bb80\",\"size\":3412},\"evidence/sbom-validation.json\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"7f88c637e22d75352a7fa4eeb10a6b07c09171b44c926ab581aeff7462472315\",\"size\":271},\"evidence/sbom.cdx.json\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"5f0086db92d070950c7ef37412dbd2a2f31fb3f23ef80414524059440b9f13b2\",\"size\":53997},\"evidence/security-scans.json\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"0007dced4ad3c1e2acb0769dc7c70f07141abe83b00019b5a26bcbd5415fc527\",\"size\":439},\"evidence/test-summary.json\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"3021e737d5888b9440f67cb12ed680d6639b04645e6bbf6d6c9db32b12f400ea\",\"size\":504},\"evidence/unit-mocked.xml\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"f5f13c946df4420d230ce72295cc9376a18db8893599755f9a3493d1df2e7d63\",\"size\":144863},\"evidence/wheel-smoke.json\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"c3528136d1a837d4c34932db0c3f7c221507a6c70d5d9814e9ac9b3fdc971040\",\"size\":695},\"evidence/worker-sql-wasm.xml\":{\"mtime_ns\":1789305173000000000,\"sha256\":\"199954e5cc6c54a466051b440a9ad3a4d9b3627e96c7d9ce021fc36bd27ca6dd\",\"size\":771}},\"code_digests\":{\"harness\":\"54e07ac136bcf9e95fb76ceef3504189c1467bc2385ffe4c7cc00ac5b103315c\",\"source\":\"be456613206164e76fd39da875abc455844d1581ad76bacfe235021e5ef8652a\"}}")
def files_snapshot(directory):
    return {str(path.relative_to(root)): {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'size': path.stat().st_size, 'mtime_ns': path.stat().st_mtime_ns} for path in sorted(directory.rglob('*')) if path.is_file()}
old = root/'build/review-runs/interrupted-synthetic'
new = root/'build/review-runs/e4-quality-recovery'
run = json.loads((new/'run.json').read_text())
quality = json.loads((root/'evidence/quality-run.json').read_text())
old_record = json.loads((old/'run.json').read_text())
old_equal = files_snapshot(old) == baseline['old_run_files']
after_evidence = files_snapshot(root/'evidence')
changed = [name for name in sorted(baseline['evidence_files'].keys() | after_evidence.keys()) if baseline['evidence_files'].get(name) != after_evidence.get(name)]
ancestors = set()
current = int(Path('/proc/self').resolve(strict=True).name)
while current > 0 and current not in ancestors:
    ancestors.add(current)
    try:
        stat = (Path('/proc') / str(current) / 'stat').read_text()
        current = int(stat[stat.rfind(')')+2:].split()[1])
    except (OSError, ValueError, IndexError):
        break
processes = []
inaccessible = 0
for process_dir in Path('/proc').iterdir():
    if not process_dir.name.isdigit() or int(process_dir.name) in ancestors:
        continue
    try:
        cwd = (process_dir/'cwd').resolve(strict=True)
        command = (process_dir/'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace')
        if cwd == root or root in cwd.parents or str(root) in command:
            processes.append({'pid':int(process_dir.name),'cwd':str(cwd),'name':(process_dir/'comm').read_text().strip()})
    except (PermissionError, ProcessLookupError, FileNotFoundError):
        inaccessible += 1
lock_path = root/'build/review-locks/review.lock'
with lock_path.open('r+') as lock:
    try:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        lock_available = True
        fcntl.flock(lock.fileno(), fcntl.LOCK_UN)
    except BlockingIOError:
        lock_available = False
snapshots = [{'path':row['path'], 'matches_current_evidence':(new/'quality'/row['path']).read_bytes() == (root/row['path']).read_bytes(), 'sha256_matches_record':hashlib.sha256((new/'quality'/row['path']).read_bytes()).hexdigest() == row['sha256']} for row in run['phases'][0]['evidence']]
result = {'old_run_id':old_record['run_id'],'old_run_status':old_record['status'],'old_run_preserved_bytes_metadata_and_file_set':old_equal,'old_run_sha256':files_snapshot(old),'new_run':run,'quality_record':quality,'quality_tool_logs':{name:(root/'build/quality'/f'{name}.log').read_text() for name in ('ruff','mypy','pip-check')},'phase_output_log':(new/'quality/output.log').read_text(),'evidence_changes':changed,'unchanged_evidence_count':len(baseline['evidence_files'])-len(changed),'code_digests_unchanged_from_preflight':code_digests(root)==baseline['code_digests'],'snapshot_verification':snapshots,'cleanup_inspection':{'lab_directory_exists':(root/'.lab').exists(),'private_directory_exists':(root/'build/private').exists(),'checkout_related_processes_excluding_host_namespace_inspector_ancestors':processes,'inaccessible_or_exited_proc_entries':inaccessible,'review_lock_available':lock_available}}
print(json.dumps(result, indent=2))
assert old_equal
assert old_record['status'] == 'RUNNING'
assert changed == ['evidence/quality-run.json']
assert code_digests(root) == baseline['code_digests'] == run['code_digests'] == quality['code_digests']
assert run['status'] == quality['status'] == 'PASS'
assert len(quality['checks']) == 3 and all(row['status']=='PASS' and row['exit_code']==0 for row in quality['checks'])
assert all(row['matches_current_evidence'] and row['sha256_matches_record'] for row in snapshots)
assert len(snapshots) == 1
assert lock_available
PY
```

Output:

```text
Traceback (most recent call last):
  File "<stdin>", line 53, in <module>
AssertionError
{
  "old_run_id": "interrupted-synthetic",
  "old_run_status": "RUNNING",
  "old_run_preserved_bytes_metadata_and_file_set": false,
  "old_run_sha256": {
    "build/review-runs/interrupted-synthetic/run.json": {
      "sha256": "766e8277d2a308cd86224331016e0a96b97b8c5ba974c3c98d0c83f71bcf1661",
      "size": 238,
      "mtime_ns": 1789305207232800046
    }
  },
  "new_run": {
    "schema_version": 1,
    "run_id": "e4-quality-recovery",
    "status": "PASS",
    "started_at_utc": "2026-09-13T13:16:16.419616+00:00",
    "code_digests": {
      "source": "be456613206164e76fd39da875abc455844d1581ad76bacfe235021e5ef8652a",
      "harness": "54e07ac136bcf9e95fb76ceef3504189c1467bc2385ffe4c7cc00ac5b103315c"
    },
    "phases": [
      {
        "name": "quality",
        "status": "PASS",
        "command": [
          "python",
          "tools/run_quality.py"
        ],
        "started_at_utc": "2026-09-13T13:16:16.421897+00:00",
        "code_digests": {
          "source": "be456613206164e76fd39da875abc455844d1581ad76bacfe235021e5ef8652a",
          "harness": "54e07ac136bcf9e95fb76ceef3504189c1467bc2385ffe4c7cc00ac5b103315c"
        },
        "exit_code": 0,
        "interrupted": false,
        "cleanup": "CHILD_MANAGED",
        "duration_ms": 3988,
        "finished_at_utc": "2026-09-13T13:16:20.424058+00:00",
        "tree_unchanged": true,
        "evidence": [
          {
            "path": "evidence/quality-run.json",
            "sha256": "813bb2c69844154d852cb4856bcf3bb86299f1cadedfab5347d1fbe6ee122a27"
          }
        ]
      }
    ],
    "scope": "Local phase execution; per-phase evidence defines its coverage; G1-G8 pending",
    "finished_at_utc": "2026-09-13T13:16:20.444166+00:00",
    "tree_unchanged": true
  },
  "quality_record": {
    "status": "PASS",
    "checks": [
      {
        "name": "ruff",
        "exit_code": 0,
        "status": "PASS"
      },
      {
        "name": "mypy",
        "exit_code": 0,
        "status": "PASS"
      },
      {
        "name": "pip-check",
        "exit_code": 0,
        "status": "PASS"
      }
    ],
    "code_digests": {
      "source": "be456613206164e76fd39da875abc455844d1581ad76bacfe235021e5ef8652a",
      "harness": "54e07ac136bcf9e95fb76ceef3504189c1467bc2385ffe4c7cc00ac5b103315c"
    },
    "started_at_utc": "2026-09-13T13:16:16.513242+00:00",
    "scope": "Static checks and installed dependency consistency; no service or deployment evidence",
    "tools": {
      "ruff": "0.16.7",
      "mypy": "2.3.1",
      "hypothesis": "6.168.0"
    },
    "tree_unchanged": true,
    "finished_at_utc": "2026-09-13T13:16:20.337704+00:00"
  },
  "quality_tool_logs": {
    "ruff": "All checks passed!\n",
    "mypy": "Success: no issues found in 4 source files\n",
    "pip-check": "No broken requirements found.\n"
  },
  "phase_output_log": "{\"name\": \"ruff\", \"exit_code\": 0, \"status\": \"PASS\"}\n{\"name\": \"mypy\", \"exit_code\": 0, \"status\": \"PASS\"}\n{\"name\": \"pip-check\", \"exit_code\": 0, \"status\": \"PASS\"}\n",
  "evidence_changes": [
    "evidence/quality-run.json"
  ],
  "unchanged_evidence_count": 38,
  "code_digests_unchanged_from_preflight": true,
  "snapshot_verification": [
    {
      "path": "evidence/quality-run.json",
      "matches_current_evidence": true,
      "sha256_matches_record": true
    }
  ],
  "cleanup_inspection": {
    "lab_directory_exists": false,
    "private_directory_exists": false,
    "checkout_related_processes_excluding_host_namespace_inspector_ancestors": [],
    "inaccessible_or_exited_proc_entries": 20,
    "review_lock_available": true
  }
}
```

Recorded command 5: Repeat postflight using the original raw JSON so nanosecond metadata integers are preserved exactly (the initial JS JSON roundtrip lost integer precision); exit 0.

```bash
TZ=UTC PYTHONPATH=<workspace>/a14-work/evaluations/E4/source/src <workspace>/a14-work/venv/bin/python - <<'PY'
import fcntl
import hashlib
import json
import os
from pathlib import Path
import sys
root = Path.cwd()
sys.path.insert(0, str(root / 'tools'))
from evidence_utils import code_digests
baseline = json.loads("{\n\"old_run_files\": {\n    \"build/review-runs/interrupted-synthetic/run.json\": {\n      \"sha256\": \"766e8277d2a308cd86224331016e0a96b97b8c5ba974c3c98d0c83f71bcf1661\",\n      \"size\": 238,\n      \"mtime_ns\": 1789305207232800046\n    }\n  },\n  \"evidence_files\": {\n    \"evidence/README.md\": {\n      \"sha256\": \"1871b01e385fbca5168b1ca42d89a165955c3e25db3cf5afd2e1ab27606f0759\",\n      \"size\": 1730,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/acceptance-results.json\": {\n      \"sha256\": \"5508be85aab48a499ecd6567987009a770fe86e4a9e42d4dceecc2516bde98df\",\n      \"size\": 330242,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/acceptance-results.md\": {\n      \"sha256\": \"4c7daaf8320405f41e539def22be69a1846635b1dc0554cf48d4082ca17803ce\",\n      \"size\": 2541,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/alerta-persistence-wasm.xml\": {\n      \"sha256\": \"996b660d9f2c01d43d36cd95b41431c7f8bf33070971d06022e16ab6b163be36\",\n      \"size\": 1734,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/batch-200-supplemental.json\": {\n      \"sha256\": \"8bd6e2203ea5d17812f70c86d99da6085f076617b7519ccd0a8be1a41deb7ee9\",\n      \"size\": 1694,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/batch-50-supplemental.json\": {\n      \"sha256\": \"168c0c2191f800f193814efc69b2bfef51cb54708be207d4b88acf46e21cc5b7\",\n      \"size\": 1682,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/collection-check.json\": {\n      \"sha256\": \"46348077dfc167a000031aef8079adab882a22c8aa3aed07073b1e2d989d6e67\",\n      \"size\": 387,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/dependency-review.json\": {\n      \"sha256\": \"73799e9e959eba522666107322cc70f7941bc785ee632bfa53fc7b4cf2ea2a7e\",\n      \"size\": 281,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/deployment-e2e-run.json\": {\n      \"sha256\": \"f6ffddbb376496d88602b2c18042bc8f47c7b2d5eb4e622cd00a904273938c48\",\n      \"size\": 2666,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/local-validation.json\": {\n      \"sha256\": \"9c0235b5fc9c5674b92677336088edf054b3550184b21543a73d19be608eb3ee\",\n      \"size\": 1078,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/mutation-pr.json\": {\n      \"sha256\": \"80e2d077fb9c00ac5f82047f53453b8fbf28b36b5d500698d524aa0f7cd4474a\",\n      \"size\": 4943,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/mutation-run.json\": {\n      \"sha256\": \"8c9747f2256f21f231f5e0c96ee7a3cd727aca7383df7a8cb21d41a67afe52cd\",\n      \"size\": 7644,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/native-alerta.xml\": {\n      \"sha256\": \"90861b00df1ff1988b00fe34f34aee99ee0cb1507987b9ecc4d9631c9706848f\",\n      \"size\": 1256,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/native-delivery_faults.xml\": {\n      \"sha256\": \"e90c94d01a210756f7f1b5aee2acc2f50c98770d0c635ce02a4fa9b5d29d093b\",\n      \"size\": 984,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/native-performance.xml\": {\n      \"sha256\": \"9b3ab9975e59c1e5138c5b408e923e8f4dcfb502abf6ae91516892b5a55ee133\",\n      \"size\": 1050,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/native-postgres.xml\": {\n      \"sha256\": \"23f87e0298c4ec23b6dfcaefa8a0170ea41f50a837f0cf9aa8789ae990e2307f\",\n      \"size\": 5684,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/native-run.json\": {\n      \"sha256\": \"fae2a9121ebf7e7e1e19bd3075121da4ec314a57e4e587e1ddbdfa9bb8128d82\",\n      \"size\": 2938,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/native-worker.xml\": {\n      \"sha256\": \"6ace7f50e00a1935908154b2a474e8af66ef6c88208adb96ff8cb7f118e2c18e\",\n      \"size\": 771,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/npm-audit.json\": {\n      \"sha256\": \"12931fe186a1d5341d0bd56a90726249c7208945f5b9168701ba8b1af5ce8dc3\",\n      \"size\": 358,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/optional-services.xml\": {\n      \"sha256\": \"5f796aed9900764609d576b022c6510f414ec1d075baa9a62bbda47cb1147d1d\",\n      \"size\": 8154,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/performance-wasm.xml\": {\n      \"sha256\": \"8cfcec2792039005ae15c1059b0bd2f2e617d7199ee20bdf38a2aca938bd8ff6\",\n      \"size\": 1045,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/pip-audit.json\": {\n      \"sha256\": \"af126be6b0ac90fa3c2ebb05a256e28afd88323f7efd488a87418a657fd64645\",\n      \"size\": 3300,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/postgres-wasm-combined.xml\": {\n      \"sha256\": \"255e3c31ced632c12e6351ad9b6acdcdab9501fea276e61c31eefac5d05fa32c\",\n      \"size\": 8976,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/postgres-wasm.xml\": {\n      \"sha256\": \"0a2a1ad070980b83aa100295134163f7b6c14e183d988047a2122078737739ee\",\n      \"size\": 5698,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/property-nightly-run.json\": {\n      \"sha256\": \"640e940240835dead2d6b2d2b7a496b9f1b579b967cb48a71043e2466d2a20d5\",\n      \"size\": 637,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/property-nightly.xml\": {\n      \"sha256\": \"53c8b8d4c5a6697683e9637ca3385faffda38967bec7dce36c9944e69fa5bd90\",\n      \"size\": 33995,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/public-audit.json\": {\n      \"sha256\": \"533c4f9147a4e79915e9834469ac5bf466ca972ae3acfb4aeb62ff6ef38ec052\",\n      \"size\": 261,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/quality-run.json\": {\n      \"sha256\": \"635a27a3c20e1b749692b346d27cd0483d20f661df10100226f236f36e73e0d2\",\n      \"size\": 803,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/real-zabbix-run.json\": {\n      \"sha256\": \"98374f786b9aca5dd686c88f664e89116709084e2296444bdd9bb7c2ddfe4cc6\",\n      \"size\": 576,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/real-zabbix.xml\": {\n      \"sha256\": \"0021d63cf77f4074f2cd2f9955f9eb44a27aeee5f566e5d52b2a78a6a7b8026d\",\n      \"size\": 1971,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/reference-run.json\": {\n      \"sha256\": \"2120fac7deb541b7985633fc716adb396ffc5f31e60698db376a6495ef1a99db\",\n      \"size\": 4482,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/runtime_wasm_sql.json\": {\n      \"sha256\": \"a52c04bad36beda7e0e46b2f83370ffcc143aa5f62d064eb19afb03c5552bb80\",\n      \"size\": 3412,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/sbom-validation.json\": {\n      \"sha256\": \"7f88c637e22d75352a7fa4eeb10a6b07c09171b44c926ab581aeff7462472315\",\n      \"size\": 271,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/sbom.cdx.json\": {\n      \"sha256\": \"5f0086db92d070950c7ef37412dbd2a2f31fb3f23ef80414524059440b9f13b2\",\n      \"size\": 53997,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/security-scans.json\": {\n      \"sha256\": \"0007dced4ad3c1e2acb0769dc7c70f07141abe83b00019b5a26bcbd5415fc527\",\n      \"size\": 439,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/test-summary.json\": {\n      \"sha256\": \"3021e737d5888b9440f67cb12ed680d6639b04645e6bbf6d6c9db32b12f400ea\",\n      \"size\": 504,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/unit-mocked.xml\": {\n      \"sha256\": \"f5f13c946df4420d230ce72295cc9376a18db8893599755f9a3493d1df2e7d63\",\n      \"size\": 144863,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/wheel-smoke.json\": {\n      \"sha256\": \"c3528136d1a837d4c34932db0c3f7c221507a6c70d5d9814e9ac9b3fdc971040\",\n      \"size\": 695,\n      \"mtime_ns\": 1789305173000000000\n    },\n    \"evidence/worker-sql-wasm.xml\": {\n      \"sha256\": \"199954e5cc6c54a466051b440a9ad3a4d9b3627e96c7d9ce021fc36bd27ca6dd\",\n      \"size\": 771,\n      \"mtime_ns\": 1789305173000000000\n    }\n  },\n  \"code_digests\": {\n    \"source\": \"be456613206164e76fd39da875abc455844d1581ad76bacfe235021e5ef8652a\",\n    \"harness\": \"54e07ac136bcf9e95fb76ceef3504189c1467bc2385ffe4c7cc00ac5b103315c\"\n  }\n}")
def files_snapshot(directory):
    return {str(path.relative_to(root)): {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'size': path.stat().st_size, 'mtime_ns': path.stat().st_mtime_ns} for path in sorted(directory.rglob('*')) if path.is_file()}
old = root/'build/review-runs/interrupted-synthetic'
new = root/'build/review-runs/e4-quality-recovery'
run = json.loads((new/'run.json').read_text())
quality = json.loads((root/'evidence/quality-run.json').read_text())
old_record = json.loads((old/'run.json').read_text())
old_equal = files_snapshot(old) == baseline['old_run_files']
after_evidence = files_snapshot(root/'evidence')
changed = [name for name in sorted(baseline['evidence_files'].keys() | after_evidence.keys()) if baseline['evidence_files'].get(name) != after_evidence.get(name)]
ancestors = set()
current = int(Path('/proc/self').resolve(strict=True).name)
while current > 0 and current not in ancestors:
    ancestors.add(current)
    try:
        stat = (Path('/proc') / str(current) / 'stat').read_text()
        current = int(stat[stat.rfind(')')+2:].split()[1])
    except (OSError, ValueError, IndexError):
        break
processes = []
inaccessible = 0
for process_dir in Path('/proc').iterdir():
    if not process_dir.name.isdigit() or int(process_dir.name) in ancestors:
        continue
    try:
        cwd = (process_dir/'cwd').resolve(strict=True)
        command = (process_dir/'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace')
        if cwd == root or root in cwd.parents or str(root) in command:
            processes.append({'pid':int(process_dir.name),'cwd':str(cwd),'name':(process_dir/'comm').read_text().strip()})
    except (PermissionError, ProcessLookupError, FileNotFoundError):
        inaccessible += 1
lock_path = root/'build/review-locks/review.lock'
with lock_path.open('r+') as lock:
    try:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        lock_available = True
        fcntl.flock(lock.fileno(), fcntl.LOCK_UN)
    except BlockingIOError:
        lock_available = False
snapshots = [{'path':row['path'], 'matches_current_evidence':(new/'quality'/row['path']).read_bytes() == (root/row['path']).read_bytes(), 'sha256_matches_record':hashlib.sha256((new/'quality'/row['path']).read_bytes()).hexdigest() == row['sha256']} for row in run['phases'][0]['evidence']]
result = {'old_run_id':old_record['run_id'],'old_run_status':old_record['status'],'old_run_preserved_bytes_metadata_and_file_set':old_equal,'old_run_sha256':files_snapshot(old),'new_run':run,'quality_record':quality,'quality_tool_logs':{name:(root/'build/quality'/f'{name}.log').read_text() for name in ('ruff','mypy','pip-check')},'phase_output_log':(new/'quality/output.log').read_text(),'evidence_changes':changed,'unchanged_evidence_count':len(baseline['evidence_files'])-len(changed),'code_digests_unchanged_from_preflight':code_digests(root)==baseline['code_digests'],'snapshot_verification':snapshots,'cleanup_inspection':{'lab_directory_exists':(root/'.lab').exists(),'private_directory_exists':(root/'build/private').exists(),'checkout_related_processes_excluding_host_namespace_inspector_ancestors':processes,'inaccessible_or_exited_proc_entries':inaccessible,'review_lock_available':lock_available}}
print(json.dumps(result, indent=2))
assert old_equal
assert old_record['status'] == 'RUNNING'
assert changed == ['evidence/quality-run.json']
assert code_digests(root) == baseline['code_digests'] == run['code_digests'] == quality['code_digests']
assert run['status'] == quality['status'] == 'PASS'
assert len(quality['checks']) == 3 and all(row['status']=='PASS' and row['exit_code']==0 for row in quality['checks'])
assert all(row['matches_current_evidence'] and row['sha256_matches_record'] for row in snapshots)
assert len(snapshots) == 1
assert lock_available
PY
```

Output:

```text
{
  "old_run_id": "interrupted-synthetic",
  "old_run_status": "RUNNING",
  "old_run_preserved_bytes_metadata_and_file_set": true,
  "old_run_sha256": {
    "build/review-runs/interrupted-synthetic/run.json": {
      "sha256": "766e8277d2a308cd86224331016e0a96b97b8c5ba974c3c98d0c83f71bcf1661",
      "size": 238,
      "mtime_ns": 1789305207232800046
    }
  },
  "new_run": {
    "schema_version": 1,
    "run_id": "e4-quality-recovery",
    "status": "PASS",
    "started_at_utc": "2026-09-13T13:16:16.419616+00:00",
    "code_digests": {
      "source": "be456613206164e76fd39da875abc455844d1581ad76bacfe235021e5ef8652a",
      "harness": "54e07ac136bcf9e95fb76ceef3504189c1467bc2385ffe4c7cc00ac5b103315c"
    },
    "phases": [
      {
        "name": "quality",
        "status": "PASS",
        "command": [
          "python",
          "tools/run_quality.py"
        ],
        "started_at_utc": "2026-09-13T13:16:16.421897+00:00",
        "code_digests": {
          "source": "be456613206164e76fd39da875abc455844d1581ad76bacfe235021e5ef8652a",
          "harness": "54e07ac136bcf9e95fb76ceef3504189c1467bc2385ffe4c7cc00ac5b103315c"
        },
        "exit_code": 0,
        "interrupted": false,
        "cleanup": "CHILD_MANAGED",
        "duration_ms": 3988,
        "finished_at_utc": "2026-09-13T13:16:20.424058+00:00",
        "tree_unchanged": true,
        "evidence": [
          {
            "path": "evidence/quality-run.json",
            "sha256": "813bb2c69844154d852cb4856bcf3bb86299f1cadedfab5347d1fbe6ee122a27"
          }
        ]
      }
    ],
    "scope": "Local phase execution; per-phase evidence defines its coverage; G1-G8 pending",
    "finished_at_utc": "2026-09-13T13:16:20.444166+00:00",
    "tree_unchanged": true
  },
  "quality_record": {
    "status": "PASS",
    "checks": [
      {
        "name": "ruff",
        "exit_code": 0,
        "status": "PASS"
      },
      {
        "name": "mypy",
        "exit_code": 0,
        "status": "PASS"
      },
      {
        "name": "pip-check",
        "exit_code": 0,
        "status": "PASS"
      }
    ],
    "code_digests": {
      "source": "be456613206164e76fd39da875abc455844d1581ad76bacfe235021e5ef8652a",
      "harness": "54e07ac136bcf9e95fb76ceef3504189c1467bc2385ffe4c7cc00ac5b103315c"
    },
    "started_at_utc": "2026-09-13T13:16:16.513242+00:00",
    "scope": "Static checks and installed dependency consistency; no service or deployment evidence",
    "tools": {
      "ruff": "0.16.7",
      "mypy": "2.3.1",
      "hypothesis": "6.168.0"
    },
    "tree_unchanged": true,
    "finished_at_utc": "2026-09-13T13:16:20.337704+00:00"
  },
  "quality_tool_logs": {
    "ruff": "All checks passed!\n",
    "mypy": "Success: no issues found in 4 source files\n",
    "pip-check": "No broken requirements found.\n"
  },
  "phase_output_log": "{\"name\": \"ruff\", \"exit_code\": 0, \"status\": \"PASS\"}\n{\"name\": \"mypy\", \"exit_code\": 0, \"status\": \"PASS\"}\n{\"name\": \"pip-check\", \"exit_code\": 0, \"status\": \"PASS\"}\n",
  "evidence_changes": [
    "evidence/quality-run.json"
  ],
  "unchanged_evidence_count": 38,
  "code_digests_unchanged_from_preflight": true,
  "snapshot_verification": [
    {
      "path": "evidence/quality-run.json",
      "matches_current_evidence": true,
      "sha256_matches_record": true
    }
  ],
  "cleanup_inspection": {
    "lab_directory_exists": false,
    "private_directory_exists": false,
    "checkout_related_processes_excluding_host_namespace_inspector_ancestors": [],
    "inaccessible_or_exited_proc_entries": 20,
    "review_lock_available": true
  }
}
```


