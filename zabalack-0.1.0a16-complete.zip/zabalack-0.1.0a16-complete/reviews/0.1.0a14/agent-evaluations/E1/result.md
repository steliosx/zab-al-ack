# E1 result

Fixed only `README.md` line 3: `evalaution` → `evaluation`.

`cat AGENTS.md` and `cat README.md` both exited 0. The repository guidance calls for affected-page link/example checks on ordinary documentation edits; no executable behavior changed.

Diff captured with Python's `difflib.unified_diff` from the original text and corrected text:

```diff
--- a/README.md
+++ b/README.md
@@ -1,6 +1,6 @@
 # Zab-al-ack
 
-**0.1.0a13 · public alpha candidate · development and isolated evalaution**
+**0.1.0a13 · public alpha candidate · development and isolated evaluation**
 
 Formerly **Ackline**. 0.1.0a9 renamed the package, CLI, Alerta entry points,
 configuration, services, database namespace and signing domain to `zabalack`;
```

The edit script exited 0 and asserted that the sole change was the opening typo.

Verification command, run in `<workspace>/a14-work/evaluations/E1/source` using `/bin/bash` with `login=false`:

```bash
python3 - <<'PY'
from pathlib import Path
from urllib.parse import unquote, urlsplit
import re
import subprocess

text = Path('README.md').read_text()
assert 'evalaution' not in text
assert text.splitlines()[2] == '**0.1.0a13 · public alpha candidate · development and isolated evaluation**'
links = re.findall(r'!?\[[^\]]*\]\(([^)\s]+)\)', text)
local_links = [unquote(urlsplit(link).path) for link in links if not urlsplit(link).scheme]
missing = sorted({link for link in local_links if not Path(link).exists()})
assert not missing, f'Missing link targets: {missing}'
blocks = re.findall(r'^```bash\n(.*?)^```\s*$', text, re.M | re.S)
assert len(blocks) == 2, f'Unexpected bash example count: {len(blocks)}'
for i, block in enumerate(blocks, 1):
    checked = subprocess.run(['/bin/bash', '-n'], input=block, text=True, capture_output=True)
    assert checked.returncode == 0, f'Bash example {i}: {checked.stderr}'
example_paths = sorted(set(re.findall(r'(?:requirements[^\s]*\.lock|tools/[\w.-]+\.py)', '\n'.join(blocks))) | {'lab/package.json'})
missing_examples = [path for path in example_paths if not Path(path).is_file()]
assert not missing_examples, f'Missing example input/script files: {missing_examples}'
assert not any(line.rstrip() != line for line in text.splitlines()), 'Trailing whitespace found'
assert text.endswith('\n'), 'Missing final newline'
print('PASS: opening status line corrected; typo absent')
print(f'PASS: all {len(local_links)} README Markdown link targets exist ({len(set(local_links))} distinct paths)')
print(f'PASS: /bin/bash -n accepted both ({len(blocks)}) bash examples; examples were not executed')
print(f'PASS: all {len(example_paths)} referenced example input/script files exist')
print('PASS: no trailing whitespace; final newline preserved')
PY
```

Exit 0:

```text
PASS: opening status line corrected; typo absent
PASS: all 31 README Markdown link targets exist (30 distinct paths)
PASS: /bin/bash -n accepted both (2) bash examples; examples were not executed
PASS: all 10 referenced example input/script files exist
PASS: no trailing whitespace; final newline preserved
```

Attempt retained: `git status --short && git diff -- README.md && git ls-files README.md AGENTS.md` exited 128 with `fatal: not a git repository (or any of the parent directories): .git`. The isolated snapshot has no Git metadata, so the captured before/after diff above provides the change evidence.

No runtime suites or services were needed for this spelling-only edit. No remote actions were taken.
