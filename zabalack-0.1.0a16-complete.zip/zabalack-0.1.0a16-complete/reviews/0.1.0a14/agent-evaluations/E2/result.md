# E2 customer-scope regression repair

Completed in `<workspace>/evaluations/E2/source`.
The defect was reproduced before changing runtime code. The final focused suite
passes **136 tests**, with no failures, errors or skips.

The affected invariant is DESIGN.md §§4.1–4.2 and §6.2: an ordinary authenticated
human must have the persisted top-level customer in their authenticated customer
scope before write-back is prepared or accepted by the worker. A source attribute
named `customer` cannot replace that top-level field. Administrators still require
both the named approved exception and the cohort's `allow_admin` permission.

The checkout's AGENTS.md and the relevant design, final-review, amendment and
agent-workflow guidance were read. No other evaluation directory or prior
conversation was consulted. Commands used `/bin/bash` with `login=false`, with
the source directory above as their working directory. Runtime and test commands
set `TZ=UTC` and `PYTHONPATH` to this copy's `src`. The supplied pinned environment
was used without dependency or environment modifications.

## Behaviour observed

| Run | Runtime state | Exit | Result | Raw log in E2 |
|---|---|---:|---|---|
| Existing worker negative and positive | Original, before any test or runtime edit | 1 | 1 failed, 1 passed | `pre-existing-tests.log` |
| Expanded focused suite | Regression tests added; original runtime | 1 | 14 failed, 122 passed | `pre-expanded-tests.log` |
| Same expanded focused suite | Repaired runtime | 0 | 136 passed | `post-focused-tests.log` |

The first failure was the existing
`test_T11a_cross_customer_scope_rejected_before_target_resolution`: a correctly
signed capture for `lab-B` with actor scope `['lab-A']` did not produce
`reject_capture`. The existing supported alternate-cohort test passed.

The expanded pre-fix run independently exposed the same error through the actual
Alerta dispatcher with mocked persistence: ordinary actors with empty, unrelated,
prefix-only or wildcard scopes received `awaiting_capture` instead of
`skipped_actor_policy`. Worker cases likewise failed to reject these signed
captures. All 14 failures were assertions of this authorization defect, not
timeouts, import errors or unavailable services. Both expanded runs reported the
same 96 upstream Alerta `datetime.utcnow()` deprecation warnings.

## Changes

- `src/zabalack/policy.py`: `authorize_actor` now requires an ordinary actor's
  customer collection to be a list or tuple containing the exact top-level
  customer. The pre-existing human identity, nonempty customer and administrative
  branch checks are retained. The plugin and worker continue to enforce the named
  administrative exception separately.
- `tests/unit/test_plugins_dispatcher.py`: added persisted-customer versus
  `attributes.customer` cases, empty and wrong scope negatives, list/tuple and
  multiple-customer positives, and a missing top-level customer negative.
  Ordinary scope remains mandatory even when the cohort allows administrators.
  Added all combinations of cohort permission and named exception for both
  `admin` and `admin:alerts`, checking proof production and probe calls.
- `tests/security/test_binding_boundary.py`: extended the existing worker scope
  negative to empty, unrelated, prefix-only and wildcard scopes. Corrected the
  synthetic helper to preserve an explicitly empty list instead of silently
  substituting its default. Added administrative exception combinations with
  empty and matching scopes, requiring the expected rejection reason or successful
  verification, and zero target resolution or delivery-claim activity.

The runtime change is:

```diff
     if actor.get("admin") is True:
         return cohort.get("allow_admin") is True
-    return actor.get("admin") is False
+    customers = actor.get("customers")
+    return actor.get("admin") is False and isinstance(customers, (list, tuple)) and customer in customers
```

## Actual runtime and test commands

Import verification, exit 0; raw output retained as `import-location.log`:

```bash
env TZ=UTC PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=<workspace>/evaluations/E2/source/src <workspace>/venv/bin/python -c 'from pathlib import Path
import os
import sys
import zabalack
import zabalack.policy
import zabalack.worker
expected = Path("<workspace>/evaluations/E2/source/src/zabalack")
print("Python:", sys.executable)
print("TZ:", os.environ["TZ"])
for module in (zabalack, zabalack.policy, zabalack.worker):
    path = Path(module.__file__).resolve()
    print(module.__name__ + ":", path)
    assert path.parent == expected, path
' > ../import-location.log 2>&1
```

The observed package, policy and worker paths were respectively `__init__.py`,
`policy.py` and `worker.py` beneath the expected E2 directory. This is import
provenance only; the test assertions above are the behaviour evidence.

First reproduction, exit 1:

```bash
env TZ=UTC PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=<workspace>/evaluations/E2/source/src <workspace>/venv/bin/python -m pytest -q tests/security/test_binding_boundary.py::test_T11a_cross_customer_scope_rejected_before_target_resolution tests/security/test_binding_boundary.py::test_T11b_authorised_other_cohort_selection_remains_trusted_operator_scope > ../pre-existing-tests.log 2>&1
```

Expanded reproduction before runtime repair, exit 1:

```bash
env TZ=UTC PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=<workspace>/evaluations/E2/source/src <workspace>/venv/bin/python -m pytest -q --tb=short tests/unit/test_crypto_policy.py tests/unit/test_plugins_dispatcher.py tests/unit/test_worker.py tests/security/test_binding_boundary.py > ../pre-expanded-tests.log 2>&1
```

Final verification after runtime repair, exit 0:

```bash
env TZ=UTC PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=<workspace>/evaluations/E2/source/src <workspace>/venv/bin/python -m pytest -q --tb=short tests/unit/test_crypto_policy.py tests/unit/test_plugins_dispatcher.py tests/unit/test_worker.py tests/security/test_binding_boundary.py > ../post-focused-tests.log 2>&1
```

An initial `git status --short` inspection returned exit 128 because this
disposable source copy has no Git repository metadata. It was not a test or
behavioural result. Source changes were applied directly and reviewed in place.

## Scope of the evidence

The runs exercise pure policy/cryptographic checks, actual pinned Alerta Python
dispatch with mocked persistence, and worker logic with database and target spies.
They do not establish live tenant permissions, PostgreSQL atomicity, native
service behaviour or deployment readiness. No services were started, and no
network, production, publication or external operations were performed. Existing
acceptance records, deployment gates and unrelated release evidence were left
unchanged. Failed logs were preserved alongside the successful run.
