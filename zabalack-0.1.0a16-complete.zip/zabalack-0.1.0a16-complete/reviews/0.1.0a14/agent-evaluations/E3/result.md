**E3 — read-only alpha-export evidence review, 2026-09-13 UTC**

**This checkout is not ready for an evidence-backed 0.1.0a14 alpha export.** Its existing successful execution records belong to different source and harness bytes. The actual read-only public audit fails with nine findings. This establishes stale evidence, not a newly observed runtime defect. No tests, service runners, builds, acceptance regeneration, publication, network requests or production actions were performed.

Reviewed only `<workspace>/evaluations/E3/source`, following `AGENTS.md`, `.agents/skills/zabalack-release-review/SKILL.md`, `docs/RELEASING.md` and `docs/agent-workflows.md`. The explicit read-only request takes precedence over the skill's execution and packaging steps. Findings were written only to `../result.md`; no other evaluation directory or prior project conversation was consulted.

All commands used `/bin/bash`, `login=false`, and `TZ=UTC`. Python checks used `<workspace>/venv/bin/python -B` (Python 3.12.14), preventing bytecode writes. No dependency installation or environment modification was attempted.

**Freshness is determined by bytes, not the age or PASS label of a report.** The principal runs were recorded on September 12, approximately a day before this review, but every one of the twelve JSON records containing `code_digests` differs from this checkout in both scopes. `tools/evidence_utils.py` binds `src/` and `sql/` separately from tests, tools, labs, deployment/configuration inputs and dependency locks. Documentation and evidence are outside those scopes; instruction files also have a separate guidance fingerprint.

| Scope | Current checkout SHA-256 | Principal historical records SHA-256 |
|---|---|---|
| Source | `be456613206164e76fd39da875abc455844d1581ad76bacfe235021e5ef8652a` | `f7714bc75454e68257e7e3e6b80be5e63c55b7a4de3358aa483522931e18f574` |
| Harness | `54e07ac136bcf9e95fb76ceef3504189c1467bc2385ffe4c7cc00ac5b103315c` | `a6716038ec17cf61d9613abb9c26228ad6e2142a6c01ee5bae09f55d1d84a2b1` |

The mismatching records are `acceptance-results.json`, `collection-check.json`, `deployment-e2e-run.json`, `local-validation.json`, `mutation-pr.json`, `mutation-run.json`, `native-run.json`, `property-nightly-run.json`, `quality-run.json`, `real-zabbix-run.json`, `reference-run.json` and `runtime_wasm_sql.json`, all under `evidence/`. Eleven use the principal historical pair above. The earlier `mutation-pr.json` instead records source `b3171722759bdbb3f4ce4b7804e2dba5f178397a9b593ad41b28f308180687d7` and harness `671aa8f36db41647487d6df86f937fdecc53711f1955b14ebcf1e82fdea79308`; it is stale as well.

`pyproject.toml` and the new changelog entry identify a14, while `ALPHA_REPORT.md`, `evidence/README.md`, `evidence/wheel-smoke.json` and `config/publication.pending.json` still identify a13. The alpha report's “Executed on the final tree” claims therefore cannot be carried forward as a14 results. The changelog says runtime Python changed only in its version string, but that statement does not make different digests equal. No prior source tree or Git history was available here to independently establish the exact delta.

**The retained execution evidence has useful, limited historical scope.** I parsed the supplied JUnit XML and compared its case outcomes to the selected reference and service summaries. These are checks of existing records; I did not execute their test cases.

| Existing evidence | Recorded result, corroborated where XML exists | Scope and limit |
|---|---|---|
| Reference run | 820 passed, 23 skipped, 0 failed: 791 unit/mock/property/offline passes; 29 PostgreSQL WASM passes; 4 native-only WASM skips; 19 optional-service skips | Historical selected reference cases, not current-tree or deployment acceptance. `collection-check.json` claims 843 collected and recorded on that older tree; current collection was not run. |
| Native run | 42 passed, 0 failed/skipped: PostgreSQL 24, delivery faults 5, worker 4, Alerta 7, performance 2; phase cleanup exit codes are 0 | Recorded local PostgreSQL 18.3/PgBouncer 1.24.1 services, `not_docker: true`; no Docker Compose execution is established. |
| Real Zabbix | 6 passed, 0 failed/skipped, observed API 7.0.10 | Historical recorder-owned synthetic contract, including the excluded-action denial; not installed production-account authority. |
| Deployment-path lab | JSON records 4 passed and 13/13 observations true, explicit cleanup success | Local processes and an installed a13 wheel; the current validator rejects its stale binding. This checkout has no separate deployment E2E JUnit file to corroborate those four counts. |
| Property nightly | XML has 46 passed, 0 failed/skipped | Additional overlapping generated checks using WASM, not native concurrency or permissions. |
| Mutation profiles | Earlier PR record claims 12 killed; latest compatibility record is nightly and claims 20 killed, with no other outcomes | Curated Python assertion mutations with mocked dependencies; neither is current. New canonical `mutation-pr-run.json` and `mutation-nightly-run.json` are absent. The optional absence is not itself a public-audit failure; fresh separate profiles are needed to substantiate a14 profile claims. |
| Quality, SQL, quickstart/media summary | Recorded Ruff/mypy/pip-check PASS; 8 SQL groups; local summary claims quickstart success and 15 webhook groups | Historical static, WASM and synthetic checks. No fresh quality, SQL, quickstart or webhook run was made. |

Repeated suites and the combined WASM XML overlap and must not be added to the 820 reference-pass total. The acceptance mapping reports 38 reference PASS rows and two `MANUAL_GATE_PENDING` rows: T2 (every serving node/site) and T27 (source actions with update operations). All 40 rows still have deployment result `MANUAL_GATE_PENDING`; the mapping itself is also stale.

**Actual read-only checks produced the following results.** The Python prefix below is the supplied interpreter with `-B`, with `TZ=UTC` set for every invocation.

| Check actually performed | Result |
|---|---|
| `git --no-optional-locks status --short --untracked-files=normal` | Exit 128: this extracted tree is not a Git repository. A clean commit/worktree state cannot be asserted. |
| Python filesystem inventory and SHA-256 snapshot | 307 regular files, no symlinks, no `build/` or `dist/` directory. |
| `evidence_utils.code_digests(root)` and comparisons of both fields on all bound JSON records | 12/12 records mismatch both source and harness; zero current bound execution records. |
| `python -B tools/public_audit.py` (no `--write-report`) | Exit 1, FAIL, 307 public files, nine findings, detailed below. |
| `python -B tools/verify_release.py` (no `--candidate`) | Exit 1, `unsigned_release_consistency` FAIL. Required `dist/` inputs are absent, so no wheel, sdist, ZIP, checksums or two-build provenance could be verified. This does not establish corruption of an existing artifact. |
| `python -B tools/check_acceptance_gate.py --evidence config/deployment-evidence.pending.json` | Exit 2, `accepted: false`, all 40 T requirements and G1–G8 open; `external_writes_enabled: false`. |
| `agent_guidance.inspect(root)` | PASS for 16 instruction/context files and three skills; SHA-256 `4c0a061b9c950c69fe7b5b69153689473df725c73eb74b88d2d1c40b823a2aae`. This verifies guidance structure/bytes, not agent performance, a signature or deployed gates. |
| `public_audit.publication_inputs(root)` | Ten required fields remain missing/false: repository, package owner, primary/backup maintainers, private conduct contact, security-report verification, rights review, public-content review, PyPI namespace confirmation and publication authorization. |
| `importlib.metadata` comparison against lock-file `==` pins | All 50 reference, 9 quality and 9 runtime pins match installed distribution versions (overlap retained). Scanner lock differs: 16 distributions absent and pip is 25.0.1 instead of 26.2.1. This was version inspection only, not installation-hash verification or a security scan. |
| Final repeat of full file-path/content-hash snapshot | Same 307 files and identical aggregate SHA-256 as before validation; no source or evidence byte changes. |

The actual audit emits `evidence-not-bound-to-tree` for reference, native, real-Zabbix, acceptance, quality, mutation and property-nightly records; additionally `mutation-gate-invalid` for `mutation-run.json`, and `deployment-evidence-invalid` for `deployment-e2e-run.json`. The previously saved `evidence/public-audit.json` says PASS for only 297 files and does not describe this audit. It was preserved unchanged. No other targeted audit findings were emitted, including SQL-manifest, public-file, guidance and inert-default checks; this limited audit is not an exhaustive secret or legal review.

The before/after snapshot algorithm hashes each regular file, sorts `(relative_path, file_sha256)` tuples, then hashes their compact JSON encoding. Its unchanged aggregate SHA-256 was `11ab62db9b5d7ca6b8b2c888b9f6c77fc493474ef40b96bfe09eddd7fe294cda`. Because this report sits outside `source/`, it is not part of that snapshot.

**Deployment, security and publication limits remain separate from local alpha export.** G1–G8 are `planned/NOT_VERIFIED` in `docs/deployment_gates.csv`; the deployment register is empty. The production example remains disabled with external writes disabled and an empty cohort, and the public audit found no active production targets. Amendment A2 is unresolved: the documented webhook-to-Alerta transport lacks the required peer/hostname verification and redirect containment. A passing synthetic lab does not resolve that boundary. Approved installed transport evidence and negative tests remain deployment prerequisites.

`evidence/security-scans.json` records a historical Python advisory lookup over 58 packages with zero advisories, Gitleaks `NOT_RUN`, and external security review `PENDING`; the npm report records no vulnerabilities. No current advisory queries or scanners were run. Some narrative pages mention independent a12 local Gitleaks success, but that must remain a distinct historical claim: it cannot override this checkout's explicit `NOT_RUN` record or prove a current a14 scan. Hosted Actions/CodeQL, Compose execution, signed attestations and production acceptance are not established by workflow templates or local-process reports.

**Preparing an export later requires fresh execution on the final candidate.** Preserve these older records and all retained failed/interrupted attempts separately; do not replace old digests, remove failures, relabel skips as passes or treat local fixtures as G1–G8. Run the available candidate gates with declared pins, retain separate PR/nightly mutation reports, and use the supplied recorders to represent genuinely unavailable service layers as `NOT_RUN` without success counts. Native unavailability may be an explicitly disclosed local-alpha limitation; hosted packaging has its own native-success gate.

Only after the final source/harness runs should acceptance be regenerated, inventories/reports updated, the public audit rerun, two builds compared and the resulting release artifacts verified. A complete handoff also needs the website, changelog/justification, hashes, deployment/rollback guides and consolidated missing-input register. None of those packaging actions was performed in this read-only task. Open publication-owner inputs and explicit publication authorization remain separate requirements; this review authorizes no upload, push or production operation.
