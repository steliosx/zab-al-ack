# Review — Ackline 0.1.0a5 handoff (2026-09-10)

Scope: the packaged `ackline-website-and-plugin-0.1.0a5.zip` (SHA-256
`b2093b38ceba9bdd6755a54f5ee9bf2da311ab1be390c3963f47e979f3dff4a9`), verified
from a fresh unzip in the same sandbox that prepared it. Reviewer environment:
Ubuntu 24.04, Python 3.12.3, Node 22, source-built PostgreSQL 18.3 and
PgBouncer 1.24.1, source-built Zabbix 7.0.10 on PostgreSQL 16 + PHP 8.3; no
Docker daemon with registry access, no Go toolchain.

## Verdict

Ready to push to a private repository as the fifth alpha candidate. Production
Python and SQL are byte-identical to 0.1.0a4 apart from the version string; the
candidate adopts the independent a4 review's tooling patch unchanged, binds
every run record to the tree it ran on, proves the outside-scope Zabbix case
positively, and executed the real-service cases the review could not. No code
defect is open. What remains before a `0.1.0b1` tag is owner-side and listed in
`docs/BETA_READINESS.md`.

## The a4 review, verified

| Claim | Checked here |
|---|---|
| Input was the delivered a4 complete zip `5540e1dd…` | Byte-identical |
| Candidate bundle `36f8df8b…` | Byte-identical to the a4 handoff bundle |
| Rebuilt wheel `aea61039…`, sdist `3fe87bc1…`, source ZIP `5a0c292b…` | Equal to the a4 artifacts (independent reproducibility of the a4 build) |
| Patch `ff1f2854…` touches seven tooling/test files, no `src/` or `sql/` | Confirmed; applies cleanly to a fresh clone; file hashes match `REVIEW_MANIFEST.json` |
| Finding 1: fixtures reach the URL before the lab check | Reproduced with the packet's HTTP-spy reproducer on unmodified a4: client constructed and probe posted for a synthetic remote URL; after the patch, no client (`reviews/0.1.0a5/a4-findings-reproduction.json`) |
| Finding 2: updater promotes contradictory/cleanup-less evidence | Reproduced: 16 of the patch's validator regressions fail against the unmodified a4 updater, 0 after the patch |
| 320 passed / 13 skipped with the patch | 306 unit/mocked + 14 WASM reproduced before the a5 additions |

## Verified from the zip

| Check | Result |
|---|---|
| Top-level `SHA256SUMS` (231 entries, nested lists included), `RELEASE_SHA256SUMS` (223), `dist/SHA256SUMS` (4) | All OK |
| Wheel `ackline-0.1.0a5-py3-none-any.whl` `ackline/` vs `src/ackline/` | Byte-identical (13 modules); vs a4 source only `__version__` differs; wheel hash `55cc6956…` identical across the three builds of this preparation |
| sdist `src/ackline/`, `sql/` vs tree; nested source ZIP vs tree | Identical (handoff metadata excluded) |
| Git bundle `candidate/v0.1.0a5` | One commit `3dcc4188…`, `Ackline release preparation <release-preparation@localhost>`, dated `2026-09-10 00:00:00 +0000`, 214 tracked files, tree identical to source |
| Fresh venv from the restored clone (`requirements.lock`, `pip install --no-deps -e .`), `pip check` | Clean |
| `tools/public_audit.py` from the restored clone | PASS, 214 files, 0 findings — recomputes the source/harness digests and confirms every run record is bound to the clone |
| `pytest tests/unit tests/security tests/release tests/alerta tests/rpc` from the clone | 340 passed, 0 failed, 6 skipped (native-only) |
| Bare `pytest --collect-only` from another working directory on `tests/real_zabbix` and the boundary test | 51 collected (fails on a4 + patch without `pythonpath`) |
| `docs/sql_manifest.json` (12 entries, `package_version` 0.1.0a5) vs `sql/` | 0 mismatches |
| `lab/pglite_checks.mjs` from the clone, three consecutive runs | 8 SQL groups PASS each time (50/50 in a dedicated loop of the repaired boundary group) |
| `zabbix/v1/test_webhook.cjs` | 12 passed |
| `tools/run_reference_suite.py --wasm` (evidence in tree) | 354 passed, 13 skipped, 0 failed (340 unit/mocked + 14 WASM) |
| Native PostgreSQL 18.3 + PgBouncer 1.24.1, database `alerta`, fresh cluster per phase (evidence in tree) | 22 passed, 0 failed, 0 skipped; `shutdown_exit_code` 0 for every phase |
| Real Zabbix 7.0.10 through the patched fixtures (evidence in tree) | 5 passed, 0 failed, 0 skipped; T11a with witness-proved existence and group association; end-to-end case; recorded by `tools/record_real_zabbix.py` |
| Digest binding | `reference-run.json`, `native-run.json`, `real-zabbix-run.json` and `acceptance-results.json` all carry source `60ab0a1d…` / harness `b845d100…`, equal to the tree; a harness edit in a scratch copy made mapping, audit and build refuse (demonstrated) |
| Acceptance matrix | 38 PASS / 2 MANUAL_GATE_PENDING (T2, T27 procedural) under the stricter validator |
| pip-audit 2.9.0 (hash-verified install) / npm audit | 50 packages, 0 advisories / 0 vulnerabilities |
| Clean-venv wheel install with `[alerta]` extra | Both `ackline_zabbix_*` entry points load; inert `ackline config-check` exit 0 |
| SBOM | Validates against the CycloneDX 1.6 schema |
| Identifier sweep of the whole handoff | No lab paths, token file names, witness token, sandbox identifiers, personal names or e-mail addresses; `msp`/`alerta_capture_probe` only in historical changelog/amendment text; no IPs beyond loopback/documentation ranges, no keys, no `.env`, no TODOs |
| Website | HTML well-formed, no `<script>`, external links limited to the canonical URL and the two upstream projects; `styles.css` and assets byte-identical to the published site; local links and anchors resolve; no `0.1.0a4` mention left |

## Findings in this pass (all corrected before packaging)

1. `tests/postgres/assertions_boundaries.sql` failed intermittently on PGlite
   (`T14 bounded candidate count`, 3 of the first 40 runs): three consecutive
   acknowledgement updates carried the identical marker text and differed only
   in `clock_timestamp()`, which PGlite resolves to milliseconds, so the capture
   trigger's WHEN predicate — correctly — ignored an unchanged history head.
   Each entry now carries distinct operator text; 50 consecutive runs pass.
   Harness-only; no product change. Earlier candidates' passes of this group
   were genuine (the flake only lost a capture, never manufactured one).
2. The review patch's `from lab.real_zabbix_safety import …` only resolved
   under `python -m pytest`; bare `pytest` could not collect `tests/real_zabbix`
   or the new boundary test. `pythonpath = ["."]` in the pytest configuration,
   with a regression test that spawns pytest from another working directory.
3. Review-era wording: `evidence/README.md` now exempts the explicitly
   historical `pip-audit-before-tooling-fix.json` from the "produced on this
   tree" statement (a4 review note).

## Residual observations (not blockers)

- `classifiers` still says `Development Status :: 3 - Alpha`; flip to `4 - Beta`
  only with the `v0.1.0b1` tag.
- The digest binding is a fail-closed consistency check computed by the same
  tools that write the records; it is not a signature. Attestation of which
  commit produced a record belongs to hosted CI.
- The Docker Compose forms of both labs and the hosted CI workflows remain
  unexecuted; the first private push is where that happens.
- Retained-ledger query plans and licence-label review remain owner items.
