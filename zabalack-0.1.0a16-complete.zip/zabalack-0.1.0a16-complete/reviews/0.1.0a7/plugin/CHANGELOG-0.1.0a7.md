# Ackline 0.1.0a7 — 2026-09-11

- Add a reviewed mutation catalogue with bounded PR and expanded nightly profiles.
  Unchanged baselines must pass; only behavioral assertion failures count as
  kills. Invalid mutants, survivors, missing tests, errors and timeouts fail.
  Mutation testing exposed and closed missing wrong-event/trigger regressions.
- Require fresh mutation evidence alongside quality/reference/native CI before
  packaging. Extend source-binding coverage to deployment configuration, service
  definitions, release templates and all GitHub policy files.
- Add an isolated normal-process deployment lab: installed application and worker,
  ordinary authentication, separate native SQL logins, real Zabbix and media flow.
  Runtime execution remains NOT_RUN here; offline harness results are separate.
- Add opt-in commit-pinned CodeQL analysis with narrow result-upload permissions.
  Supply an inactive attestation workflow and strict release/attestation verifiers;
  local unsigned provenance is never relabeled as a signed hosted attestation.
- Record source-backed amendment A2: Zabbix 7.0.10 webhook HttpRequest disables
  TLS peer/host verification and follows redirects. Deployment requires reviewed
  transport remediation and negative tests; the worker TLS policy is unchanged.
- Correct README compatibility rows that did not clearly label historical native
  and real-Zabbix execution. Preserve G1–G8 and all publication-owner inputs.
- Runtime code is unchanged apart from version metadata. Migrations 001–007 and
  schema version 3 are unchanged; this candidate adds no SQL migration.

