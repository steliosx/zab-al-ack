# Ackline 0.1.0a7 implementation and verification

Implemented the remaining four quality areas on clean a6 commit
`55a64856f3a0c816c616c0218c4557a871cf2c9a`. Candidate commit:
`67f84543b430a6b1f9f0f9117bdf51e39d6b6014`, branch `candidate/0.1.0a7`,
author/committer timestamps `2026-09-11T17:42:02Z`. No remote push, tag publication,
package upload, production action or website deployment occurred.

## Delivered controls

| Item | Implementation | Executed evidence |
|---|---|---|
| 5. Mutation testing | Reviewed 12-case PR / 20-case nightly catalogue; unchanged baseline, private source copies, import-source checks, assertion-only kills, strict source-bound gate; required in CI/export | Expanded profile: 107 baseline tests passed, all 20 mutants killed; zero survivors/invalid/errors/timeouts |
| 6. Deployment E2E | New internal Docker project; installed Alerta HTTP factory and worker CLI; ordinary login, real role logins, Zabbix media import, macros, neutral/human updates and recovery; bounded cleanup; manual opt-in workflow | 51 offline helper/orchestration tests passed; four service tests skipped. Real service run NOT_RUN |
| 7. Security automation | Opt-in Python/JavaScript CodeQL, commit/CLI pins inspected from upstream, narrow result-upload permission and practical triage instructions | Offline workflow contracts passed. Hosted analysis/SARIF/rulesets NOT_RUN |
| 8. Release provenance | Shared current-run CI, exact artifact/source/evidence and wheel/sdist metadata verification; inactive signing/publication templates; pinned cryptographic verifier with exact workflow/tag/commit policy | Offline negative tests and actual a7 artifact consistency passed. Signed issuance and Ackline cryptographic attestation verification NOT_RUN |

Local artifact hashes remain unsigned consistency evidence. The new verifiers do
not turn that into a signed attestation. Required hosted jobs must execute after a
separately authorized repository push and owner policy configuration.

## Findings resolved before the final tree

- A wrong-event/trigger validation mutant survived the original tests. Two new
  independent valid-shaped mismatched responses now require no attempt/write.
  Runtime code already enforced the boundary; no product fix was needed.
- Review caught a nonexistent mutation dependency-lock path in CI. It now uses
  the actual hash-pinned quality lock, with an installation-contract regression.
- The normal service lab needed a PostgreSQL URL for Alerta backend selection,
  readable secret mounts for the pinned Zabbix image UID, an integer/string-aware
  history.push ID check, and exact one-off-container cleanup after timeout or
  interruption. These were repaired and covered by offline tests.
- Wheel/sdist verification now rejects rehashed metadata changes to entry points,
  dependencies, Python constraints, package identity and RECORD, as well as extra
  payloads, malformed archives, source mismatch and foreign/stale run evidence.
- README compatibility rows now distinguish historical service runs from the
  current candidate. Deployment, configuration and release/security policy edits
  now invalidate harness evidence as well.
- The inactive publication template now reuses required CI and validates the
  fresh candidate before its publication-owner gate. It remains disabled.

A separate agent reviewed the mutation/provenance/CI boundaries and ran focused
negative tests. This is code review within this development task, not an
independent external security assessment. External assessment remains pending.

## Narrow upstream amendment requiring deployment resolution

Actual Zabbix 7.0.10 source disables certificate peer/hostname verification and
enables redirects in webhook HttpRequest. Amendment A2 records the exact source
commit/file hash. An HTTPS webhook URL alone cannot prove authenticated ingestion;
G1/G2 require inspected remediation/control plus negative certificate, hostname
and redirect tests. Worker HTTPX TLS behavior is unchanged. No production target
was queried and no upstream patch was silently applied.

Alerta 9.1.0 performs schema work at normal startup. The lab uses the documented
trusted application/table-owner model and separate Ackline migration/runtime roles;
it does not claim successful non-owner application startup.

## Final executed results

| Check | Result |
|---|---|
| Reference pytest | **719 passed / 22 skipped / 0 failed** |
| Unit/mock/property/offline helpers | 696 passed |
| PostgreSQL 18.3 WASM | 23 passed / 4 native-only skips |
| Optional native/real services | 18 skipped; zero service passes |
| Collection coverage | All 741 discovered cases selected; multiplicity retained |
| Expanded mutation | 20/20 assertion kills; unchanged baseline 107 passed |
| Ruff / gradual strict mypy / pip check | Passed |
| Supplemental SQL / webhook groups | 8 / 12 passed; separate from pytest counts |
| Isolated quickstart / clean-venv wheel smoke | Passed |
| Python / Node advisory queries | 58 packages, zero advisories / zero reported vulnerabilities |
| SBOM | 61 components; CycloneDX 1.6 schema valid |
| Targeted export audit | Zero findings on 262 public source files |
| Wheel, normalized sdist and source ZIP | Each byte-identical across its two final builds |
| Actual release verifier | PASS; unsigned consistency only |

All 13 SQL files and seven shipped migrations are byte-identical to a6. All 13
runtime Python files are unchanged except the package version metadata. Schema 3
remains required and a7 adds no migration. The final wheel is byte-identical to
the earlier clean-venv-smoked wheel and all installed package members match source.

Native PostgreSQL/PgBouncer, real Zabbix, deployment E2E, hosted Actions, CodeQL,
Gitleaks, signed attestation issuance/verification and cross-platform reproduction
remain **NOT_RUN**. The workspace has no Docker or supported non-root native
runtime. The fresh records do not reuse historical service passes. G1–G8 remain
MANUAL_GATE_PENDING; 38 partial reference acceptance passes do not close them.

Node modules were reused only after byte-identical lock verification; fresh npm
installation/tarball verification was not repeated. No new dependencies were
introduced by these four controls. Raw logs, generated credentials, private lab
state and mutation copies are excluded from the handoff.

## Restore, deploy and roll back

The candidate ZIP includes `source/`, built `dist/`, this review, standalone
changelog, a6-to-a7 diff, verification result and checksums. Follow START_HERE.md
for exact restoration, including the explicit bundle branch. The source includes
plugins, SQL, CLI/services, collectors, media artifacts, deployment/rollback
scripts, all tests, new quality tooling and technical documentation. The separate
public website is not part of this code candidate.

Production examples remain disabled with empty cohorts/endpoints. For separately
authorized staging, use source/docs/deployment.md and rollback.md. Existing a6
schema-3 installations need no new SQL migration. Rollback remains a hold with
capture/ledger data retained; it must not unacknowledge events, delete migrations,
replay expired work or resume schema-2 workers against schema 3.

The consolidated deployment-input register is source/docs/INPUTS_REQUIRED.md:
installed revisions/topology, auth/customer/ingestion mappings, source/media/update
inventory, scoped cohorts, role/secret references, permissions, measured batches,
responders, records policy and the A2 transport resolution. The ten publication
inputs remain pending in source/config/publication.pending.json. Hosted analysis
and signing also need the reviewed repository variables, protected environments
and exact workflow policies described in their docs. No live secrets belong in
chat, public issues or the archive.
