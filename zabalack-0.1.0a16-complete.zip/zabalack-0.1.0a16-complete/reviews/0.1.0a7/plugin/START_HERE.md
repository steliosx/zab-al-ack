# Ackline 0.1.0a7 candidate

Read REVIEW-0.1.0a7.md and source/ALPHA_REPORT.md first. This is a local alpha;
service/hosted results and all deployment gates remain explicitly limited.

From this packet root, verify every file (including nested checksum lists):

```bash
sha256sum -c RELEASE_SHA256SUMS
```

Restore the exact local repository from its bundle, selecting its branch:

```bash
git clone --branch candidate/0.1.0a7 dist/ackline-0.1.0a7.bundle restored
cd restored
```

The checkout equals `source/` and the source ZIP. It has no configured hosted
remote. The clone's local bundle origin can be removed with `git remote remove
origin` if desired. No tag or public upload was performed.

Use Python 3.12 and the commands in README.md / docs/RELEASING.md. Install the
reference lock, hash-pinned quality lock and editable project. For the WASM lab:
`npm ci --prefix lab --legacy-peer-deps --ignore-scripts`. Then run quality,
mutation, SQL, reference, mapping and build commands in their documented order.
The complete workflow's required checks include native PostgreSQL/PgBouncer;
local alpha builds disclose NOT_RUN where the supported runtime is unavailable.

To verify the supplied artifacts against the extracted source without services:

```bash
cd source
python3.12 tools/verify_release.py --dist ../dist
```

This stdlib verifier establishes unsigned consistency, not a signed attestation.
The dist/SHA256SUMS file covers the build products; RELEASE_SHA256SUMS also covers
the bundle and every handoff/source file. Do not add files to the signing subject
list or confuse this local bundle with a hosted attestation.

Practical documentation: docs/mutation-testing.md, docs/deployment-e2e.md,
docs/security-automation.md and docs/release-provenance.md. The new deployment
lab's runtime is internal and synthetic, with no published ports. CodeQL and
service workflows require explicit repository enablement; signing/publication
templates remain inactive. Do not use live credentials for these lab commands.

Production deployment remains separately authorized: read docs/INPUTS_REQUIRED.md,
SPEC_AMENDMENTS.md A2, deployment.md and rollback.md. External writes are disabled
and no production cohort/endpoint is configured. Existing a6 schema-3 evaluation
installations require no new SQL migration for a7. Preserve all capture/ledger
records and do not automatically undo or retry source acknowledgements.
