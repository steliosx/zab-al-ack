# Evidence for the 0.1.0a7 candidate

Only fresh a7 execution records are exported here. Prior a6 reports were retained
outside this source selection before testing; Git history preserves their context.
No historical PASS was assigned a current digest.

`reference-run.json` selects the redacted phase JUnit reports used for acceptance;
`test-summary.json` separates layers. All 741 discovered cases were selected:
719 passed, 22 skipped, none failed. SQL/webhook groups, quickstart, repeat profile
runs and focused development runs are not added to that unique-case total.

`mutation-run.json` records the expanded curated profile: a 107-case passing
baseline, all 20 behavioral kills and no survivor/invalid/error/timeout. Only
assertion-based failures count; the real pinned pytest hook identifies failure
classes. This is Python unit/mock mutation coverage, not SQL/native mutation proof.
`quality-run.json` records pinned Ruff, mypy and dependency checks.

Implementation hashes cover `src`/`sql`. Harness hashes cover tests, tools, labs,
media, collectors, metadata, dependency/quality configuration, all GitHub policy,
release templates, deployment and configuration. Every executed runner records its
starting hashes and verifies unchanged inputs. Documentation/evidence, generated
metadata and caches are outside these digest scopes. The full source archive is
separately verified byte-for-byte; local hashes do not establish signed provenance.

`native-run.json`, `real-zabbix-run.json` and `deployment-e2e-run.json` remain
NOT_RUN because no supported native service runtime is available. Their reference
skips remain skips. The four deployment service cases do not have a passing lab
report. `automation-status.json` separates unavailable hosted CodeQL, attestation
and workflow execution from offline contract tests. No signed attestation exists
for this candidate, and no G1–G8 gate is satisfied.

`runtime_wasm_sql.json` records the eight executed supplemental SQL groups.
`security-scans.json`, `npm-audit.json` and `sbom-validation.json` distinguish
advisory/schema checks from unavailable secret scanning and external review.
`local-validation.json` and `wheel-smoke.json` record additional local checks.
Raw logs, generated secrets, private JUnit and mutant workspaces are excluded.

Interpretations, source-backed amendments, commands and deployment inputs are in
`ALPHA_REPORT.md` and `docs/RELEASING.md`. Exact built-artifact checksums are in the
handoff; archived evidence is not a substitute for the deployed G1–G8 inputs.
