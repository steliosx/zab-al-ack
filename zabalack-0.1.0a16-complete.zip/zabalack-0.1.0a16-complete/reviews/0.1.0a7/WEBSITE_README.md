# Ackline informational website

A simple, dependency-free marketing page for the independent Alerta-to-Zabbix
acknowledgement integration. `dist/` is the complete public site: HTML, CSS, an
original SVG monogram, technical documentation and a downloadable alpha brief. There is no
JavaScript, analytics, form, backend or connection to an Alerta/Zabbix endpoint.

The source integration repository and its release artifacts are deliberately not
included or published by this website. The docs include selected configuration
and command examples verified against packaged a7 interfaces. The page calls out its alpha readiness,
single-alert scope and independent project status. Reference versions describe
development interfaces, not a production support promise.

Brand direction: a lower-case Ackline wordmark, a geometric A/check monogram,
Alerta-inspired amber, white space and dark operational UI surfaces. The workflow
is a labelled synthetic HTML illustration, not a screenshot of shipped product UI.
Alerta and Netdata were used as high-level visual/marketing references; no text,
logos or screenshots were copied.

Open `dist/index.html` directly or serve the `dist/` directory from a static host.
No build or package installation is required. The custom SVG logo is in
`dist/assets/ackline-mark.svg`.

Claim references: the local 0.1.0a7 candidate, its frozen ALPHA_REPORT.md,
evidence, cumulative changelog and amendments R10/R11. The website reports
719 passed / 0 failed / 22 skipped in the recorded a7 reference run, with the
unit/mock/property and PostgreSQL WASM layers explicit. Native and real-Zabbix
services, deployment E2E, hosted CodeQL and signed attestations remain NOT_RUN
for a7. Earlier service results are not reassigned to this version. All G1–G8
and publication-owner inputs remain pending. Schema 3 and migration 007 are
required; upstream amendments A1/A2 are described in the docs and brief.

The website refresh changes informational content only. It neither rebuilds nor
changes the verified plugin release or its evidence. The full handoff ZIP keeps
those original bytes and includes the same public static files deployed here.
Public repository links must only be added once an approved destination exists.
Keep example data synthetic and readiness language accurate. No plugin source,
review packet or release archive is published by this informational site.

`dist/docs.html` is the practical technical guide, styled by `dist/docs.css`.
It covers isolated setup, inert configuration, the Alerta adapter, single-alert
workflow, inspection, audited pause, reconciliation semantics, test layers,
deployment boundaries, non-destructive rollback planning and local collectors.
The examples do not contain production endpoints or secrets. Database/operator
commands are labelled separately from commands safe to execute offline.
