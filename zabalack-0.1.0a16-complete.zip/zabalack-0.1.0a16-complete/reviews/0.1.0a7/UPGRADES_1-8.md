# Ackline: upgrades 1–8 and why they were made

This consolidated guide covers upgrades 1–4 in **0.1.0a6** and 5–8 in
**0.1.0a7**. The current plugin candidate is commit
`67f84543b430a6b1f9f0f9117bdf51e39d6b6014`, dated 2026-09-11 UTC.
The full historical changelog and decisions remain in
`plugin/source/CHANGELOG.md` and
`plugin/source/docs/RELEASE_AMENDMENTS.md` (R10 and R11).

This guide consolidates the existing a7 records. Preparing the website and
combined archive does not constitute a new execution of the plugin test suite.
Packaging and website checks belong to the combined archive's own verification
record; they do not replace or upgrade the original test evidence.

## The eight changes

| # | Delivered change | Why it matters | Recorded scope or remaining work |
|---|---|---|---|
| 1 | Execution-owned evidence and a CI collector that joins quality, reference and native results from the same repository, commit, run and attempt. Recorders invalidate prior success and bind results to source and harness digests. | A passing old report must not qualify changed code for packaging. A caller-supplied JUnit file must not substitute for fresh service execution. | Local evidence and negative validator tests ran. Hosted CI has not run for a7. Hash binding establishes consistency, not publisher identity. |
| 2 | Hash-pinned Ruff, gradual strict mypy and explicit validated identity/intent types. | Catch common implementation mistakes and make the most sensitive configuration, signing, policy and RPC boundaries easier to maintain. | Ruff, mypy and dependency checks passed. Strict typing covers four selected modules, not the entire project. |
| 3 | Hypothesis trust-boundary tests and generated sequences against restricted PostgreSQL ledger functions, with bounded PR and nightly profiles. | Exercise combinations of expiry, leases, settlement, retries and new action generations that individual examples can miss. | Pure tests and sequential PostgreSQL WASM tests ran. They do not prove native concurrency, authentication or PgBouncer behavior. The broader a6 sequence found the expiry defect described below. |
| 4 | Native worker process crash and race tests: competing workers, dropped responses, process death after remote commit, expired leases and stale completion. | Check that uncertainty and ownership fencing survive actual process loss without silently sending a second acknowledgement. | The native suite is implemented but NOT_RUN on the a7 workspace. Offline HTTPS/helper checks are separate evidence. |
| 5 | A reviewed mutation catalogue: 12 PR cases and 20 nightly cases, with a passing unchanged baseline, disposable source copies and assertion-only kills. A fresh mutation result is required for export and CI packaging. | Confirm that tests detect deliberate damage to authority, binding, identity and write guards. Import errors, timeouts and skipped tests must not inflate success. | Expanded local profile: 107 baseline tests passed and all 20 mutants were detected. A surviving wrong-event/trigger mutant exposed two missing regressions, now added. The production guard was already correct. |
| 6 | An isolated deployment-path lab using installed Alerta and worker processes, ordinary HTTP login, distinct native SQL logins, real Zabbix and its media/update flow. | Extend coverage beyond injected actors, mocked storage and direct helper calls, and exercise the normal installed application path. | 51 offline helper/orchestration cases passed; the four actual service cases are NOT_RUN. The new internal Docker project has no published ports or caller-supplied source endpoint. |
| 7 | Opt-in, commit-pinned CodeQL for Python and JavaScript/TypeScript, narrow result-upload permission and documented triage. | Add repeatable static security analysis while keeping repository access and alert handling explicit. | Offline workflow contracts passed. Hosted CodeQL, SARIF upload, rulesets and alert triage are NOT_RUN. A completed analysis alone would not mean zero alerts. |
| 8 | Strict release verification, an inactive attestation template and a consumer verifier that invokes a pinned cryptographic tool with exact workflow, tag and commit policy. | Detect changed package code, metadata, dependencies, entry points and evidence; prepare a verifiable origin for a future deliberately published release. | Actual a7 unsigned artifact consistency passed, as did offline rejection tests. Signed issuance and cryptographic verification of an Ackline attestation are NOT_RUN. No attestation has been issued. |

## The product fix found during these upgrades

The a6 generated ledger tests found a specific dead end: an operator explicitly
confirmed that an uncertain attempt had no effect before its original expiry;
the action became `failed`, but expiry cleanup left its effect open. A later
explicit human action could then remain coalesced behind that old generation.

Forward migration **007** changes only the expiry helper to include failed
actions whose reason is `operator_no_effect_confirmed`, after their original
deadline. It preserves the uncertainty, unresolved-attempt and live-lease guards.
Settlement does not enqueue a retry or write to Zabbix. An independent SQL
regression reproduces the old behavior before applying the forward migration.

Workers and readiness probes require **schema version 3**. An older installation
must follow the approved migration and readiness-resealing procedure. Existing
a6 schema-3 installations need no additional SQL for a7: migrations 001–007 and
all other SQL files are byte-identical to a6. The a7 runtime Python differs from
a6 only in package version metadata. See `plugin/source/docs/deployment.md` and
`plugin/source/docs/rollback.md`; rollback retains capture and ledger data and
must not replay expired work or unacknowledge source events.

## What the a7 records actually establish

These are the original final-tree candidate results, preserved with the plugin:

| Check | Recorded result |
|---|---|
| Reference pytest | **719 passed / 22 skipped / 0 failed**; all 741 discovered cases selected |
| Unit, mock, property and offline helper layer | 696 passed; includes the 51 deployment helper cases |
| PostgreSQL 18.3 WASM | 23 passed / 4 native-only skips; sequential SQL and documented adapter scope |
| Optional native and real services | 18 skipped / 0 passed; includes the four new deployment E2E cases |
| Expanded curated mutation profile | 107-case passing baseline; 20/20 assertion kills; zero survivors, invalid mutants, errors or timeouts |
| Ruff / gradual strict mypy / pip check | Passed |
| Supplemental SQL / synthetic webhook groups | 8 / 12 passed; not added to the unique pytest total |
| Isolated quickstart / clean-venv wheel smoke | Passed; the quickstart uses WASM and mocked source effects |
| Python / Node advisory queries | 58 packages with zero reported advisories / zero reported vulnerabilities at the recorded run |
| SBOM / targeted export audit | CycloneDX 1.6 schema valid, 61 components / zero findings on 262 public source files |
| Two final builds | Wheel, normalized sdist and source ZIP each byte-identical across the two builds |
| Release verifier | Passed for unsigned source/package/evidence consistency |

The authoritative layer breakdown is
`plugin/source/evidence/test-summary.json`; detailed interpretation is in
`plugin/source/ALPHA_REPORT.md` and `plugin/REVIEW-0.1.0a7.md`.
The source digest is
`2f9b9f784e85cf181efe31ccc8c2d7559a6e7dda391e557e0047df322c321bde`;
the harness digest is
`e337b92536a81457a0904f8aadd8b14af5f5ec015148488e7002029fc4cb0acb`.
Recorded zero findings are bounded results, not security clearance.

Native PostgreSQL/PgBouncer, real Zabbix, deployment E2E, hosted Actions,
CodeQL, Gitleaks, signed attestation issuance/verification and cross-platform
reproduction remain **NOT_RUN** for a7. Independent external security review
remains pending. The Node installation was reused after byte-identical lock
verification; a fresh npm installation/tarball verification was not repeated.
Historical a4/a5 service passes have not been relabeled as a7 results.

## Reference incompatibilities and deployment inputs

The source-backed amendments in `plugin/source/docs/SPEC_AMENDMENTS.md` remain
part of the deployment decision:

- **A1, Alerta 9.1.0:** provisional SQL and database error details can expose
  signing material. The supplied app wrapper installs the required privacy
  adapter. Deployed logging, handlers, tracing and notification subscribers
  still need inspection before enablement.
- **A2, Zabbix 7.0.10 webhook transport:** inspected `HttpRequest` source
  disables certificate peer/hostname verification and follows redirects.
  An HTTPS webhook URL alone does not authenticate the ingestion path. G1/G2
  require an inspected, approved transport remedy or enclosing authenticated
  control, with negative certificate, hostname and redirect tests. The worker's
  separate HTTPX client still verifies TLS and does not follow redirects.
- **Alerta startup ownership:** the installed Alerta factory performs schema
  work at startup. The service lab uses the documented trusted Alerta table-owner
  application login and separate Ackline migration/runtime roles. It does not
  prove that non-owner application startup works.

**G1–G8 remain MANUAL_GATE_PENDING.** The partial reference acceptance results
do not close deployment gates. Production examples retain disabled external
writes and empty cohorts/endpoints. No production service, trigger, credential
or acknowledgement has been changed by these upgrades.

`plugin/source/docs/INPUTS_REQUIRED.md` is the consolidated deployment register:
installed revisions/topology, customer and ingestion mappings, source/media/update
inventory, scoped cohorts, role and secret references, permissions, measured
batches, responders, records policy and A2 transport resolution. Publication-owner
inputs remain in `plugin/source/config/publication.pending.json`. Hosted analysis
and signing additionally require reviewed repository policy and workflow setup.
Engineers should provide secret references through approved local tooling, not
live credentials in chat or public files.

## Reviewer checklist for this combined handoff

- Verify the outer archive checksum list, including its nested checksum lists.
- Verify that `plugin/` retains the original a7 candidate bytes and its recorded
  source/harness identity; consult its `START_HERE.md` for bundle restoration.
- Compare the bundled `website/` files with the website revision recorded in the
  combined handoff. Website publication does not publish the plugin package.
- Read the cumulative changelog, R10/R11 and A1/A2 before interpreting headline
  test counts or choosing an upgrade path.
- Reproduce the reference checks from the pinned environment, then separately
  run the native, real-Zabbix and deployment-path suites on a supported isolated
  host. Record failures, skips and unavailable services as such.
- Before any production enablement or hosted issuance, complete the applicable
  input registers, ownership decisions and separately authorized deployment gates.

Useful implementation guides are under `plugin/source/docs/`:
`quality-checks.md`, `stateful-testing.md`, `native-fault-testing.md`,
`mutation-testing.md`, `deployment-e2e.md`, `security-automation.md`,
`release-provenance.md`, `RELEASING.md`, `deployment.md` and `rollback.md`.
