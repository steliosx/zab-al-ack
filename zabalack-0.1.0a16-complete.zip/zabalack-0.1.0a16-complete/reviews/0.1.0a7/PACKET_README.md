# Ackline 0.1.0a7 — complete handoff

This single ZIP contains the current plugin, all upgrades 1–8, built artifacts,
full cumulative changelog, review evidence and the matching public static site.

| Location | Contents |
|---|---|
| [UPGRADES_1-8.md](UPGRADES_1-8.md) | Consolidated changes, justification, evidence limits and reviewer checklist |
| [plugin/source/CHANGELOG.md](plugin/source/CHANGELOG.md) | Full cumulative plugin changelog, including a6 (1–4) and a7 (5–8) |
| [plugin/source/docs/RELEASE_AMENDMENTS.md](plugin/source/docs/RELEASE_AMENDMENTS.md) | Detailed reasoning, including R10/R11 |
| [plugin/START_HERE.md](plugin/START_HERE.md) | Source restoration, build and verification commands |
| `plugin/dist/` | Wheel, sdist, source ZIP, unsigned provenance, checksums and Git bundle |
| [plugin/REVIEW-0.1.0a7.md](plugin/REVIEW-0.1.0a7.md) | Recorded tests, findings and unexecuted checks |
| [plugin/source/docs/INPUTS_REQUIRED.md](plugin/source/docs/INPUTS_REQUIRED.md) | Consolidated deployment input register |
| [plugin/source/docs/deployment.md](plugin/source/docs/deployment.md) | Installation, migration, readiness and activation procedure |
| [plugin/source/docs/rollback.md](plugin/source/docs/rollback.md) | Non-destructive rollback instructions |
| [website/index.html](website/index.html) | Portable static homepage, documentation and assets |
| [WEBSITE_README.md](WEBSITE_README.md) | Static hosting and content notes |
| `verification/` | Checks performed for this combined handoff |
| `COMPLETE_MANIFEST.json` | Plugin identity and published website revision |

## What changed in this handoff

The website now describes a7 and all eight engineering upgrades. Practical docs
include the quality, mutation, release-verification and service-lab plan commands.
Schema 3 and migration 007 replace the stale schema-2 guidance. The alpha brief
now records a7 evidence, the addressed a5 tooling findings and open A1/A2 and
startup-ownership constraints. Existing design, assets and static behavior remain.

These changes bring the public claims into line with the delivered candidate.
The plugin itself is preserved byte for byte: all 275 files are identical to the
previously delivered a7 packet, including the original nested checksum lists.
No plugin suite was rerun, no new binary version was created and no old evidence
was relabeled. Statements in the frozen plugin reports about the website being
outside that build describe the original plugin task; this handoff separately
records the website update.

Recorded a7 reference results remain **719 passed / 22 skipped / 0 failed**.
Native services, deployment E2E, hosted checks and signed attestations remain
NOT_RUN for a7. G1–G8 and publication-owner inputs remain pending. Website
publication did not publish the plugin or authorize any monitoring-system change.

## Verify and open

From this extracted folder, verify the complete handoff:

```sh
sha256sum -c SHA256SUMS
```

The outer list covers every other file, including all nested checksum lists.
For the immutable plugin's own check, enter `plugin/` and run:

```sh
sha256sum -c RELEASE_SHA256SUMS
```

Follow `plugin/START_HERE.md` for the artifact verifier and exact Git-bundle
restoration. Checksums and local provenance are unsigned consistency evidence.

Open `website/index.html` directly. To host elsewhere, serve only `website/` as
static files. Do not publish this complete ZIP as the website's document root.
No JavaScript, analytics, forms, service credentials or monitoring connection is
included in the site. The public revision is at https://ackline.stel.chatgpt.site.

The source and wheel should stay together: SQL, deployment tooling, collectors,
versioned media artifacts and tests are in the source, not installed by the wheel.
Production examples remain disabled with no active cohort. Use the matching
input register and deployment/rollback procedure before any separately approved
pilot.
