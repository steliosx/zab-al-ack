"""Assemble one reviewed handoff after all gates below have completed locally."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil
import subprocess
import sys
import zipfile

BASE = Path(__file__).resolve().parents[1]
SOURCE = BASE / "zabalack"
MATERIAL = BASE / "review-material"
SITE = BASE.parent / "ackline-site"
NAME = "zabalack-0.1.0a12-reviewed-complete"
PACKET = BASE / "handoff" / NAME
OUTPUT = BASE.parent / "deliverables" / (NAME + ".zip")
sys.path.insert(0, str(SOURCE / "tools"))
from public_audit import audit, public_files  # noqa: E402


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def copy(source, destination):
    assert source.is_file() and not source.is_symlink()
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)


def main():
    assert audit(SOURCE)["status"] == "PASS"
    assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=SOURCE)
    assert json.loads((MATERIAL / "site-checks.json").read_text())["status"] == "PASS"
    assert json.loads((MATERIAL / "site-publication.json").read_text())["status"] == "succeeded"
    assert json.loads((MATERIAL / "results.json").read_text())["status"] == "COMPLETE"
    assert json.loads((MATERIAL / "package-verification.json").read_text())["status"] == "PASS"
    assert json.loads((MATERIAL / "lab-final-shutdown.json").read_text())["status"] == "STOPPED"
    assert not PACKET.exists(), "Fresh output directory required"
    PACKET.mkdir(parents=True)
    for path in public_files(SOURCE):
        copy(path, PACKET / "plugin/source" / path.relative_to(SOURCE))
    for path in sorted((SOURCE / "dist").rglob("*")):
        if path.is_file():
            copy(path, PACKET / "dist" / path.relative_to(SOURCE / "dist"))
    copy(MATERIAL / "source-review.bundle", PACKET / "dist/source-review.bundle")
    for path in sorted((SITE / "dist").rglob("*")):
        if path.is_file():
            copy(path, PACKET / "website" / path.relative_to(SITE / "dist"))
    for path in sorted((BASE / "supplied/zabalack-0.1.0a12-complete/visual-previews").glob("*.png")):
        copy(path, PACKET / "visual-previews" / path.name)
    for name in ("README.md", "SITE_CHANGELOG.md"):
        copy(SITE / name, PACKET / "website-source-notes" / name)
    copy(BASE.parent / "upload/zabalack-0.1.0a12-complete.zip",
         PACKET / "original-input/zabalack-0.1.0a12-complete.zip")
    for path in sorted((BASE / "independent-evidence").rglob("*")):
        if path.is_file():
            copy(path, PACKET / "review/evidence" / path.relative_to(BASE / "independent-evidence"))
    for path in sorted(MATERIAL.rglob("*")):
        if path.is_file() and path.name not in {"source-review.bundle", "results-draft.json"} and "__pycache__" not in path.parts:
            copy(path, PACKET / "review" / path.relative_to(MATERIAL))
    copy(SOURCE / "CHANGELOG.md", PACKET / "CHANGELOG.md")
    copy(SOURCE / "docs/INPUTS_REQUIRED.md", PACKET / "DEPLOYMENT_INPUTS_REQUIRED.md")
    readme = """# Zab-al-ack 0.1.0a12 — independently reviewed complete handoff

Start with `review/REVIEW.md` and `review/results.json`. This reviewed edition
corrects the lab role fixture (A4); runtime Python, SQL and wheel bytes match
the original candidate. It is not a new tagged or published plugin release.

- `plugin/source/`: corrected source, full cumulative changelog, deployment and
  rollback instructions, acceptance mapping and current bound evidence.
- `dist/`: wheel, normalized sdist, source ZIP, build provenance, checksums and
  local review Git bundle. No remote plugin push was performed.
- `website/`: the updated informational static site, including docs and blog.
- `review/`: findings, actual test/build/publication records, failed attempts,
  source inspection hashes, executed VM helpers and reproduction recipe.
- `original-input/`: the supplied a12 complete ZIP, retained byte-for-byte with
  its prior artifacts, reviews, screenshots and cumulative history.
- `DEPLOYMENT_INPUTS_REQUIRED.md`: the consolidated outstanding input register.

All production gates G1–G8 remain pending. A2's webhook transport remedy is
unresolved. Production examples are disabled with no active cohort. No live
monitoring credentials or production access were used. VM services are stopped.

Verify this packet from its extracted root with `sha256sum -c SHA256SUMS`.
That list covers every other file, including nested checksum lists and the
unchanged original ZIP. The outer ZIP's digest is returned with the download.

Use `plugin/source/docs/deployment.md`, `runbook.md`, `local-services.md`, and
`plugin/source/docs/RENAME.md` for deployment/rollback boundaries; the first three
paths are relative to `plugin/source/docs/`. Do not infer an in-place legacy
Ackline database upgrade. The `review/reproduction/` recipe is for disposable
services only. No secrets, VM disks or compiled OS binaries are included.
"""
    (PACKET / "README.md").write_text(readme)
    files = sorted(p for p in PACKET.rglob("*") if p.is_file())
    (PACKET / "SHA256SUMS").write_text("".join(sha(p) + "  " + p.relative_to(PACKET).as_posix() + "\n" for p in files))
    OUTPUT.parent.mkdir(exist_ok=True)
    timestamp = (2026, 9, 12, 0, 0, 0)
    with zipfile.ZipFile(OUTPUT, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(p for p in PACKET.rglob("*") if p.is_file()):
            info = zipfile.ZipInfo(NAME + "/" + path.relative_to(PACKET).as_posix(), timestamp)
            info.create_system = 3
            info.external_attr = (0o100755 if path.stat().st_mode & 0o111 else 0o100644) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, path.read_bytes())
    # Fresh extraction and exact complete checksum-set verification.
    verified = BASE / "handoff-verified"
    assert not verified.exists()
    with zipfile.ZipFile(OUTPUT) as archive:
        assert archive.testzip() is None
        archive.extractall(verified)
    extracted = verified / NAME
    rows = {}
    for line in (extracted / "SHA256SUMS").read_text().splitlines():
        digest, name = line.split("  ", 1)
        assert name not in rows
        rows[name] = digest
    actual = {p.relative_to(extracted).as_posix(): sha(p) for p in extracted.rglob("*")
              if p.is_file() and p != extracted / "SHA256SUMS"}
    assert rows == actual
    record = {"status": "PASS", "archive": str(OUTPUT), "sha256": sha(OUTPUT),
              "size_bytes": OUTPUT.stat().st_size, "checksum_entries": len(rows),
              "fresh_unzip_and_complete_checksums": True,
              "verified_at_utc": datetime.now(timezone.utc).isoformat()}
    (BASE / "final-archive-verification.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()
