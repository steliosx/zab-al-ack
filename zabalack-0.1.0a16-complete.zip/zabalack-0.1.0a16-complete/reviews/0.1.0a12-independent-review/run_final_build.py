"""Wait for this review's final service job, then run the existing export gates."""
from pathlib import Path
from datetime import datetime, timezone
import json
import os
import subprocess
import time

BASE = Path(__file__).resolve().parents[1]
REPO = BASE / "zabalack"
MATERIAL = BASE / "review-material"
PYTHON = str(BASE / "venv/bin/python")
done = BASE / "vm/private/jobs/38-final-real-api-suites.done"
deadline = time.monotonic() + 1200
while not done.exists() and time.monotonic() < deadline:
    time.sleep(5)
assert done.exists() and json.loads(done.read_text())["exit_code"] == 0
commands = [
    [PYTHON, str(MATERIAL / "finalize_evidence.py")],
    [PYTHON, "tools/update_acceptance.py"],
    [PYTHON, "tools/public_audit.py", "--write-report"],
    [PYTHON, "tools/build_release.py"],
    [PYTHON, "tools/verify_release.py"],
    [PYTHON, str(MATERIAL / "verify_site.py"), str(BASE.parent / "ackline-site/dist"),
     str(MATERIAL / "site-checks.json")],
]
records = []
private = BASE / "build-private"
private.mkdir(exist_ok=True)
env = dict(os.environ, TZ="UTC")
for i, command in enumerate(commands):
    with (private / ("final-" + str(i) + ".log")).open("w") as output:
        result = subprocess.run(command, cwd=REPO, env=env, stdout=output,
                                stderr=subprocess.STDOUT, timeout=600)
    record = {"step": i, "command": [Path(command[0]).name, *[
        arg.replace(str(BASE.parent), "WORKSPACE") for arg in command[1:]]],
        "exit_code": result.returncode, "finished_at_utc": datetime.now(timezone.utc).isoformat()}
    records.append(record)
    (MATERIAL / "final-build-commands.json").write_text(json.dumps(records, indent=2) + "\n")
    print(json.dumps(record), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
