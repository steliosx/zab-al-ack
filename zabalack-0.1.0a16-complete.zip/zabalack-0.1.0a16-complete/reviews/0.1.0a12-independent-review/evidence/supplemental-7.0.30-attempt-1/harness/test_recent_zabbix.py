"""Supplemental real API checks; synthetic VM only, never deployment gates.

T29 below checks the real client's lost-response classification and reference
lookup. It does not claim to exercise the durable reconciler or HA fencing.
"""
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import asyncio
import json
import os
import secrets
import threading
import time

import httpx
import pytest

from zabalack.rpc import Endpoint, ZabbixClient, RPCError, ValidationError, validate_event, observed_reference
from prepare_source_fixture import LabAPI, LabAPIError, URL, PRIVATE

@pytest.fixture(scope='module')
def lab():
    assert os.environ.get('ACK_TEST_REAL_ZABBIX_LAB')=='YES_ISOLATED_LAB'
    assert os.environ.get('ACK_TEST_REAL_ZABBIX_WRITE')=='ACKNOWLEDGE_SYNTHETIC_LAB_EVENT'
    fixture=json.loads((PRIVATE/'fixture.json').read_text())
    assert fixture['url']==URL and fixture['isolated_lab'] is True and fixture['fresh_instance_no_notifications'] is True
    extra=json.loads((PRIVATE/'extra.json').read_text())
    assert extra['version'] in ('7.0.10','7.0.30')
    admin=LabAPI()
    assert admin.call('apiinfo.version',{},anonymous=True)==extra['version']
    assert admin.call('action.get',{'output':['actionid'],'filter':{'status':0}},token=(PRIVATE/'admin.session').read_text())==[]
    admin.token=(PRIVATE/'admin.session').read_text()
    def client(token_file=None, url=URL):
        assert url in (URL,'http://127.0.0.1:59082/api_jsonrpc.php')
        return ZabbixClient(Endpoint('isolated-review',url,token_file or fixture['token_file'],None,api_version=extra['version'],lab=True))
    yield fixture,extra,admin,client
    admin.client.close()

def source(problem):
    return {'zabbix_event_id':problem['event'],'zabbix_trigger_id':problem['trigger']}

def stamp():
    return datetime.now(timezone.utc).isoformat(timespec='seconds').replace('+00:00','Z')

@pytest.mark.asyncio
async def test_T26_resolved_original_problem_is_acknowledged_recovery_untouched(lab):
    fixture,extra,admin,client=lab
    p=extra['problems']['resolved']
    admin.push(p['item'],0)
    for _ in range(90):
        rows=await client().event_get(p['event'],fixture['cohort'])
        event=validate_event(rows,source(p),fixture['cohort'])
        if event['r_eventid']!='0':break
        await asyncio.sleep(1)
    else:pytest.fail('Synthetic recovery was not observed')
    recovery=event['r_eventid']
    ref=secrets.token_urlsafe(18)
    await client().acknowledge(p['event'],comment=True,public_reference=ref,issued_at=stamp())
    original=validate_event(await client().event_get(p['event'],fixture['cohort'],history=True),source(p),fixture['cohort'])
    assert original['acknowledged']=='1' and original['r_eventid']==recovery
    recovered=admin.call('event.get',{'eventids':[recovery],'output':['eventid','value','acknowledged'],'selectAcknowledges':['message','action']})[0]
    assert recovered['value']=='0' and recovered['acknowledged']=='0' and recovered['acknowledges']==[]

@pytest.mark.asyncio
async def test_T12_multi_host_event_returns_full_set_and_is_rejected(lab):
    fixture,extra,admin,client=lab
    p=extra['problems']['multi']
    witness=client(fixture['outside_scope_source']['witness_token_file'])
    rows=await witness.event_get(p['event'],fixture['cohort'])
    assert {h['hostid'] for h in rows[0]['hosts']}==set(extra['hosts'])
    with pytest.raises(ValidationError,match='host_set_mismatch'):
        validate_event(rows,source(p),fixture['cohort'])
    assert rows[0]['acknowledged']=='0'

@pytest.mark.asyncio
async def test_action_2_acknowledges_without_customer_visible_comment(lab):
    fixture,extra,admin,client=lab
    p=extra['problems']['ack_only']
    before=validate_event(await client().event_get(p['event'],fixture['cohort']),source(p),fixture['cohort'])
    assert before['acknowledged']=='0'
    await client().acknowledge(p['event'],comment=False,public_reference=secrets.token_urlsafe(18),issued_at=stamp())
    after=validate_event(await client().event_get(p['event'],fixture['cohort'],history=True),source(p),fixture['cohort'])
    assert after['acknowledged']=='1'
    assert len(after['acknowledges'])==1 and after['acknowledges'][0]['action']=='2'
    assert after['acknowledges'][0]['message']==''

@pytest.mark.parametrize('action,extra_params,reason',[(1,{},'no permissions to close problems'),(8,{'severity':4},'no permissions to change problem severity'),(32,{'suppress_until':0},'no permissions to suppress problems')])
def test_T28_source_role_denies_excluded_actions(lab,action,extra_params,reason):
    fixture,extra,admin,client=lab
    p=extra['problems']['permissions']
    token=Path(fixture['token_file']).read_text()
    before=admin.call('event.get',{'eventids':[p['event']],'output':['acknowledged','severity'],'selectAcknowledges':['action']})
    with pytest.raises(LabAPIError) as caught:
        admin.call('event.acknowledge',{'eventids':[p['event']],'action':action,**extra_params},token=token)
    assert caught.value.code==-32602 and caught.value.permission_reason==reason
    after=admin.call('event.get',{'eventids':[p['event']],'output':['acknowledged','severity'],'selectAcknowledges':['action']})
    assert before==after

def test_T11a_source_denies_outside_scope_acknowledgement(lab):
    fixture,extra,admin,client=lab
    p=extra['problems']['outside']
    with pytest.raises(LabAPIError) as caught:
        admin.call('event.acknowledge',{'eventids':[p['event']],'action':2},token=Path(fixture['token_file']).read_text())
    assert caught.value.permission_reason=='No permissions to referred object or it does not exist!'
    row=admin.call('event.get',{'eventids':[p['event']],'output':['acknowledged'],'selectAcknowledges':['action']})[0]
    assert row['acknowledged']=='0' and row['acknowledges']==[]

@pytest.mark.asyncio
async def test_source_role_shares_ack_unack_permission_but_product_client_blocks_unack(lab):
    fixture,extra,admin,client=lab
    p=extra['problems']['permissions']
    with pytest.raises(RPCError,match='write_scope_invalid'):
        await client().call('event.acknowledge',{'eventids':[p['event']],'action':16})
    # This separate synthetic fixture explicitly measures the broader upstream
    # permission. The integration itself never sends the action=16 request.
    await client().acknowledge(p['event'],comment=False,public_reference=secrets.token_urlsafe(18),issued_at=stamp())
    result=admin.call('event.acknowledge',{'eventids':[p['event']],'action':16},token=Path(fixture['token_file']).read_text())
    assert result=={'eventids':[p['event']]}
    after=validate_event(await client().event_get(p['event'],fixture['cohort'],history=True),source(p),fixture['cohort'])
    assert after['acknowledged']=='0' and {r['action'] for r in after['acknowledges']}=={'2','16'}

@pytest.mark.asyncio
async def test_T28_expired_token_returns_bounded_client_failure(lab):
    fixture,extra,admin,client=lab
    token=extra['expiring']
    admin.call('token.update',{'tokenid':token['token_id'],'expires_at':int(time.time())-1})
    with pytest.raises(RPCError,match='api_permission_or_request_rejected'):
        await client(token['file']).event_get(extra['problems']['permissions']['event'],fixture['cohort'])

@pytest.mark.asyncio
async def test_T29_real_write_response_lost_source_reference_observed_once(lab):
    fixture,extra,admin,client=lab
    p=extra['problems']['lost_response']
    ref,issued=secrets.token_urlsafe(18),stamp()
    counts={'writes':0}
    class Proxy(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def do_POST(self):
            assert self.path=='/api_jsonrpc.php'
            length=int(self.headers['Content-Length'])
            assert 0<length<65536
            body=self.rfile.read(length)
            request=json.loads(body)
            assert request['method'] in ('event.get','event.acknowledge','host.get')
            with httpx.Client(timeout=15,trust_env=False,follow_redirects=False) as upstream:
                response=upstream.post(URL,content=body,headers={'Content-Type':'application/json','Authorization':self.headers['Authorization']})
            if request['method']=='event.acknowledge':
                assert request['params']['eventids']==[p['event']]
                assert response.status_code==200 and response.json().get('result')=={'eventids':[p['event']]}
                counts['writes']+=1
                self.close_connection=True
                return  # Real write completed; deliberately discard its HTTP response.
            self.send_response(response.status_code)
            self.send_header('Content-Length',str(len(response.content)))
            self.end_headers()
            self.wfile.write(response.content)
    proxy=ThreadingHTTPServer(('127.0.0.1',59082),Proxy)
    thread=threading.Thread(target=proxy.serve_forever,daemon=True)
    thread.start()
    try:
        faulted=client(url='http://127.0.0.1:59082/api_jsonrpc.php')
        validate_event(await faulted.event_get(p['event'],fixture['cohort']),source(p),fixture['cohort'])
        with pytest.raises(RPCError) as caught:
            await faulted.acknowledge(p['event'],comment=True,public_reference=ref,issued_at=issued)
        assert caught.value.uncertain is True and caught.value.reason=='outcome_unknown'
        observed=validate_event(await client().event_get(p['event'],fixture['cohort'],history=True),source(p),fixture['cohort'])
        assert observed['acknowledged']=='1' and observed_reference(observed,public_reference=ref,issued_at=issued)
        assert len([row for row in observed['acknowledges'] if ref in row['message']])==1
        assert counts['writes']==1
    finally:
        proxy.shutdown();proxy.server_close();thread.join(timeout=5)
