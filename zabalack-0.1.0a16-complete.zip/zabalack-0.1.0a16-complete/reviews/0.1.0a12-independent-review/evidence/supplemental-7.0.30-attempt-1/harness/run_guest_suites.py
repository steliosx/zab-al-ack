"""Run the original a12 service suites inside this disposable emulated VM."""
from pathlib import Path
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil
import subprocess
import sys

ROOT=Path('/opt/review')
REPO=ROOT/'zabalack'
SHARE=Path('/mnt/review')
PYTHON=ROOT/'venv/bin/python'
ENV=dict(os.environ, TZ='UTC', ACK_LAB_PG_BIN=str(ROOT/'native/pg18/bin'),
         ACK_LAB_PGBOUNCER_BIN=str(ROOT/'native/pgbouncer/bin/pgbouncer'))

def run(args, **kw):
    return subprocess.run(list(map(str,args)),cwd=REPO,env=ENV,**kw)

def archive_evidence(label, names):
    target=SHARE/'results'/label
    target.mkdir(parents=True,exist_ok=True)
    for name in names:
        for path in (REPO/'evidence').glob(name):
            shutil.copyfile(path,target/path.name)
    (target/'execution-context.json').write_text(json.dumps({
        'layer':'native binaries in a full Ubuntu VM using QEMU TCG CPU emulation',
        'docker':False,'performance_scope':'functional checks only; emulated timing is not a deployment benchmark',
        'production_access':False,'deployment_gates':'MANUAL_GATE_PENDING',
        'source_commit':'af03590226cd2b7b2100e7293d62e975d5549e4e',
        'finished_at_utc':datetime.now(timezone.utc).isoformat()},indent=2)+'\n')

def fresh_cluster():
    state=REPO/'.lab'
    if state.exists():
        assert (state/'ISOLATED_ACK_LAB').is_file()
        run([PYTHON,'lab/local_runtime.py','stop','--isolated-lab'])
        # Inspect through the same unprivileged OS service user.
        status=run(['runuser','-u','nobody','--',ROOT/'native/pg18/bin/pg_ctl','-D',state/'pgdata','status'],capture_output=True)
        assert status.returncode==3, 'Declared cluster must be stopped before a fresh phase'
        shutil.rmtree(state)
    run([PYTHON,'lab/local_runtime.py','start','--isolated-lab'],check=True)
    run([ROOT/'native/pg18/bin/psql','postgresql://lab_admin@127.0.0.1:55432/postgres','-v','ON_ERROR_STOP=1','-c','CREATE DATABASE alerta OWNER lab_admin'],check=True)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--isolated-lab',action='store_true',required=True)
    parser.add_argument('suite',choices=['native','contract','supplemental'])
    parser.add_argument('--version',choices=['7.0.10','7.0.30'])
    args=parser.parse_args()
    assert os.geteuid()==0 and SHARE.is_mount() and (SHARE/'guest-provisioned.json').is_file()
    if args.suite=='native':
        result=run([PYTHON,'tools/native_local.py','--isolated-lab'])
        archive_evidence('native',['native-*.json','native-*.xml'])
        return result.returncode
    assert args.version
    ENV.update(ACK_TEST_REAL_ZABBIX_LAB='YES_ISOLATED_LAB',ACK_TEST_REAL_ZABBIX_WRITE='ACKNOWLEDGE_SYNTHETIC_LAB_EVENT',
               ACK_TEST_REAL_ZABBIX_FIXTURE='/run/zabalack-review/fixture.json')
    if args.suite=='contract':
        fresh_cluster()
        ENV.update(ACK_TEST_ADMIN_DSN='postgresql://lab_admin@127.0.0.1:55432/alerta',ACK_TEST_DESTRUCTIVE_LAB='YES_ISOLATED_LAB')
        try:
            result=run([PYTHON,'tools/record_real_zabbix.py','--run','--timeout','900'])
            archive_evidence('real-zabbix-'+args.version,['real-zabbix-run.json','real-zabbix.xml'])
            return result.returncode
        finally:
            run([PYTHON,'lab/local_runtime.py','stop','--isolated-lab'],check=True)
    # Own this supplemental execution, bind before and after, and leak-check the
    # staged report. Never import a prior XML or overwrite the release catalogue.
    sys.path.insert(0,str(REPO/'tools'))
    from evidence_utils import code_digests, redact_junit, cases
    from record_real_zabbix import forbidden_terms
    private=Path('/run/zabalack-review')
    raw=private/'supplemental.xml'
    staged=private/'supplemental-public.xml'
    target=SHARE/'results'/('supplemental-'+args.version)
    target.mkdir(parents=True,exist_ok=True)
    if (target/'run.json').exists():
        raise RuntimeError('Retain the previous supplemental run before retrying')
    raw.unlink(missing_ok=True)
    staged.unlink(missing_ok=True)
    before=code_digests(REPO)
    names=('test_recent_zabbix.py','prepare_source_fixture.py','run_guest_suites.py','zabbix_services.py')
    def harness():
        return {name:hashlib.sha256((SHARE/name).read_bytes()).hexdigest() for name in names}
    before_harness=harness()
    extra_private=[private/'admin.session',private/'review-expiring.token']
    terms=forbidden_terms(private/'fixture.json',[],extra_private)
    record={'status':'RUNNING','counts':{'passed':0,'failed':0,'skipped':0},
            'version':args.version,'code_digests':before,'harness':before_harness,
            'deployment_gates':'MANUAL_GATE_PENDING','layer':'supplemental real Zabbix API in QEMU TCG guest',
            'started_at_utc':datetime.now(timezone.utc).isoformat()}
    (target/'run.json').write_text(json.dumps(record,indent=2)+'\n')
    ENV.update(PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',PYTHONPATH=str(REPO/'src')+os.pathsep+str(SHARE))
    try:
        result=run([PYTHON,'-m','pytest','-p','pytest_asyncio.plugin','-p','no:cacheprovider',
                    '/mnt/review/test_recent_zabbix.py','-q','-ra','--junitxml='+str(raw)],timeout=900)
        exit_code=result.returncode
    except subprocess.TimeoutExpired:
        exit_code=124
    if raw.exists():
        redact_junit(raw,staged,REPO)
        rows=cases(staged)
    else:rows=[]
    counts={status:sum(r['status']==status for r in rows) for status in ('passed','failed','skipped')}
    unchanged=before==code_digests(REPO) and before_harness==harness()
    secrets_unchanged=terms==forbidden_terms(private/'fixture.json',[],extra_private)
    leak_free=staged.exists() and all(term not in staged.read_text() for term in terms)
    record.update(status='PASS' if exit_code==0 and counts=={'passed':10,'failed':0,'skipped':0} and unchanged and secrets_unchanged and leak_free else 'FAIL',
                  counts=counts,exit_code=exit_code,tree_unchanged=unchanged,
                  private_inputs_unchanged=secrets_unchanged,public_evidence_leak_check=bool(leak_free),
                  finished_at_utc=datetime.now(timezone.utc).isoformat())
    if leak_free:
        shutil.copyfile(staged,target/'tests.xml')
    if record['status']!='PASS':
        record['reason']='supplemental_execution_or_evidence_validation_failed'
    (target/'run.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record),flush=True)
    return 0 if record['status']=='PASS' else 1

if __name__=='__main__':
    raise SystemExit(main())
