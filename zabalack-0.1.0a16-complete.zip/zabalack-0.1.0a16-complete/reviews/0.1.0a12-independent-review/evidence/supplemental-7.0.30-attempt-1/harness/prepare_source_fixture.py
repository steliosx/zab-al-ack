"""Generate real synthetic problem events and restricted tokens on a fresh local lab."""
from pathlib import Path
import argparse
import json
import os
import secrets
import sys
import time

import httpx

URL='http://127.0.0.1:58080/api_jsonrpc.php'
PRIVATE=Path('/run/zabalack-review')

class LabAPIError(RuntimeError):
    def __init__(self, method, envelope):
        super().__init__('synthetic_api_'+method+'_rejected')
        error=envelope.get('error',{})
        self.code=error.get('code') if isinstance(error,dict) else None
        data=error.get('data','') if isinstance(error,dict) else ''
        reasons=('no permissions to close problems','no permissions to change problem severity',
                 'no permissions to suppress problems','No permissions to referred object or it does not exist!')
        self.permission_reason=next((r for r in reasons if isinstance(data,str) and r in data),None)

class LabAPI:
    def __init__(self):
        self.client=httpx.Client(timeout=20,trust_env=False,follow_redirects=False)
        self.token=None
        self.sequence=0
    def call(self, method, params, token=None, anonymous=False):
        self.sequence+=1
        auth=None if anonymous else (token or self.token)
        response=self.client.post(URL,json={'jsonrpc':'2.0','method':method,'params':params,'id':self.sequence},
            headers={'Authorization':'Bearer '+auth} if auth else {})
        response.raise_for_status()
        body=response.json()
        if body.get('id')!=self.sequence or 'error' in body or 'result' not in body:
            raise LabAPIError(method,body)
        return body['result']
    def create(self, method, params, field):
        return self.call(method,params)[field][0]
    def push(self,item,value):
        end=time.monotonic()+90
        while time.monotonic()<end:
            result=self.call('history.push',[{'itemid':item,'value':value}])
            if result.get('response')=='success' and result.get('data') and all('error' not in r for r in result['data']):
                return
            time.sleep(1)
        raise RuntimeError('synthetic_history_cache_deadline')
    def event(self,trigger):
        end=time.monotonic()+90
        while time.monotonic()<end:
            rows=self.call('event.get',{'objectids':[trigger],'source':0,'object':0,'value':1,'output':['eventid','objectid','acknowledged']})
            if len(rows)==1 and rows[0]['objectid']==trigger and rows[0]['acknowledged']=='0':
                return rows[0]['eventid']
            time.sleep(1)
        raise RuntimeError('synthetic_event_deadline')

def protected(name,value):
    path=PRIVATE/name
    path.write_text(value)
    path.chmod(0o600)
    return str(path)

def prepare(version):
    assert os.geteuid()==0 and Path('/mnt/review').is_mount()
    assert Path('/opt/review/zabbix-state/ISOLATED_REVIEW_LAB').is_file()
    PRIVATE.mkdir(mode=0o700,exist_ok=True)
    PRIVATE.chmod(0o700)
    api=LabAPI()
    assert api.call('apiinfo.version',{},anonymous=True)==version
    print('Verified fresh loopback API version',version,flush=True)
    api.token=api.call('user.login',{'username':'Admin','password':'zabbix'},anonymous=True)
    print('Authenticated synthetic bootstrap identity',flush=True)
    assert api.call('action.get',{'output':['actionid'],'filter':{'status':0}})==[], 'No active actions allowed in this contract fixture'
    assert api.call('hostgroup.get',{'output':['groupid'],'filter':{'name':'Zab-al-ack review cohort'}})==[], 'Fresh lab required'
    groups=[api.create('hostgroup.create',{'name':name},'groupids') for name in ('Zab-al-ack review cohort','Zab-al-ack review outside')]
    hosts=[api.create('host.create',{'host':'review-synthetic-'+str(i),'groups':[{'groupid':g}],'interfaces':[]},'hostids') for i,g in enumerate(groups)]
    problems={}
    for name,host,host_name in [('source',hosts[0],'review-synthetic-0'),('e2e',hosts[0],'review-synthetic-0'),('outside',hosts[1],'review-synthetic-1'),('resolved',hosts[0],'review-synthetic-0'),('ack_only',hosts[0],'review-synthetic-0'),('permissions',hosts[0],'review-synthetic-0'),('lost_response',hosts[0],'review-synthetic-0')]:
        key='review.'+name
        item=api.create('item.create',{'hostid':host,'name':'Synthetic '+name,'key_':key,'type':2,'value_type':3,'delay':'0','trapper_hosts':''},'itemids')
        trigger=api.create('trigger.create',{'description':'Review synthetic '+name,'expression':f'last(/{host_name}/{key})=1','priority':2},'triggerids')
        problems[name]={'item':item,'trigger':trigger}
    multi_items=[]
    for i,host in enumerate(hosts):
        multi_items.append(api.create('item.create',{'hostid':host,'name':'Synthetic multi-host input','key_':'review.multi','type':2,'value_type':3,'delay':'0','trapper_hosts':''},'itemids'))
    multi=api.create('trigger.create',{'description':'Review synthetic multi-host','expression':'last(/review-synthetic-0/review.multi)=1 and last(/review-synthetic-1/review.multi)=1','priority':2},'triggerids')
    print('Created isolated groups, hosts, trapper items and triggers',flush=True)
    def account(name, methods, permissions, rights):
        role=api.create('role.create',{'name':name,'type':1,'rules':{'ui.default_access':0,'modules.default_access':0,'api.access':1,'api.mode':1,'api':methods,'actions.default_access':0,'actions':[{'name':p,'status':1} for p in permissions]}},'roleids')
        group=api.create('usergroup.create',{'name':name,'gui_access':1,'hostgroup_rights':[{'id':g,'permission':2} for g in rights]},'usrgrpids')
        user=api.create('user.create',{'username':name,'passwd':secrets.token_urlsafe(32)+'!A1','roleid':role,'usrgrps':[{'usrgrpid':group}]},'userids')
        token_id=api.create('token.create',{'name':name,'userid':user,'expires_at':int(time.time())+7200},'tokenids')
        token=api.call('token.generate',[token_id])[0]['token']
        return {'file':protected(name+'.token',token),'token_id':token_id}
    restricted=account('review-worker',['event.get','event.acknowledge','host.get'],['add_problem_comments','acknowledge_problems'],[groups[0]])
    print('Created restricted synthetic worker identity',flush=True)
    witness=account('review-witness',['event.get','host.get'],[],groups)
    print('Created independent read-only witness identity',flush=True)
    expiring=account('review-expiring',['event.get','host.get'],[],[groups[0]])
    print('Created separate expiring identity',flush=True)
    time.sleep(12)
    for problem in problems.values():
        api.push(problem['item'],1)
        problem['event']=api.event(problem['trigger'])
        print('Observed a fresh synthetic problem event',flush=True)
    for item in multi_items:api.push(item,1)
    problems['multi']={'trigger':multi,'event':api.event(multi),'items':multi_items}
    fixture={'isolated_lab':True,'fresh_instance_no_notifications':True,'url':URL,'token_file':restricted['file'],
       'source':{'zabbix_instance':'isolated-real-zabbix','zabbix_event_id':problems['source']['event'],'zabbix_trigger_id':problems['source']['trigger']},
       'cohort':{'host_ids':[hosts[0]],'group_ids':[groups[0]]},
       'outside_scope_source':{'zabbix_event_id':problems['outside']['event'],'group_ids':[groups[1]],'witness_token_file':witness['file']},
       'end_to_end':{'zabbix_event_id':problems['e2e']['event'],'zabbix_trigger_id':problems['e2e']['trigger']}}
    protected('fixture.json',json.dumps(fixture))
    protected('extra.json',json.dumps({'version':version,'problems':problems,'groups':groups,'hosts':hosts,'expiring':expiring,'admin_file':protected('admin.session',api.token)}))
    api.client.close()
    print('Prepared real events, scoped worker and independent read-only witness for',version)

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--isolated-lab',action='store_true',required=True)
    parser.add_argument('--version',choices=['7.0.10','7.0.30'],required=True)
    args=parser.parse_args()
    prepare(args.version)
