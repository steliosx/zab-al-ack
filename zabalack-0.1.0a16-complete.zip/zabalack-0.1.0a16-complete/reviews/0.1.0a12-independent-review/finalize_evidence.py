"""Collect completed execution-owned records without modifying their identities."""
from pathlib import Path
from datetime import datetime, timezone
import json
import shutil
import sys
import hashlib

BASE = Path(__file__).resolve().parents[1]
REPO = BASE / "zabalack"
MATERIAL = BASE / "review-material"
FINAL = BASE / "independent-evidence/corrected"
SITE = BASE.parent / "ackline-site"
sys.path.insert(0, str(REPO / "tools"))
from evidence_utils import code_digests, cases  # noqa: E402


def read(path):
    return json.loads(path.read_text())


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def junit_counts(path):
    rows = cases(path)
    return {s: sum(r["status"] == s for r in rows) for s in ("passed", "failed", "skipped")}


def main():
    digests = code_digests(REPO)
    assert digests == read(BASE / "independent-evidence/final-code-digests.json")
    for job in ("36-final-installed-wheel-deployment", "37-final-native", "38-final-real-api-suites"):
        assert read(BASE / "vm/private/jobs" / (job + ".done"))["exit_code"] == 0
    labels = ["native", "real-zabbix-7.0.30", "real-zabbix-7.0.10",
              "supplemental-7.0.30", "supplemental-7.0.10"]
    for label in labels:
        source = BASE / "share/results" / label
        assert source.is_dir()
        target = FINAL / label
        assert not target.exists(), "Keep prior evidence; do not overwrite a final record set"
        shutil.copytree(source, target)
    reference = read(FINAL / "host/reference-run.json")
    native = read(FINAL / "native/native-run.json")
    deployment = read(FINAL / "deployment/deployment-e2e-run.json")
    for record in (reference, native, deployment):
        assert record["status"] == "PASS" and record["code_digests"] == digests
        assert record["tree_unchanged"] is True
    assert reference["counts"] == {"passed": 818, "failed": 0, "skipped": 22}
    assert len(native["phases"]) == 5
    for phase in native["phases"]:
        assert phase["exit_code"] == phase["shutdown_exit_code"] == 0
        assert phase["status"] == "PASS"
        assert junit_counts(FINAL / "native" / Path(phase["junit"]).name) == phase["counts"]
    native_counts = {s: sum(p["counts"][s] for p in native["phases"])
                     for s in ("passed", "failed", "skipped")}
    assert native_counts == {"passed": 42, "failed": 0, "skipped": 0}
    assert deployment["counts"] == {"passed": 4, "failed": 0, "skipped": 0}
    assert len(deployment["checks"]) == 13 and all(v is True for v in deployment["checks"].values())
    assert deployment["shutdown_exit_code"] == deployment["runner_shutdown_exit_code"] == 0
    api = {}
    for version in ("7.0.30", "7.0.10"):
        contract_dir = FINAL / ("real-zabbix-" + version)
        supplement_dir = FINAL / ("supplemental-" + version)
        contract = read(contract_dir / "real-zabbix-run.json")
        supplement = read(supplement_dir / "run.json")
        for record in (contract, supplement):
            assert record["status"] == "PASS" and record["code_digests"] == digests
        assert contract["observed_api_versions"] == [version]
        assert contract["counts"] == junit_counts(contract_dir / "real-zabbix.xml") == {"passed": 5, "failed": 0, "skipped": 0}
        assert supplement["counts"] == junit_counts(supplement_dir / "tests.xml") == {"passed": 10, "failed": 0, "skipped": 0}
        assert supplement["tree_unchanged"] and supplement["private_inputs_unchanged"] and supplement["public_evidence_leak_check"]
        for name, digest in supplement["harness"].items():
            assert hashlib.sha256((MATERIAL / "reproduction/helpers" / name).read_bytes()).hexdigest() == digest
        api[version] = {"contract": contract["counts"], "supplemental": supplement["counts"],
                        "full_notification_pipeline": version == "7.0.10"}
    for path in (FINAL / "native").iterdir():
        if path.name != "execution-context.json":
            shutil.copyfile(path, REPO / "evidence" / path.name)
    for name in ("real-zabbix-run.json", "real-zabbix.xml"):
        shutil.copyfile(FINAL / "real-zabbix-7.0.30" / name, REPO / "evidence" / name)

    result = read(MATERIAL / "results-draft.json")
    result.update(status="EVIDENCE_COMPLETE", native=native_counts, real_zabbix=api,
                  installed_wheel={"counts": deployment["counts"], "observations": 13,
                                   "all_observations_true": True, "cleanup_exit_code": 0},
                  final_service_evidence="PASS",
                  final_evidence_directory="evidence/corrected",
                  historical_evidence_note="Original, intermediate 74e/022 and failed records are retained separately; none were rebound.",
                  collected_at_utc=datetime.now(timezone.utc).isoformat())
    write(MATERIAL / "results.json", result)
    manifest = read(REPO / "docs/compatibility_manifest.json")
    manifest["recorded_at_utc"] = result["collected_at_utc"]
    manifest.pop("review_pending_final_service_records", None)
    manifest["independent_review"]["final_service_records_verified"] = True
    manifest["independent_review"]["reference_counts"] = reference["counts"]
    manifest["independent_review"]["real_zabbix_versions"] = api
    manifest["reference_interfaces"]["zabbix"]["deployment_e2e_target"]["status"] = (
        "INDEPENDENT_CORRECTED_QEMU_LAB_EXECUTED: installed wheel, 4 passed and 13/13 observations; "
        "cleanup exit 0, evidence/deployment-e2e-run.json. Docker Compose NOT_RUN. "
        "The complete-handoff visual-previews/04-zabbix-event-details.png is the supplied earlier 7.0.10 capture; no new browser capture."
    )
    manifest["new_quality_controls"]["deployment_e2e"] = "INDEPENDENT_CORRECTED_QEMU_LAB_EXECUTED: final harness; see evidence/deployment-e2e-run.json; Docker Compose NOT_RUN"
    manifest["native_and_real_zabbix_evidence"] = "Independent final-harness QEMU local services: native 42/0/0; real 7.0.30 and 7.0.10 each contract 5/0/0 plus supplemental 10/0/0; installed-wheel 7.0.10 pipeline 4/0/0 and 13/13 observations. Cleanup exit 0. No production gates established."
    write(REPO / "docs/compatibility_manifest.json", manifest)
    findings = read(BASE / "independent-evidence/review-findings.json")
    findings[0]["status"] = "FIXED_AND_VERIFIED_ON_REAL_7_0_30_AND_7_0_10"
    findings[0]["tests"] = "Final harness: reference 818/0/22; native 42/0/0; both Zabbix versions contract 5/0/0 and supplemental 10/0/0; installed-wheel 7.0.10 pipeline 4/0/0 and 13 observations"
    write(BASE / "independent-evidence/review-findings.json", findings)
    table = """| Executed layer | Result | Scope |
|---|---|---|
| Reference | 818 passed, 22 skipped, 0 failed | 789 unit/mock/property/offline + 29 PostgreSQL WASM passes |
| Native PostgreSQL 18.3 / PgBouncer 1.24.1 | 42 passed, 0 skipped, 0 failed | Five fresh clusters; all cleanup exit codes 0 |
| Zabbix 7.0.30 | 5 contract + 10 supplemental passed; no skips/failures | Real API, source-built server |
| Zabbix 7.0.10 | 5 contract + 10 supplemental passed; no skips/failures | Same real API coverage on the original reference |
| Installed-wheel pipeline, Zabbix 7.0.10 | 4 passed, 13/13 observations; no skips/failures | Actual Alerta login/action, SQL capture, worker, projection and source notifications; cleanup 0 |
| SQL / synthetic webhook | 8 / 15 groups passed | WASM SQL and Node contracts, distinct from native/source evidence |
| Property / curated mutation | 46 passed; PR 12 and nightly 20 mutations killed | Overlapping scenarios, not extra unique acceptance cases |
| Ruff / mypy / pip check / quickstart | Passed | Local tools and reference walkthrough |
| Local Gitleaks / pip-audit / npm audit | Zero findings; 58 Python packages, zero advisories | No hosted or external security-review claim |
| CycloneDX SBOM | Schema validation passed, 61 components | Offline pinned validator and retained schemas |

Counts overlap across layers and repeated versions. Inspect the primary JSON/XML
records under `evidence/corrected/`; original and failed records remain separate."""
    path = MATERIAL / "REVIEW.md"
    text = path.read_text()
    assert "<!-- FINAL_RESULTS_TABLE -->" in text
    path.write_text(text.replace("<!-- FINAL_RESULTS_TABLE -->", table))
    pipeline = "The installed-wheel 7.0.10 pipeline also passed all four tests and 13 observations, with successful cleanup."
    for name in ("dist/index.html", "dist/docs.html"):
        path = SITE / name
        text = path.read_text()
        assert "<!-- SERVICE_RESULTS -->" in text
        text = text.replace("<!-- SERVICE_RESULTS -->", pipeline)
        text = text.replace("<!-- DEPLOYMENT_TABLE_RESULTS -->", "Independent final-harness local VM execution: 4 passed, 13/13 observations, cleanup exit 0.")
        # Describe the selected local execution without implying the Docker form ran.
        text = text.replace("flows in an internal Docker network.", "flows. The supplied Docker form is separate from the local VM form executed here.")
        path.write_text(text)
    path = SITE / "dist/blog/zabbix-7-0-30-review.html"
    text = path.read_text()
    assert "<!-- SERVICE_RESULTS -->" in text
    path.write_text(text.replace("<!-- SERVICE_RESULTS -->", "<p>Both Zabbix versions passed all five contract cases and all ten supplemental API cases, with no skips or failures. " + pipeline + " These records identify the final corrected harness; earlier attempts are retained separately.</p>"))
    print(json.dumps({"status": "EVIDENCE_COMPLETE", "digests": digests, "native": native_counts, "api": api}, indent=2))


if __name__ == "__main__":
    main()
