# Zab-al-ack 0.1.0a12 — independent source review and recent-Zabbix lab

The supplied candidate was independently rebuilt before modification. Its wheel,
normalized sdist and source ZIP reproduced byte-for-byte. The review then found
and corrected a real permission-fixture defect, expanded real Zabbix coverage,
and updated the informational website. This is a reviewed edition of a12, not
a new tagged release or a public plugin upload.

The authoritative machine-readable result is `results.json`. No original or
intermediate run is silently rebound to the final harness. Runtime Python and
all SQL remain unchanged; the wheel remains the original a12 runtime artifact.

## What changed, and why

**F1 — effective source permissions (high within the lab's permission proof).**
The original lab role set disabled defaults but omitted individual actions.
In the inspected Zabbix 7.0.10 and 7.0.30 `CRole` implementation, role creation
initializes old defaults as enabled, and omitted rules retain that value. The
review's first real 7.0.30 suppression request succeeded. Close and severity
were rejected at a different host-rights boundary, not by the intended role
permission. A regression also fails against the original a12 provisioner.

The corrected helper enumerates the inspected action/UI rules and reads their
effective values back before creating users or tokens. Missing, duplicated,
ambiguous or broader permissions fail closed. The mock now reproduces upstream
omitted-rule behavior. Eight new permission regressions and actual restricted
source tests cover this correction. See `plugin/source/docs/SPEC_AMENDMENTS.md`
A4, relative to the handoff root.

The client's allowed actions remain 2 and 6. Zabbix shares one upstream
acknowledge/unacknowledge capability: the token can inherently unacknowledge,
while the client blocks action 16. Do not describe that token as an action-2-only
capability. G5 still requires evidence from the approved installed account.

**F2 — stale screenshot metadata (low).** The a12 compatibility manifest retained
an a11 NOT_RUN description and a nonexistent source PNG path. Those fields now
identify the supplied captures and their actual complete-handoff locations.
The website uses the supplied transcript PNGs and keeps the real frontend image
labelled Zabbix 7.0.10. No new browser capture or Alerta UI screenshot is claimed.

**Corrections to the review's own harness.** Two initial supplemental assertions
expected string acknowledgement IDs; the server returned integers. The existing
client already accepts both forms. Only those new assertions changed; exact
event identity and specific action-denial requirements remain. Another setup
attempt required Zabbix's minimum one enabled UI element. The independent
fixture now uses the shared helper's existing Problems-page default without
broadening its API/action rules.

The review initially omitted its new shared role module from the Docker context
selection. The stager now includes it, and a ninth regression imports both
modules from an isolated staged tree. The first installed-wheel attempt also
hit a 13-second cold `trigger.create` under QEMU, beyond the synthetic helper's
10-second bound. Only that lab provisioning/observation client now allows up to
30 seconds. Production delivery timeouts, expiry, leases and test assertions
are unchanged. These fixes preceded the final runs and changed the harness
digest; intermediate results remain separate.

A further installed-wheel attempt passed three tests and twelve observations,
but failed its projection sample. It waited for ledger success and immediately
read a view that the worker commits separately. The retained database later
showed projection ok. The original boolean did not retain which sampled field
failed, so the read-before-projection explanation is an inference supported by
the separate transactions. The corrected lab waits boundedly for the original
full event/status/history/projection predicate. A tenth regression rejects
pending, wrong-event, wrong-status and wrong-history states. Production code
and SQL are unchanged; the 3-pass/1-fail attempt is preserved.

## Final execution evidence

| Executed layer | Result | Scope |
|---|---|---|
| Reference | 818 passed, 22 skipped, 0 failed | 789 unit/mock/property/offline + 29 PostgreSQL WASM passes |
| Native PostgreSQL 18.3 / PgBouncer 1.24.1 | 42 passed, 0 skipped, 0 failed | Five fresh clusters; all cleanup exit codes 0 |
| Zabbix 7.0.30 | 5 contract + 10 supplemental passed; no skips/failures | Real API, source-built server |
| Zabbix 7.0.10 | 5 contract + 10 supplemental passed; no skips/failures | Same real API coverage on the original reference |
| Installed-wheel pipeline, Zabbix 7.0.10 | 4 passed, 13/13 observations; no skips/failures | Actual Alerta login/action, SQL capture, worker, projection and source notifications; cleanup 0 |
| SQL / synthetic webhook | 8 / 15 groups passed | WASM SQL and Node contracts, distinct from native/source evidence |
| Property / curated mutation | 46 passed; PR 12 and nightly 20 mutations killed | Overlapping scenarios, not extra unique acceptance cases |
| Ruff / mypy / pip check / quickstart | Passed | Local tools and reference walkthrough |
| Local Gitleaks / pip-audit / npm audit | Zero findings; 58 Python packages, zero advisories | No hosted or external security-review claim |
| CycloneDX SBOM | Schema validation passed, 61 components | Offline pinned validator and retained schemas |

Counts overlap across layers and repeated versions. Inspect the primary JSON/XML
records under `evidence/corrected/`; original and failed records remain separate.

The reference suite collected 840 cases: 789 unit/mock/property/offline passes,
29 PostgreSQL WASM passes, 18 optional-service skips and four native-only skips
in the WASM phase. Dedicated service runs are separate. Repeated scenarios across
versions and layers are not additional unique T-catalogue cases. The acceptance
matrix retains its original requirements, including T11a and T11b; supplemental
API cases do not silently substitute for deployment-only requirements.

The real API supplement covers:

| Case | Evidence boundary |
|---|---|
| Resolved original problem | Acknowledge the original; leave its recovery event untouched |
| Multi-host trigger | Observe the full host set; reject an incomplete cohort |
| Action 2 | Acknowledge without adding a comment |
| Close, severity and suppression | Require each specific upstream role-permission denial |
| Outside-scope write | Independent read-only witness proves event/group existence first |
| Unacknowledge capability | Demonstrate the shared upstream permission; client still rejects action 16 |
| Expired token | Bound and classify the real authentication failure |
| Lost response after accepted write | Observe one remote effect/reference and no client resend |

The lost-response supplement concerns the client/reference boundary. The native
fault tests separately exercise durable leases/reconciliation; neither is a
production HA or exactly-once guarantee. The full installed-wheel notification
pipeline remains deliberately pinned to 7.0.10. The newer 7.0.30 evidence is the
contract and supplemental API layer, not that full pipeline.

## Original, intermediate and failed attempts

| Record set | Meaning |
|---|---|
| `original-input/` in the handoff | Supplied a12 ZIP retained byte-for-byte, including older releases/reviews |
| `evidence/host`, `native`, `real-zabbix-7.0.30`, `rebuilt-dist` | Independent runs/builds before corrections, on the original harness |
| `evidence/supplemental-7.0.30-attempt-1` | Actual first run: five passed and five failed; exact helper snapshots retained |
| `evidence/original-role-regression.*` | Expected failing reproduction against the unmodified a12 provisioner |
| `evidence/intermediate-harness-74` | Passing intermediate reference/native/API runs plus the failed pipeline setup; not final-harness evidence |
| `evidence/intermediate-74-executable-snapshot.zip` | Exact source/harness files for reproducing that intermediate digest; not a complete installable package |
| `evidence/intermediate-harness-022` | The staged-context/timeout fix and its 3-pass/1-fail projection-sample attempt, before the final wait correction |
| `evidence/corrected` | Final executed evidence bound to the corrected harness |

Two VM interruptions/setup issues produced no acceptance tests: a disk-copy
problem interrupted a fixture setup, and an asynchronous shutdown caused an
attempt to overwrite a running server binary. The lab now keeps its active disk
outside the synchronized workspace, waits for declared services to stop and
reuses only hash-identical binaries. The stopped image passed a consistency
check before restart. Marked failed state was retained. A fresh scanner
environment replaced an unavailable earlier interpreter path. An early property
command omitted its required isolation flag and ran no tests; the explicit
corrected command passed. These are recorded as setup/invocation failures, not
test passes or product defects.

## Source, build and reproducibility

Original input SHA-256:
`c94a059e9de82fd3cea69e929dbcd143aa5743cb98abf3c2000d5df244e12f46`.
Baseline Git commit: `af03590226cd2b7b2100e7293d62e975d5549e4e`.
Final source/harness identities, review commit and artifact hashes are in
`results.json`, `package-verification.json` and `dist/BUILD_PROVENANCE.json`
(the last path is relative to the handoff root).

The source digest is unchanged. The final harness includes the role verifier,
ten added regressions, realistic mock, staging dependency, bounded lab
timeout and complete-predicate projection wait. Wrapper context `source_commit` fields name their baseline Git HEAD;
the primary source/harness digests identify executed worktree bytes.

The lab uses a full disposable Ubuntu 24.04 VM with QEMU 8.2.2 TCG, real OS users
and ordinary database logins. PostgreSQL 18.3, PgBouncer 1.24.1 and Zabbix 7.0.30
and 7.0.10 were built from source. The Zabbix backend uses separate PostgreSQL
16.15 and PHP 8.3.6 packages. See `reproduction/` for verified source/image/package
inputs, executed helpers and a concrete recipe. No PostgreSQL root guard was
bypassed and no SQL grant was broadened. The emulated timing is functional
evidence, not a capacity benchmark.

Zabbix 7.0.30 is the recent 7.0 LTS patch used here, not a claim to have tested
every newer Zabbix 7 branch. Upstream reference:
[7.0.30 release notes](https://www.zabbix.com/rn/rn7.0.30) and
[official 7.0 source archives](https://cdn.zabbix.com/zabbix/sources/stable/7.0/).
Inspected source file hashes are in `evidence/zabbix-source-inspection.json`.

## Deployment, rollback and next improvements

1. Resolve A2's actual webhook TLS/hostname/redirect boundary with an inspected
   transport remedy and negative certificate/redirect tests. The current artifact
   leaves the inspected verification options disabled and follows redirects;
   the separate worker client verifies TLS and refuses redirects.
2. Extend the full media/problem/update/recovery pipeline to 7.0.30 through a
   reviewed reference-target change. Its current five-plus-ten API evidence is
   not a substitute for that pipeline.
3. Execute the supplied Docker forms and hosted workflows, including CodeQL;
   arrange the independent security review and real publication ownership.
   Local Gitleaks and unsigned consistency checks are not those approvals.
4. Collect the actual deployment inputs and run staged permission, update-action,
   HA/fencing, pool and fleet capacity checks. Use the consolidated
   `DEPLOYMENT_INPUTS_REQUIRED.md` at the handoff root; provide protected secret
   references, never live secrets in chat.

All G1–G8 remain pending. Production examples keep external writes disabled and
no active cohort. No production access, acknowledgement, trigger/action change,
migration, service restart, notification or credential change was performed.
Only the authorized informational Site is published.

For installation and non-destructive rollback, use the plugin's existing
`docs/deployment.md`, `docs/runbook.md`, `docs/local-services.md`, `deploy/` and
`docs/RENAME.md`. This review adds no SQL migration or in-place legacy Ackline upgrade.
Provision a fresh disposable lab to obtain corrected role evidence; retain
records when stopping or rolling back. The final package records service
shutdown and VM power-off explicitly.

## Completed handoff verification

The final reviewed wheel is byte-identical to the supplied a12 wheel. Two builds
of the final wheel and normalized sdist matched; the source ZIP also reproduced.
The local review bundle restored into a fresh clone with all 297 tracked source
and evidence files equal to the source tree and source ZIP. The release verifier
also compared the sdist, wheel payload and install metadata. All 13 SQL manifest
entries match. This is unsigned local consistency evidence, not an attestation.

Review commit: `81a41f73a67a6c23ef04912d39b4b2d429174920`. The final public-source and full-history
Gitleaks scan found zero findings. No plugin repository or package was pushed.
The informational [Site](https://zabalack.stel.chatgpt.site) published successfully, after 16 pages,
399 local references and six PNG dimension checks passed. Browser visual QA and
new captures were not executed; the labelled supplied images remain in use.

Declared lab services stopped successfully and the VM powered off with driver
exit 0. See `site-publication.json`, `site-checks.json`, `final-secret-scan.json`,
`package-verification.json`, `lab-final-shutdown.json` and `results.json`.
