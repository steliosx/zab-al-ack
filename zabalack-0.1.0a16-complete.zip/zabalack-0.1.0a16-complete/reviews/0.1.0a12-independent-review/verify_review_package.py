"""Verify final artifacts and restore the local review bundle to compare bytes."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import sys
import zipfile

BASE = Path(__file__).resolve().parents[1]
REPO = BASE / "zabalack"
MATERIAL = BASE / "review-material"
sys.path.insert(0, str(REPO / "tools"))
from public_audit import public_files, audit  # noqa: E402
from verify_release import verify  # noqa: E402
from evidence_utils import code_digests  # noqa: E402


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=REPO, text=True).strip()


def main():
    assert not git("status", "--porcelain")
    assert audit(REPO)["status"] == "PASS"
    release = verify(REPO, REPO / "dist")
    assert release["status"] == "PASS"
    wheel = REPO / "dist/pypi/zabalack-0.1.0a12-py3-none-any.whl"
    assert sha(wheel) == "685475dfc6946eb41b02df6bdfd5538d80fa29fb8d5aad34fd5797237257b600"
    baseline = "af03590226cd2b7b2100e7293d62e975d5549e4e"
    assert not git("diff", baseline, "HEAD", "--", "src", "sql", "README.md", "pyproject.toml")
    manifest = json.loads((REPO / "docs/sql_manifest.json").read_text())
    assert len(manifest["files"]) == 13
    assert all(sha(REPO / row["path"]) == row["sha256"] for row in manifest["files"])
    source = {p.relative_to(REPO).as_posix(): p.read_bytes() for p in public_files(REPO)}
    with zipfile.ZipFile(REPO / "dist/zabalack-0.1.0a12-source.zip") as archive:
        exported = {name.removeprefix("zabalack-0.1.0a12/"): archive.read(name)
                    for name in archive.namelist()}
    assert exported == source, "All source and evidence bytes must agree"
    commit = git("rev-parse", "--verify", "HEAD")
    bundle = MATERIAL / "source-review.bundle"
    subprocess.run(["git", "bundle", "verify", str(bundle)], cwd=REPO, check=True, capture_output=True)
    clone = BASE / "package-verification/clone"
    assert not clone.exists(), "Fresh clone required"
    clone.parent.mkdir(exist_ok=True)
    subprocess.run(["git", "clone", "--branch", "review/a12-zabbix-7-0-lts", str(bundle), str(clone)], check=True, capture_output=True)
    restored_commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=clone, text=True).strip()
    assert restored_commit == commit
    restored = {p.relative_to(clone).as_posix(): p.read_bytes() for p in public_files(clone)}
    assert restored == source
    assert set(git("ls-files").splitlines()) == set(source), "Bundle tracked tree and public export must select the same files"
    record = {
        "status": "PASS", "scope": "unsigned local consistency, not signed provenance",
        "review_commit": commit, "baseline_commit": baseline,
        "review_branch": "review/a12-zabbix-7-0-lts", "plugin_remote_push": False,
        "bundle_sha256": sha(bundle), "bundle_restored_to_fresh_clone": True,
        "bundle_tree_equals_source_equals_source_zip": True,
        "sdist_matches_source_with_declared_generated_metadata": True,
        "runtime_python_sql_readme_project_metadata_unchanged": True,
        "wheel_identical_to_supplied_a12": True, "wheel_sha256": sha(wheel),
        "source_files": len(source), "sql_manifest_entries": 13, "sql_manifest_mismatches": 0,
        "code_digests": code_digests(REPO), "release_verifier": release,
        "verified_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    (MATERIAL / "package-verification.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()
