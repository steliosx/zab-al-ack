"""Offline structural checks for the informational Site; no browser QA claim."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit, unquote
from datetime import datetime, timezone
import hashlib
import json
import re
import struct
import sys

root = Path(sys.argv[1]).resolve()
output = Path(sys.argv[2])
origin = "https://zabalack.stel.chatgpt.site"
errors = []


class Page(HTMLParser):
    def __init__(self, path):
        super().__init__(convert_charrefs=True)
        self.path = path
        self.ids = set()
        self.refs = []
        self.images = []
        self.canonical = []
        self.og_urls = []
        self.main = 0
        self.h1 = 0
        self.title = 0

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag in {"script", "form", "iframe", "input", "object", "embed"}:
            errors.append(f"{self.path.name}: active element {tag}")
        if any(k.lower().startswith("on") for k in a):
            errors.append(f"{self.path.name}: event handler")
        if "id" in a:
            if a["id"] in self.ids:
                errors.append(f"{self.path.name}: duplicate id {a['id']}")
            self.ids.add(a["id"])
        for key in ("href", "src"):
            if a.get(key):
                self.refs.append(a[key])
        if tag == "img":
            self.images.append(a)
            if "alt" not in a:
                errors.append(f"{self.path.name}: missing image alt")
        if tag == "link" and a.get("rel") == "canonical":
            self.canonical.append(a.get("href"))
        if tag == "meta" and a.get("property") == "og:url":
            self.og_urls.append(a.get("content"))
        self.main += tag == "main"
        self.h1 += tag == "h1"
        self.title += tag == "title"


pages = {}
for path in sorted(root.rglob("*.html")):
    parser = Page(path)
    text = path.read_text()
    parser.feed(text)
    pages[path] = parser
    expected = origin + "/" + path.relative_to(root).as_posix()
    if path == root / "index.html":
        expected = origin + "/"
    if parser.canonical != [expected] or parser.og_urls != [expected]:
        errors.append(f"{path.name}: canonical or Open Graph URL mismatch")
    if (parser.main, parser.h1, parser.title) != (1, 1, 1):
        errors.append(f"{path.name}: main/h1/title structure")
    if "SERVICE_RESULTS" in text:
        errors.append(f"{path.name}: unfinished service evidence")

references = 0
png_checks = 0
for path, parser in pages.items():
    for ref in parser.refs:
        u = urlsplit(ref)
        if u.scheme and u.scheme not in {"https", "http", "mailto"}:
            errors.append(f"{path.name}: unexpected URL scheme")
            continue
        if u.netloc and u.netloc != urlsplit(origin).netloc:
            continue
        target = (root / u.path.lstrip("/")) if u.path.startswith("/") else (path.parent / unquote(u.path))
        target = path if not u.path else target.resolve()
        if target.is_dir():
            target = target / "index.html"
        references += 1
        if not target.is_relative_to(root) or not target.is_file():
            errors.append(f"{path.name}: missing or escaping local reference {ref}")
        elif u.fragment and (target not in pages or unquote(u.fragment) not in pages[target].ids):
            errors.append(f"{path.name}: missing fragment {ref}")
    for attrs in parser.images:
        p = (path.parent / attrs["src"]).resolve()
        if p.suffix == ".png" and p.is_file():
            data = p.read_bytes()
            assert data[:8] == b"\x89PNG\r\n\x1a\n"
            dimensions = struct.unpack(">II", data[16:24])
            if dimensions != (int(attrs.get("width", 0)), int(attrs.get("height", 0))):
                errors.append(f"{path.name}: wrong image dimensions {p.name}")
            png_checks += 1
for path in root.glob("*.css"):
    for ref in re.findall(r"url\(\s*['\"]?([^)'\"]+)", path.read_text()):
        if not ref.startswith("data:") and not (path.parent / ref).is_file():
            errors.append(f"{path.name}: missing CSS asset")

report = {
    "status": "PASS" if not errors else "FAIL",
    "checked_at_utc": datetime.now(timezone.utc).isoformat(),
    "html_pages": len(pages), "local_references": references,
    "png_dimension_checks": png_checks, "errors": errors,
    "files": {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
              for p in sorted(root.rglob("*")) if p.is_file()},
    "browser_visual_qa": "NOT_RUN",
    "new_browser_captures": "NOT_RUN; supplied labelled images reused",
    "scope": "Offline structure, local paths/fragments, inert markup, metadata and image dimensions",
}
output.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({k: v for k, v in report.items() if k != "files"}, indent=2))
raise SystemExit(0 if not errors else 1)
