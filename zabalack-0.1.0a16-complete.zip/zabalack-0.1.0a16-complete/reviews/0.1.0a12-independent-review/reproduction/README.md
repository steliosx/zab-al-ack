# Reproduce the isolated source-built review lab

The executed helpers and input manifests accompany this recipe. The execution
records establish the specific runs described in `../REVIEW.md`; this document
does not claim that a new cold-start automation wrapper or Docker image was
executed. The source repository also supplies its original Docker and local
runners in `lab/` and `tools/`.

## Isolation and inputs

Use a disposable x86_64 Ubuntu 24.04 VM, with no monitoring-system routes or
credentials. The review used QEMU 8.2.2 TCG, four virtual CPUs and 4 GiB RAM.
Allow at least 20 GiB free outside any continuously synchronized workspace.
QEMU's user network used `restrict=on`; only guest SSH and loopback test ports
were forwarded. PostgreSQL ran as a real unprivileged guest user. Do not defeat
its root check, fake process identities or relax the project's role grants.

Inputs retained here include:

- Official Zabbix 7.0.30, 7.0.10, PostgreSQL 18.3 and PgBouncer 1.24.1 source
  archive URLs and SHA-256 values in `sources.json`.
- Ubuntu's dated cloud-image URL and verified digest in `ubuntu-image.json`.
- The exact guest `.deb` and offline Python wheel manifests. Ubuntu packages
  came from the signed snapshot `20260828T000000Z`; these are lab provisioning
  inputs, not a production inventory. The guest used PHP 8.3.6 and PostgreSQL
  16.15 for Zabbix's separate backend.
- The plugin's pinned reference, quality and runtime requirements; its npm
  lock; the reviewed source/harness digests; and the unchanged a12 wheel.

Verify every downloaded input against the retained hashes before use. No VM
disk, OS binary, credential, private fixture or raw service log is exported.
Generate a new SSH key locally; substitute only its public half in
`user-data.template`. For a NoCloud seed, the command shape is:

```sh
genisoimage -output seed.iso -volid cidata -joliet -rock user-data meta-data
```

The review's `drive_vm.py` keeps QEMU and SSH in the same execution context,
executes explicitly queued JSON jobs and checkpoints a stopped disk. Its
`launch-command.template.json` records the actual command shape with the review
root replaced by `REVIEW_ROOT`. It expects the extracted QEMU sysroot used in
this sandbox; on a normal isolated host, use that host's reviewed QEMU/firmware
paths. No claim of identical host packages or native CPU timing is made.

## Prepare the share and guest

The executed helper paths are intentionally fixed:

| Host share | Guest location | Contents |
|---|---|---|
| `share/` | `/mnt/review` | 9p share, input packages, wheels, helpers and bounded results |
| `share/source.tar` | `/opt/review/zabalack` | Reviewed source tree; no private lab state |
| `share/native/pg18` | `/opt/review/native/pg18` | Source-built PostgreSQL 18.3 |
| `share/native/pgbouncer` | `/opt/review/native/pgbouncer` | Source-built PgBouncer 1.24.1 |
| `share/native/zabbix-<version>` | `/opt/review/native/zabbix-<version>` | Source-built server |
| `share/zabbix-<version>-web-sql.tar.gz` | Fresh marked instance directory | The matching upstream `ui/` and `database/` directories |

Build the upstream programs in an isolated development prefix. The executed
configuration selected PostgreSQL `--without-icu --without-readline
--with-ssl=openssl`; PgBouncer used OpenSSL and libevent. The Zabbix server used:

```sh
./configure --prefix="$REVIEW_PREFIX/native/zabbix-7.0.30" \
  --enable-server --with-postgresql="$REVIEW_PREFIX/native/pg18/bin/pg_config" \
  --with-libpcre2 --with-libcurl --with-openssl \
  --with-libevent="$REVIEW_SYSROOT/usr"
make -j4
make install
```

Repeat with the 7.0.10 source directory and matching prefix. Build dependencies
include a C toolchain, make, bison, flex, perl, OpenSSL, libevent, libcurl and
PCRE2 development files. A relocated bison installation requires its matching
`BISON_PKGDATADIR` and `M4`; do not mix generator data from another version.
For a conventional VM build, the repository's hash-checking
`lab/build_postgres.sh --isolated-lab <archive>` is another supplied route.

The review extracted verified Ubuntu packages into a private host sysroot,
built the binaries there, and copied them to the full guest. Its compiled
PostgreSQL prefix was preserved by a guest symlink created in
`provision_guest.py`. Inspect this explicit path when relocating the recipe;
setting `ACK_LAB_PG_BIN` alone does not rewrite compiled share-directory paths.

Populate `share/debs/` and `share/wheels/` from the manifests, copy a compatible
Node runtime to `share/node`, and place the reviewed wheel at
`share/zabalack-0.1.0a12-py3-none-any.whl`. Install npm dependencies with
`npm ci --legacy-peer-deps --ignore-scripts` in the source's `lab/` before
creating the guest source tar if WASM support is required there. The native
phases themselves use native PostgreSQL, not the WASM engine.

Copy the supplied `helpers/*.py` to the share root. Inside the marked guest:

```sh
sudo python3 /mnt/review/provision_guest.py --isolated-lab
sudo /opt/review/venv/bin/python /mnt/review/run_guest_suites.py --isolated-lab native
sudo /opt/review/venv/bin/python /mnt/review/zabbix_services.py --isolated-lab start --version 7.0.30
sudo /opt/review/venv/bin/python /mnt/review/prepare_source_fixture.py --isolated-lab --version 7.0.30
sudo /opt/review/venv/bin/python /mnt/review/run_guest_suites.py --isolated-lab contract --version 7.0.30
sudo /opt/review/venv/bin/python /mnt/review/run_guest_suites.py --isolated-lab supplemental --version 7.0.30
```

The provisioning helper prevents automatic distribution service starts and
installs only supplied packages. It generates fresh synthetic data and retains
tokens under `/run/` in the guest. Do not export that directory. The independent
read-only witness proves that the outside-scope event exists before the worker's
restricted read and write are evaluated. Effective role verification must pass
before tokens are issued.

Retain earlier `share/results/` directories before repeating a suite. The
supplemental runner refuses to overwrite a prior run; it owns its JUnit
execution, hashes helpers before and after, and leak-checks exported evidence.
Use `fresh_source_lab.py` to stop and retain a marked instance before creating
the second version. Do not reuse a mutated event set or an older broad-role
fixture as fresh permission evidence. The shutdown helper waits for declared
processes and verifies existing binary bytes rather than overwriting a running
executable. If cleanup fails, stop and investigate; it is not a passing phase.

## Installed-wheel pipeline and shutdown

After stopping the contract/API instance, the separate
`run_installed_wheel_lab.py --isolated-lab` helper creates new services and a
noneditable runner environment. It runs the repository's original installed-
wheel deployment suite on the intentionally pinned Zabbix 7.0.10 pipeline.
The tests cover real media import, problem/update/recovery notifications,
ordinary Alerta login/action, capture, worker delivery and echo filtering.
The 7.0.30 API result must not be described as execution of that full pipeline.

The wheel helper has no configurable external target. It creates a separate
SCRAM-authenticated PostgreSQL 18.3 cluster, synthetic credentials and lab TLS
material, checks installed bytes/entry points, and attempts to stop its services
in `finally`. Inspect both its test result and cleanup exit codes.

At completion stop all declared services and power off the guest. For the
review driver, enqueue `{"stop":true}` as the next job, then require the
driver's stopped result. Never delete a running disk. The packaged execution
summary records actual cleanup and any interrupted attempts separately.

G1–G8, production HA, fleet fairness/capacity, installed-environment permission
tests, and A2's webhook TLS/redirect remedy remain deployment work. See the
plugin's single `docs/INPUTS_REQUIRED.md` register.


The final reviewed synthetic provisioner uses a bounded 30-second RPC timeout
for setup and observations: the first cold trigger.create took 13 seconds in
QEMU and failed its previous 10-second bound. This is not the production worker
client. Delivery timeouts/expiry and assertions are unchanged. The new staged-
import regression verifies inclusion of the role helper; it is not execution
of the Docker image itself. `sbom_validate.py` reproduces offline schema checks
with jsonschema 4.26.0 and the retained schemas.

The final pipeline observer waits within the existing run bound for the full
projection/event/status/history predicate after ledger completion. Its preceding
3-pass/1-fail attempt and the pending/mismatched-state regression are retained.
The final batch sequence used `finish_api_suites.py` after the 42-case native
run; it validates that run before creating fresh API fixtures for both versions
and stops declared Zabbix services when finished.
