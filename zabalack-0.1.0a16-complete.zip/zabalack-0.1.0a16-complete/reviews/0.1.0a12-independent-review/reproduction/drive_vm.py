"""Keep QEMU and its SSH client in one sandbox execution context.

The guest owns real Linux user IDs. Neither PostgreSQL's root guard nor any
database grant is changed. Jobs are explicit commands from this review only.
"""
from pathlib import Path
import json
import os
import shlex
import shutil
import socket
import subprocess
import tempfile
import threading
import time

BASE = Path(__file__).resolve().parents[1]
VM = BASE / "vm"
JOBS = VM / "private/jobs"
JOBS.mkdir(mode=0o700, exist_ok=True)
env = dict(os.environ,
           LD_LIBRARY_PATH=str(BASE / "sysroot/usr/lib/x86_64-linux-gnu"),
           QEMU_MODULE_DIR=str(BASE / "sysroot/usr/lib/x86_64-linux-gnu/qemu"))
cmd = json.loads((VM / "launch-command.json").read_text())
runtime = Path(tempfile.mkdtemp(prefix="zabalack-review-qemu-"))
runtime_disk = runtime / "disk.qcow2"
shutil.copyfile(VM / "disk.qcow2", runtime_disk)
cmd = [item.replace(str(VM / 'disk.qcow2'), str(runtime_disk)) for item in cmd]
cmd += ['-qmp', 'tcp:127.0.0.1:55223,server=on,wait=off']
network = cmd.index("-netdev") + 1
cmd[network] = cmd[network].replace("user,id=net0,", "user,id=net0,restrict=on,")
ssh = ["ssh", "-i", str(VM / "private/id_ed25519"), "-p", "55222",
       "-o", "UserKnownHostsFile=" + str(VM / "private/known_hosts"),
       "-o", "StrictHostKeyChecking=accept-new", "-o", "ConnectTimeout=5",
       "-o", "BatchMode=yes", "lab@127.0.0.1"]
with (VM / "qemu.log").open("a") as log:
    qemu = subprocess.Popen(cmd, env=env, stdout=log, stderr=subprocess.STDOUT)
    finished = threading.Event()
    def health_monitor():
        while not finished.is_set() and qemu.poll() is None:
            try:
                with socket.create_connection(('127.0.0.1',55223),timeout=5) as sock:
                    stream=sock.makefile('rb')
                    greeting=json.loads(stream.readline())
                    if 'QMP' not in greeting:
                        raise RuntimeError('Unexpected lab monitor protocol')
                    def request(command):
                        sock.sendall((json.dumps({'execute':command})+'\n').encode())
                        while True:
                            reply=json.loads(stream.readline())
                            if 'return' in reply:return reply['return']
                            if 'error' in reply:raise RuntimeError('Lab monitor request rejected')
                    request('qmp_capabilities')
                    status=request('query-status')
                    (VM/'private/health.json').write_text(json.dumps({
                        'running':status['running'],'status':status['status'],
                        'active_disk_outside_synced_workspace':True,
                        'free_runtime_bytes':shutil.disk_usage(runtime).free,
                        'checked_at_epoch':time.time()})+'\n')
            except (OSError,ValueError,KeyError,RuntimeError):
                pass
            finished.wait(10)
    monitor=threading.Thread(target=health_monitor,daemon=True)
    monitor.start()
    try:
        deadline = time.monotonic() + 600
        while time.monotonic() < deadline:
            if qemu.poll() is not None:
                raise RuntimeError("QEMU stopped; inspect qemu.log")
            probe = subprocess.run([*ssh, "true"], capture_output=True, timeout=15)
            if probe.returncode == 0:
                break
            time.sleep(2)
        else:
            raise RuntimeError("Guest SSH readiness deadline exceeded")
        (VM / "ready.json").write_text(json.dumps({"status": "READY", "isolation": "QEMU TCG, restricted user network"}))
        print("Guest SSH ready; restricted network; awaiting review jobs", flush=True)
        while qemu.poll() is None:
            pending = sorted(p for p in JOBS.glob("*.json") if not p.with_suffix(".done").exists())
            for path in pending:
                job = json.loads(path.read_text())
                if job.get("stop") is True:
                    subprocess.run([*ssh, "sudo poweroff"], capture_output=True, timeout=30)
                    qemu.wait(timeout=90)
                    path.with_suffix(".done").write_text('{"status":"STOPPED"}\n')
                    print("Guest powered off", flush=True)
                    raise SystemExit(0)
                start = time.monotonic()
                with path.with_suffix(".log").open("w") as output:
                    try:
                        result = subprocess.run([*ssh, shlex.join(job["argv"])], stdout=output,
                                                stderr=subprocess.STDOUT, timeout=job.get("timeout", 900))
                        code = result.returncode
                    except subprocess.TimeoutExpired:
                        code = 124
                result = {"exit_code": code, "elapsed_seconds": round(time.monotonic() - start, 3)}
                path.with_suffix(".done").write_text(json.dumps(result) + "\n")
                print(path.stem, json.dumps(result), flush=True)
            time.sleep(0.5)
    finally:
        finished.set()
        if qemu.poll() is None:
            qemu.terminate()
            try:
                qemu.wait(timeout=30)
            except subprocess.TimeoutExpired:
                qemu.kill()
                qemu.wait()
        monitor.join(timeout=7)
        # One stopped checkpoint; never synchronize a continually changing VM disk.
        shutil.copyfile(runtime_disk, VM/'disk.qcow2')
        shutil.rmtree(runtime)
