"""Run both fresh API suites only after the final native run passed."""
from pathlib import Path
import argparse,json,subprocess,sys,shutil
p=argparse.ArgumentParser();p.add_argument('--isolated-lab',action='store_true',required=True);p.parse_args()
repo=Path('/opt/review/zabalack');share=Path('/mnt/review');python='/opt/review/venv/bin/python'
sys.path.insert(0,str(repo/'tools'))
from evidence_utils import code_digests
native=json.loads((repo/'evidence/native-run.json').read_text())
assert native['status']=='PASS' and native['code_digests']==code_digests(repo)
assert sum(x['counts']['passed'] for x in native['phases'])==42
assert all(x['shutdown_exit_code']==0 for x in native['phases'])
for name in ('batch-50-supplemental.json','batch-200-supplemental.json'):
 shutil.copyfile(repo/'evidence'/name,share/'results/native'/name)
for version,retained in [('7.0.30','final-deployment'),('7.0.10','final-7.0.30')]:
 subprocess.run([python,str(share/'fresh_source_lab.py'),'--isolated-lab','--retain-as',retained,'--version',version],check=True)
 for suite in ('contract','supplemental'):
  subprocess.run([python,str(share/'run_guest_suites.py'),'--isolated-lab',suite,'--version',version],check=True)
subprocess.run([python,str(share/'zabbix_services.py'),'--isolated-lab','stop'],check=True)
print('Both final source API suites complete and services stopped',flush=True)
