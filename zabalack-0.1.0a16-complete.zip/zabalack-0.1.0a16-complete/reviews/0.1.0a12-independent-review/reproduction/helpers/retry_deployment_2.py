"""Retain a stopped, marked failed deployment attempt; recreate only this lab."""
from pathlib import Path
import argparse,subprocess
p=argparse.ArgumentParser();p.add_argument('--isolated-lab',action='store_true',required=True);p.parse_args()
root=Path('/opt/review')
for name in ('deployment-state','zabbix-state'):
 state=root/name
 assert (state/'ISOLATED_REVIEW_LAB').is_file()
 assert not (state/'pgdata/postmaster.pid').exists()
 target=state.with_name(name+'-deployment-attempt-2')
 assert not target.exists()
 state.rename(target)
private=Path('/run/zabalack-e2e');target=private.with_name('zabalack-e2e-deployment-attempt-2')
assert not target.exists();private.rename(target)
link=Path('/opt/zabalack-lab');assert link.is_symlink() and link.resolve()==root/'zabalack';link.unlink()
venv=root/'wheel-venv';assert (venv/'pyvenv.cfg').is_file();assert not venv.with_name('wheel-venv-deployment-attempt-2').exists();venv.rename(venv.with_name('wheel-venv-deployment-attempt-2'))
hosts=Path('/etc/hosts');line='127.0.0.1 postgres zabbix-web runner # isolated Zab-al-ack review VM'
assert hosts.read_text().splitlines().count(line)==1
hosts.write_text('\n'.join(x for x in hosts.read_text().splitlines() if x!=line)+'\n')
raise SystemExit(subprocess.run(['/opt/review/venv/bin/python','/mnt/review/run_installed_wheel_lab.py','--isolated-lab']).returncode)
