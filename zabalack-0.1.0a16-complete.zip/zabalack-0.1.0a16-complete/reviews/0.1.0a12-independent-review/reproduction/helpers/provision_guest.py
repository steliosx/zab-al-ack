"""Provision this fresh disposable Ubuntu VM from verified local packages only."""
from pathlib import Path
import argparse
import json
import os
import shutil
import subprocess
import tarfile

SHARE = Path('/mnt/review')
parser=argparse.ArgumentParser()
parser.add_argument('--isolated-lab',action='store_true',required=True)
parser.add_argument('--resume-packages',action='store_true')
args=parser.parse_args()
assert os.geteuid() == 0 and SHARE.is_mount(), 'fresh isolated guest root required'
assert Path('/sys/class/dmi/id/product_name').read_text().strip() in ('Standard PC (i440FX + PIIX, 1996)', 'QEMU Standard PC (i440FX + PIIX, 1996)')
Path('/usr/sbin/policy-rc.d').write_text('#!/bin/sh\nexit 101\n')
Path('/usr/sbin/policy-rc.d').chmod(0o755)
Path('/etc/postgresql-common').mkdir(exist_ok=True)
Path('/etc/postgresql-common/createcluster.conf').write_text('create_main_cluster = false\n')
env = dict(os.environ, DEBIAN_FRONTEND='noninteractive', TZ='UTC')
if not args.resume_packages:
    subprocess.run(['dpkg', '--force-confold', '-i', *map(str, sorted((SHARE/'debs').glob('*.deb')))], env=env, check=True)
else:
    subprocess.run(['dpkg', '-i', *map(str, (SHARE/'debs').glob('libpcsclite1_*.deb'))], env=env, check=True)
    subprocess.run(['dpkg', '--configure', '-a'],env=env,check=True)
subprocess.run(['locale-gen', 'en_US.UTF-8'], env=env, check=True)
work = Path('/opt/review')
work.mkdir(exist_ok=True)
repo = work/'zabalack'
repo.mkdir(exist_ok=True)
with tarfile.open(SHARE/'source.tar') as archive:
    archive.extractall(repo, filter='data')
subprocess.run(['python3.12', '-m', 'venv', str(work/'venv')], check=True)
python = str(work/'venv/bin/python')
subprocess.run([python, '-m', 'pip', 'install', '--no-index', '--find-links', str(SHARE/'wheels'), '-r', str(repo/'requirements.lock')], check=True)
subprocess.run([python, '-m', 'pip', 'install', '--no-index', '--find-links', str(SHARE/'wheels'), '--require-hashes', '-r', str(repo/'requirements-quality.lock')], check=True)
subprocess.run([python, '-m', 'pip', 'install', '--no-deps', '--no-build-isolation', '-e', str(repo)], check=True)
shutil.copyfile(SHARE/'node', '/usr/local/bin/node')
Path('/usr/local/bin/node').chmod(0o755)
for name in ('pg18', 'pgbouncer'):
    shutil.copytree(SHARE/'native'/name, work/'native'/name, dirs_exist_ok=True)
Path('/workspace/scratch/0a47267899dd/a12-review').mkdir(parents=True, exist_ok=True)
link = Path('/workspace/scratch/0a47267899dd/a12-review/native')
if not link.exists():
    link.symlink_to(work/'native', target_is_directory=True)
# Native runners delete only their own disposable state and start PostgreSQL as nobody.
result = subprocess.run([python, '-m', 'pip', 'check'], check=True, capture_output=True, text=True)
(SHARE/'guest-provisioned.json').write_text(json.dumps({'status':'PASS', 'dependency_check':result.stdout.strip(), 'python': subprocess.check_output([python,'--version'], text=True).strip()})+'\n')
