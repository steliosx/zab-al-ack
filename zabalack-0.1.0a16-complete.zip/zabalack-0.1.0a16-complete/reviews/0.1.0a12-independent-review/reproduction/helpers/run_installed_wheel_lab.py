"""Run the original a12 installed-wheel suite with reviewed lab role provisioning.

No caller-selectable targets, credentials or reset commands. All writes are to
new synthetic services under /opt/review in the marked disposable QEMU guest.
"""
from pathlib import Path
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
import pwd
import secrets
import shutil
import subprocess

ROOT=Path('/opt/review')
REPO=ROOT/'zabalack'
SHARE=Path('/mnt/review')
STATE=ROOT/'deployment-state'
PRIVATE=Path('/run/zabalack-e2e')
PG=ROOT/'native/pg18/bin'
PYTHON=ROOT/'venv/bin/python'
RUNNER=ROOT/'wheel-venv/bin/python'
WHEEL=SHARE/'zabalack-0.1.0a12-py3-none-any.whl'
ENV={'PATH':'/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin','TZ':'UTC','HOME':'/tmp','PYTHONUNBUFFERED':'1'}

def run(args, user=False, **kwargs):
    return subprocess.run((['runuser','-u','nobody','--'] if user else [])+list(map(str,args)),cwd=REPO,env=ENV,**kwargs)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--isolated-lab',action='store_true',required=True)
    parser.parse_args()
    assert os.geteuid()==0 and SHARE.is_mount() and (SHARE/'guest-provisioned.json').is_file()
    assert Path('/sys/class/dmi/id/product_name').read_text().strip() in ('Standard PC (i440FX + PIIX, 1996)','QEMU Standard PC (i440FX + PIIX, 1996)')
    assert hashlib.sha256(WHEEL.read_bytes()).hexdigest()=='685475dfc6946eb41b02df6bdfd5538d80fa29fb8d5aad34fd5797237257b600'
    assert not STATE.exists(), 'Fresh deployment state required; retain any previous evidence'
    state_user=pwd.getpwnam('nobody')
    STATE.mkdir(mode=0o700)
    os.chown(STATE,state_user.pw_uid,state_user.pw_gid)
    (STATE/'ISOLATED_REVIEW_LAB').write_text('Synthetic disposable QEMU guest only\n')
    assert not PRIVATE.exists(), 'Private deployment directory already exists'
    PRIVATE.mkdir(mode=0o700)
    password=secrets.token_urlsafe(32)
    for path in (PRIVATE/'pg-password',STATE/'pg-password'):
        path.write_text(password)
        path.chmod(0o600)
    os.chown(STATE/'pg-password',state_user.pw_uid,state_user.pw_gid)
    link=Path('/opt/zabalack-lab')
    assert not link.exists(), 'Lab source link already exists'
    link.symlink_to(REPO,target_is_directory=True)
    hosts=Path('/etc/hosts')
    assert all(name not in hosts.read_text().split() for name in ('postgres','zabbix-web','runner'))
    with hosts.open('a') as stream:
        stream.write('\n127.0.0.1 postgres zabbix-web runner # isolated Zab-al-ack review VM\n')
    run(['python3.12','-m','venv',RUNNER.parent.parent],check=True)
    run([RUNNER,'-m','pip','install','--no-index','--find-links',SHARE/'wheels','-r',REPO/'requirements.lock'],check=True)
    run([RUNNER,'-m','pip','install','--no-index','--no-deps',WHEEL],check=True)
    run([RUNNER,'-m','pip','check'],check=True)
    run([PG/'initdb','-D',STATE/'pgdata','-U','lab_admin','--pwfile='+str(STATE/'pg-password'),
         '--auth-local=trust','--auth-host=scram-sha-256','--locale=C.UTF-8'],user=True,check=True)
    with (STATE/'pgdata/postgresql.conf').open('a') as stream:
        stream.write("\nlisten_addresses='127.0.0.1'\nport=5432\nunix_socket_directories=''\nshared_buffers='128MB'\nlog_statement='none'\n")
    shutdown=[]
    started=datetime.now(timezone.utc).isoformat()
    result=None
    try:
        run([PG/'pg_ctl','-D',STATE/'pgdata','-l',STATE/'postgres.log','-w','start'],user=True,check=True)
        with subprocess.Popen([str(PG/'psql'),'postgresql://lab_admin@127.0.0.1:5432/postgres','-v','ON_ERROR_STOP=1','-c','CREATE DATABASE alerta OWNER lab_admin'],env=dict(ENV,PGPASSWORD=password)) as child:
            assert child.wait()==0
        run([PYTHON,SHARE/'zabbix_services.py','--isolated-lab','start','--version','7.0.10','--port','8080'],check=True)
        services={
            'postgres':'PostgreSQL 18.3 compiled from verified upstream source; fresh cluster with real unprivileged service user and SCRAM-SHA-256 host authentication',
            'zabbix-db':'PostgreSQL 16.15 Ubuntu snapshot package; separate fresh synthetic database on guest loopback',
            'zabbix-server':'Zabbix 7.0.10 compiled from verified upstream source; clean environment; loopback; disposable QEMU TCG guest',
            'zabbix-web':'Zabbix 7.0.10 upstream PHP frontend on PHP 8.3.6; loopback HTTP in disposable QEMU TCG guest'}
        services_path=STATE/'services.json'
        services_path.write_text(json.dumps(services))
        result=run([PYTHON,'tools/run_deployment_e2e_local.py','--isolated-lab','--runner-python',RUNNER,'--wheel',WHEEL,'--services-file',services_path])
        target=SHARE/'results/deployment'
        target.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(REPO/'evidence/deployment-e2e-run.json',target/'deployment-e2e-run.json')
        # The original runner exports bounded observations; raw private files stay here.
        return result.returncode
    finally:
        for command in ([PYTHON,SHARE/'zabbix_services.py','--isolated-lab','stop'],
                        ['runuser','-u','nobody','--',PG/'pg_ctl','-D',STATE/'pgdata','-m','fast','-w','stop']):
            shutdown.append(run(command).returncode)
        target=SHARE/'results/deployment'
        target.mkdir(parents=True,exist_ok=True)
        (target/'execution-context.json').write_text(json.dumps({
            'layer':'installed wheel against real local services in QEMU TCG guest',
            'started_at_utc':started,'finished_at_utc':datetime.now(timezone.utc).isoformat(),
            'baseline_commit':'af03590226cd2b7b2100e7293d62e975d5549e4e','docker':False,
            'reviewed_harness':'2727c4cbb2b0b6187bf70921ec03f5f16237aaf36ba5616241ed33aba85ea76c',
            'helper_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'runner_exit_code':None if result is None else result.returncode,
            'service_shutdown_exit_codes':shutdown,'production_access':False,
            'deployment_gates':'MANUAL_GATE_PENDING'},indent=2)+'\n')

if __name__=='__main__':
    raise SystemExit(main())
