"""Start fresh, loopback-only Zabbix instances inside the disposable review VM."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import pwd
import secrets
import shutil
import subprocess
import tarfile
import time
import urllib.request

ROOT = Path('/opt/review')
SHARE = Path('/mnt/review')
STATE = ROOT/'zabbix-state'
PG = Path('/usr/lib/postgresql/16/bin')

def command(args, user=False, **kw):
    return subprocess.run((['runuser','-u','nobody','--'] if user else []) + list(map(str,args)), check=True, **kw)

def owned(path, mode=0o700):
    path.mkdir(parents=True, exist_ok=True)
    person=pwd.getpwnam('nobody')
    os.chown(path,person.pw_uid,person.pw_gid)
    path.chmod(mode)

def secret(path, text):
    path.write_text(text)
    path.chmod(0o600)
    person=pwd.getpwnam('nobody')
    os.chown(path,person.pw_uid,person.pw_gid)

def wait_stopped(pid):
    deadline=time.monotonic()+180
    while time.monotonic()<deadline:
        proc=Path(f'/proc/{pid}')
        try:
            state=(proc/'stat').read_text().rsplit(')',1)[1].split()[0]
            if state=='Z': return
        except FileNotFoundError:
            return
        time.sleep(0.5)
    raise RuntimeError('Declared lab service did not stop within 180 seconds')

def stop():
    if not (STATE/'ISOLATED_REVIEW_LAB').is_file():
        return
    for p in STATE.glob('*/server.pid'):
        try:
            pid=int(p.read_text())
            cmdline=Path(f'/proc/{pid}/cmdline').read_bytes()
            if b'zabbix_server' not in cmdline or str(STATE).encode() not in cmdline:
                raise RuntimeError('Refusing unrelated process')
            os.kill(pid,15)
            wait_stopped(pid)
        except (FileNotFoundError,ProcessLookupError):
            pass
    for p in STATE.glob('*/php.pid'):
        try:
            pid=int(p.read_text())
            cmdline=Path(f'/proc/{pid}/cmdline').read_bytes()
            if b'php' not in cmdline or str(STATE).encode() not in cmdline:
                raise RuntimeError('Refusing unrelated process')
            os.kill(pid,15)
            wait_stopped(pid)
        except (FileNotFoundError,ProcessLookupError):
            pass
    if (STATE/'pgdata/postmaster.pid').exists():
        command([PG/'pg_ctl','-D',STATE/'pgdata','-m','fast','-w','stop'],user=True)

def start(version, port):
    assert version in ('7.0.10','7.0.30') and port in (58080,8080)
    assert os.geteuid()==0 and SHARE.is_mount()
    if STATE.exists() and not (STATE/'ISOLATED_REVIEW_LAB').exists():
        raise RuntimeError('Unmarked pre-existing state')
    owned(STATE,0o755)
    (STATE/'ISOLATED_REVIEW_LAB').write_text('Fresh disposable review VM only\n')
    if not (STATE/'pgdata/PG_VERSION').exists():
        command([PG/'initdb','-D',STATE/'pgdata','-U','lab_admin','--auth-local=trust','--auth-host=trust','--locale=C.UTF-8'],user=True)
        with (STATE/'pgdata/postgresql.conf').open('a') as f:
            f.write("\nlisten_addresses='127.0.0.1'\nport=55416\nunix_socket_directories=''\nshared_buffers='128MB'\nlog_statement='none'\n")
    if not (STATE/'pgdata/postmaster.pid').exists():
        command([PG/'pg_ctl','-D',STATE/'pgdata','-l',STATE/'postgres.log','-w','start'],user=True)
    name='v'+version.replace('.','_')+'p'+str(port)
    directory=STATE/name
    if directory.exists():
        raise RuntimeError('Fresh instance required; prior instance retained')
    owned(directory,0o755)
    with tarfile.open(SHARE/('zabbix-'+version+'-web-sql.tar.gz')) as archive:
        archive.extractall(directory,filter='data')
    source_binary=SHARE/'native'/('zabbix-'+version)
    target_binary=ROOT/'native'/('zabbix-'+version)
    if target_binary.exists():
        source_files={p.relative_to(source_binary):hashlib.sha256(p.read_bytes()).hexdigest()
                      for p in source_binary.rglob('*') if p.is_file()}
        target_files={p.relative_to(target_binary):hashlib.sha256(p.read_bytes()).hexdigest()
                      for p in target_binary.rglob('*') if p.is_file()}
        assert source_files==target_files, 'Refusing an unexpected pre-existing binary tree'
    else:
        shutil.copytree(source_binary,target_binary)
    # Separate synthetic database and role for this instance.
    password=secrets.token_urlsafe(32)
    psql=[str(PG/'psql'),'postgresql://lab_admin@127.0.0.1:55416/postgres','-v','ON_ERROR_STOP=1']
    command([*psql,'-c',f'CREATE ROLE {name} LOGIN PASSWORD \'{password}\''])
    command([*psql,'-c',f'CREATE DATABASE {name} OWNER {name}'])
    dsn=f'postgresql://{name}@127.0.0.1:55416/{name}'
    for part in ('schema.sql','images.sql','data.sql'):
        command([PG/'psql',dsn,'-v','ON_ERROR_STOP=1','-f',directory/'database/postgresql'/part],stdout=subprocess.DEVNULL)
    config=directory/'server.conf'
    secret(config, '\n'.join(['LogType=file','LogFile='+str(directory/'server.log'),
        'PidFile='+str(directory/'server.pid'),'SocketDir='+str(directory),
        'ListenIP=127.0.0.1','ListenPort='+str(10051 if port==58080 else 10052),
        'DBHost=127.0.0.1','DBPort=55416','DBName='+name,'DBUser='+name,'DBPassword='+password,
        'StartPollers=1','StartPingers=0','StartTrappers=1','StartAlerters=1','StartDiscoverers=0',
        'StartHTTPPollers=0','StartDBSyncers=1','StartPreprocessors=1','CacheUpdateFrequency=10',
        'Timeout=10','AllowRoot=0','User=nobody'])+'\n')
    php=directory/'ui/conf/zabbix.conf.php'
    php.write_text("<?php\n$DB['TYPE']='POSTGRESQL';\n$DB['SERVER']='127.0.0.1';\n$DB['PORT']='55416';\n$DB['DATABASE']='"+name+"';\n$DB['USER']='"+name+"';\n$DB['PASSWORD']='"+password+"';\n$ZBX_SERVER='127.0.0.1';\n$ZBX_SERVER_PORT='"+str(10051 if port==58080 else 10052)+"';\n$ZBX_SERVER_NAME='Zab-al-ack isolated lab';\n$IMAGE_FORMAT_DEFAULT=IMAGE_FORMAT_PNG;\n")
    php.chmod(0o600)
    command([ROOT/'native'/('zabbix-'+version)/'sbin/zabbix_server','-c',config],user=True,
            env={'PATH':'/usr/sbin:/usr/bin:/sbin:/bin','TZ':'UTC','HOME':'/tmp'})
    with (directory/'php.log').open('w') as log:
        proc=subprocess.Popen(['php','-d','date.timezone=UTC','-d','max_execution_time=300','-d','opcache.enable_cli=1','-S',f'127.0.0.1:{port}','-t',str(directory/'ui')],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    (directory/'php.pid').write_text(str(proc.pid))
    url=f'http://127.0.0.1:{port}/api_jsonrpc.php'
    for _ in range(60):
        try:
            request=urllib.request.Request(url,json.dumps({'jsonrpc':'2.0','method':'apiinfo.version','params':{},'id':1}).encode(),{'Content-Type':'application/json'})
            reply=json.load(urllib.request.urlopen(request,timeout=5))
            assert reply=={'jsonrpc':'2.0','result':version,'id':1},'Unexpected API identity'
            break
        except (OSError,ValueError):
            time.sleep(1)
    else:
        raise RuntimeError('API readiness deadline')
    (SHARE/'zabbix-service.json').write_text(json.dumps({'version':version,'api_port':port,'status':'READY','backend':'PostgreSQL 16.15','isolation':'QEMU TCG, loopback services, restricted guest network'})+'\n')
    print('Ready: Zabbix',version,'on loopback port',port,flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--isolated-lab',action='store_true',required=True)
    parser.add_argument('action',choices=['start','stop'])
    parser.add_argument('--version',choices=['7.0.10','7.0.30'],default='7.0.30')
    parser.add_argument('--port',type=int,choices=[58080,8080],default=58080)
    args=parser.parse_args()
    stop() if args.action=='stop' else start(args.version,args.port)
