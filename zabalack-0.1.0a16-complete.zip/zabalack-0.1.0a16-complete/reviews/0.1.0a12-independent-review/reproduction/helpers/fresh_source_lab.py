from pathlib import Path
import argparse, subprocess
p=argparse.ArgumentParser()
p.add_argument('--isolated-lab',action='store_true',required=True)
p.add_argument('--retain-as',choices=['supplemental-attempt-1','corrected-7.0.30','corrected-7.0.10','role-ui-attempt-1','final-deployment','final-7.0.30'],required=True)
p.add_argument('--version',choices=['7.0.10','7.0.30'],required=True)
a=p.parse_args()
state=Path('/opt/review/zabbix-state')
private=Path('/run/zabalack-review')
assert (state/'ISOLATED_REVIEW_LAB').is_file()
subprocess.run(['/opt/review/venv/bin/python','/mnt/review/zabbix_services.py','--isolated-lab','stop'],check=True)
assert not (state/'pgdata/postmaster.pid').exists()
assert not state.with_name('zabbix-state-'+a.retain_as).exists()
state.rename(state.with_name('zabbix-state-'+a.retain_as))
if private.exists():
 assert not private.with_name('zabalack-review-'+a.retain_as).exists()
 private.rename(private.with_name('zabalack-review-'+a.retain_as))
subprocess.run(['/opt/review/venv/bin/python','/mnt/review/zabbix_services.py','--isolated-lab','start','--version',a.version],check=True)
subprocess.run(['/opt/review/venv/bin/python','/mnt/review/prepare_source_fixture.py','--isolated-lab','--version',a.version],check=True)
