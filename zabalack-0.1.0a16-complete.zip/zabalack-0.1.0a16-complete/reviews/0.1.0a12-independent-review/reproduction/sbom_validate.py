"""Offline validation using the retained, hash-verified CycloneDX schemas."""
from pathlib import Path
import argparse, hashlib, json, importlib.metadata
from jsonschema import Draft7Validator, RefResolver
p=argparse.ArgumentParser()
p.add_argument('sbom',type=Path)
p.add_argument('output',type=Path)
a=p.parse_args()
b=Path(__file__).resolve().parent/'schemas'
expected={'bom-1.6.schema.json':'3e92dddbc30cf7f6a02b80f0942b1a4cfd4fb1c26f1dfc4310afa9d613cafb93','spdx.schema.json':'baa9d3bd1ed57b6751b0887edead6b5063ff53ff7429cf85d476c6c94af0166e'}
for name,digest in expected.items():
 assert hashlib.sha256((b/name).read_bytes()).hexdigest()==digest,'Schema bytes changed'
schema=json.loads((b/'bom-1.6.schema.json').read_text());spdx=json.loads((b/'spdx.schema.json').read_text())
store={schema['$id']:schema,spdx['$id']:spdx,'http://cyclonedx.org/schema/spdx.schema.json':spdx,'https://cyclonedx.org/schema/spdx.schema.json':spdx}
def denied(uri): raise RuntimeError('Unexpected external schema request')
resolver=RefResolver.from_schema(schema,store=store,handlers={'https':denied,'http':denied})
sbom=json.loads(a.sbom.read_text());Draft7Validator(schema,resolver=resolver).validate(sbom)
report={'status':'PASS','schema':'CycloneDX 1.6','validator_version':importlib.metadata.version('jsonschema'),'component_count':len(sbom['components']),'schemas':expected,'sbom_sha256':hashlib.sha256(a.sbom.read_bytes()).hexdigest(),'schema_provenance':'Checksum-verified snapshots retained from supplied a11 review history','network_access_during_validation':False,'scope':'Schema validity only; no licence or vulnerability clearance'}
a.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
