# Zab-al-ack 0.1.0a12 — independently reviewed complete handoff

Start with `review/REVIEW.md` and `review/results.json`. This reviewed edition
corrects the lab role fixture (A4); runtime Python, SQL and wheel bytes match
the original candidate. It is not a new tagged or published plugin release.

- `plugin/source/`: corrected source, full cumulative changelog, deployment and
  rollback instructions, acceptance mapping and current bound evidence.
- `dist/`: wheel, normalized sdist, source ZIP, build provenance, checksums and
  local review Git bundle. No remote plugin push was performed.
- `website/`: the updated informational static site, including docs and blog.
- `review/`: findings, actual test/build/publication records, failed attempts,
  source inspection hashes, executed VM helpers and reproduction recipe.
- `original-input/`: the supplied a12 complete ZIP, retained byte-for-byte with
  its prior artifacts, reviews, screenshots and cumulative history.
- `DEPLOYMENT_INPUTS_REQUIRED.md`: the consolidated outstanding input register.

All production gates G1–G8 remain pending. A2's webhook transport remedy is
unresolved. Production examples are disabled with no active cohort. No live
monitoring credentials or production access were used. VM services are stopped.

Verify this packet from its extracted root with `sha256sum -c SHA256SUMS`.
That list covers every other file, including nested checksum lists and the
unchanged original ZIP. The outer ZIP's digest is returned with the download.

Use `plugin/source/docs/deployment.md`, `runbook.md`, `local-services.md`, and
`plugin/source/docs/RENAME.md` for deployment/rollback boundaries; the first three
paths are relative to `plugin/source/docs/`. Do not infer an in-place legacy
Ackline database upgrade. The `review/reproduction/` recipe is for disposable
services only. No secrets, VM disks or compiled OS binaries are included.
