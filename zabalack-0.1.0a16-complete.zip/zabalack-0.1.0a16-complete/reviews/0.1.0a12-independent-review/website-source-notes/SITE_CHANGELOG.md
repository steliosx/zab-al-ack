# Independent a12 review and recent-Zabbix lab — 2026-09-12

- Published the supplied a12 documentation and blog additions, retaining the
  current Site identity, public audience, branding and static architecture.
- Added a review article about source-built Zabbix 7.0.30/7.0.10, explicit role
  permissions, effective read-back and the preserved first-attempt failures.
- Explained the staged-context dependency fix, bounded cold-setup timeout and
  projection-observation wait, with their failed attempts and ten new regressions.
- Updated current evidence to the independently corrected source/harness and
  separated reference, native, real API and installed-wheel pipeline results.
  Counts overlap; QEMU timing is not a production capacity benchmark.
- Added practical role-verification guidance and the shared upstream
  acknowledge/unacknowledge capability. Kept A2 and G1–G8 open.
- Switched the first three guide illustrations to the supplied browser-rendered
  transcript PNGs with accurate dimensions and explicit real/mocked labels.
  The fourth image remains the supplied 7.0.10 frontend capture, not a new
  screenshot or a 7.0.30 image. Added it to the review article with that label.
- Corrected the old a12 article title/link and clarified that its image shows
  the source side, while thirteen cross-system checks are separate run evidence.
  Preserved the old release articles as historical records.
- Updated stale website-source notes, current source references, brief and
  screenshot metadata. No script, form, tracker, plugin download or monitoring
  connection was added.

Offline structural validation covers local links/fragments, metadata, inert
markup and PNG dimensions. Browser visual QA and new browser capture were not
executed. The complete handoff records the actual checks and publication result.

---

# Zab-al-ack a9 website rename

- Renamed current branding, metadata, public URLs, wordmark, icon title, asset
  filename and brief; kept the existing Alerta-inspired mark and visual theme.
- Updated practical commands, Alerta entry points, schema/service names and
  current evidence to the renamed a9 source.
- Added a9 release article and transition guidance. Preserved eight Ackline
  articles as historical records, with a clear note on each.
- Explained the fresh namespace, legacy-installation guard, proof rejection,
  privacy compatibility, retained evidence and outstanding deployment checks.
- Allowed the longer wordmark to wrap safely with the header at narrow widths.
- Static site remains informational, with no scripts, forms or plugin downloads.

Validation records and publication details are included in the complete a9
handoff. Browser visual QA was not executed for this update.

---

# Website update — a8 blog and independent review

- Added the supplied blog index and eight release notes, preserving the existing
  site branding and static architecture.
- Narrowed the a1 delivery wording: bounded acknowledgement is not an exactly-once
  guarantee. Renamed the a5 post so a source digest is not presented as proof of
  truthful authorship. Corrected the a2 index summary: one grant and one diagnostic
  retention change, rather than two grants.
- Updated the a8 article with the cause-macro fix, an exact upstream source link,
  the independent evidence-validation finding and its 56 regression cases.
- Distinguished original service reports from the independent review's 781/22/0
  reference result. Described the editable-install/local-bootstrap gap explicitly.
- Updated the homepage, technical evidence table and downloadable brief; removed
  stale a7 evidence labels. Practical SQL validation now uses the execution-owned
  runner. Added the A3 media-artifact note beside deployment guidance.
- Added the necessary blog heading and metadata styles and kept all pages free of
  scripts, forms, trackers, credentials and plugin release downloads.

Validation: content checked against original a8 and the independent review;
static entrypoints, local links/fragments, metadata and inert configuration
examples checked before publishing. Browser visual QA not executed. Plugin
runtime, SQL, package artifacts and recorded tests are unchanged by this update.
