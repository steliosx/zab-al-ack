# Zab-al-ack informational website

Static pages in `dist/`: overview, practical technical documentation, alpha
brief, twelve historical candidate articles and the independent a12 review.
There are no scripts, forms, analytics, backend, signup flows or monitoring
connections. Plugin packages and private review material are not hosted here.

The current review describes source-built Zabbix 7.0.30/7.0.10 lab evidence,
effective-role correction A4 and the unresolved A2 transport boundary. Original
release records and supplied screenshots remain labelled as historical evidence;
the 7.0.10 screenshot is not presented as a new 7.0.30 capture.

The existing amber/white/dark identity, SVG mark and responsive styles are
retained. Open `dist/index.html` locally or use the configured static host.
Static links, fragments, image dimensions and metadata are checked before
publication. Browser visual QA and new browser captures were not executed for
this update. See SITE_CHANGELOG.md and the complete handoff's review records.

The Site retains its existing hosting identity and public audience. Production
examples remain disabled with no active cohort, and G1–G8 remain open. Public
plugin repository/package ownership and publication approval are still pending.
