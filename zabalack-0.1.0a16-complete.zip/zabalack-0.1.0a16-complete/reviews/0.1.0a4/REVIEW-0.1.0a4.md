# Review — Ackline 0.1.0a4 handoff (2026-09-10)

Scope: the packaged `ackline-website-and-plugin-0.1.0a4.zip` (SHA-256
`a442abaab5a00ca55ea9b7cbcaf4772d3421ef4d91cbb28616abb99ebf133e08`), verified
from a fresh unzip in the same sandbox that prepared it. Reviewer environment:
Ubuntu 24.04, Python 3.12.3, Node 22, source-built PostgreSQL 18.3 and
PgBouncer 1.24.1, source-built Zabbix 7.0.10 on PostgreSQL 16 + PHP 8.3; no
Docker daemon with registry access, no Go toolchain.

## Verdict

Ready to push to a private repository as the fourth alpha candidate. It adopts
the independent 0.1.0a3 review's corrections unchanged (forward migration 006,
schema version 2) and closes that review's first-priority gap: the migration,
its upgrade scenarios and the full acknowledgement path were executed on real
components (native PostgreSQL 18.3 with PgBouncer, real Alerta HTTP, real
Zabbix 7.0.10). No code defect is open. What remains before a `0.1.0b1` tag is
owner-side and listed in `docs/BETA_READINESS.md`.

## Verified from the zip

| Check | Result |
|---|---|
| Top-level `SHA256SUMS` (226 entries, now including `plugin/source/RELEASE_SHA256SUMS` and `plugin/source/dist/SHA256SUMS`), `RELEASE_SHA256SUMS` (218), `dist/SHA256SUMS` (4) | All OK |
| Wheel `ackline-0.1.0a4-py3-none-any.whl` `ackline/` vs `src/ackline/` | Byte-identical (13 modules); wheel hash `aea61039…` identical across the three builds of this preparation |
| sdist `src/ackline/`, `sql/` vs tree | Identical |
| Nested `dist/ackline-0.1.0a4-source.zip` vs source tree | Identical, handoff metadata excluded |
| Git bundle `candidate/v0.1.0a4` | One commit `36f8df8b…`, `Ackline release preparation <release-preparation@localhost>`, dated `2026-09-10 00:00:00 +0000`, 209 tracked files, tree identical to source |
| Fresh venv from the restored clone (`requirements.lock`, `pip install --no-deps -e .`), `pip check` | Clean |
| `pytest tests/unit tests/security tests/release tests/alerta tests/rpc` from the clone | 236 passed, 0 failed, 6 skipped (native-only); `tests/release` 72 passed |
| `docs/sql_manifest.json` (12 entries, `package_version` 0.1.0a4) vs `sql/` | 0 mismatches |
| `lab/pglite_checks.mjs` from the clone | 8 SQL groups PASS (including the seven-scenario late-response group) |
| `zabbix/v1/test_webhook.cjs` | 12 passed |
| `tools/run_reference_suite.py --wasm` (evidence in tree) | 250 passed, 13 skipped, 0 failed (236 unit/mocked + 14 WASM; 13 skips are the native/real-Zabbix-only cases) |
| Native PostgreSQL 18.3 + PgBouncer 1.24.1, database `alerta`, fresh cluster per phase (evidence in tree) | 22 passed, 0 failed, 0 skipped; `shutdown_exit_code` 0 for every phase; includes both 005→006 upgrade scenarios |
| Real Zabbix 7.0.10 (evidence in tree) | 5 passed, 0 failed, 0 skipped: T13, T33, T11a, T1/T25 contract cases and the T1/T13/T25/T38 end-to-end case (real Alerta `PUT /alert/<id>/action` → capture → production worker/registry/client → real `event.acknowledge` → ledger `ok`/`write_response`, one attempt → projection → Zabbix read-back with one `[ackline]` acknowledgement → idle second pass) |
| `evidence/real-zabbix.xml`, `evidence/native-*.xml` | No lab paths, token file names, lab passwords or host fingerprints |
| `tools/public_audit.py --publication` | PASS, 209 files, 0 findings, ten publication inputs pending |
| Acceptance matrix | 38 PASS / 2 MANUAL_GATE_PENDING (T2, T27 procedural); native and real-Zabbix columns populated from the executed reports under the stricter validator |
| pip-audit 2.9.0 (hash-verified install) / npm audit | 50 packages, 0 advisories / 0 vulnerabilities |
| Clean-venv wheel install with `[alerta]` extra | Both `ackline_zabbix_*` entry points load; `ackline --config … config-check` exit 0 (`evidence/wheel-smoke.json`) |
| SBOM | Validates against the CycloneDX 1.6 schema (`dist/sbom-schema-validation.json`) |
| Implementation integrity vs the 0.1.0a3 candidate `afdfb858…` | `src/`: `__init__.py` (version), `health.py` and `worker.py` (schema version 2 gate) changed; `sql/`: `006_late_response_fencing.sql` added; nothing else in `src/` or `sql/` differs (`evidence/implementation-integrity.json`) |
| Identifier sweep of the whole handoff | No lab paths, token files, sandbox identifiers, personal names or e-mail addresses; `msp`/`alerta-ack` only in historical changelog/amendment text; no IPs beyond loopback/documentation ranges, no keys, no `.env`, no TODOs |
| Website | HTML well-formed, no `<script>`, external links limited to the canonical URL and the two upstream projects; `styles.css` and assets byte-identical to the published site; local links and anchors resolve; no `0.1.0a3` mention left |

## Findings in this pass (all corrected before packaging)

1. `docs/compatibility_manifest.json` still reported `postgresql_native` and
   `pgbouncer` as `BLOCKED_ENVIRONMENT` and `zabbix.real_server` as `NOT_RUN` —
   text inherited from the a1 packet that neither the a2 nor the a3 review
   caught. The three entries now describe the executed source-built runs and
   point at `evidence/native-run.json` / `evidence/real-zabbix-run.json`; the
   Compose form stays `NOT_RUN`.
2. Review-phase wording left by the a3 review checkout: `evidence/README.md`
   opened with "Current independent a3 review evidence" and referred to the
   deleted `REVIEW_STATUS.md`; `docs/deployment.md` described 006 as "the
   unreleased a3 review"; `docs/compatibility_manifest.json` carried
   `review_status: unreleased…` and a note that native/real evidence was "not
   current validation for migration 006". All rewritten for the a4 candidate.
3. The outer `SHA256SUMS` of the a3 handoff omitted nested checksum files (a3
   review observation); the a4 lists exclude only the list itself.

## Residual observations (not blockers)

- `classifiers` still says `Development Status :: 3 - Alpha`; flip to `4 - Beta`
  only with the `v0.1.0b1` tag.
- The Docker Compose forms of both labs and the hosted CI workflows remain
  unexecuted; the first private push is where that happens.
- Evidence runs are not yet digest-bound to the source/test tree (a3 review
  priority 2); this pass established the binding manually (bundle tree ==
  source tree == wheel/sdist contents, `code_under_test` recorded in the
  run records).
- Retained-ledger query plans and licence-label review remain owner items.
