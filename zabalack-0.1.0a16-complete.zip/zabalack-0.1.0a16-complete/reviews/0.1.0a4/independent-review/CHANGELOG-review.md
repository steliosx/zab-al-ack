# Unreleased a4 review tooling corrections

Based on candidate/v0.1.0a4 (36f8df8ba52bc53243eff3363a86711e080bc8cf).

- Validate the exact disposable Zabbix endpoint before any fixture HTTP access; validate correlated JSON-RPC version responses.
- Reject failed or inconsistent real-Zabbix evidence and missing native cleanup success.
- Add 70 mocked/security/release regression cases; full reference suite 320 passed, 0 failed, 13 skipped.
- No production Python/SQL, dependencies, package version, website or deployment defaults changed.

The patch is proposed and untagged. Built artifacts in this packet reproduce the original a4 candidate; they do not contain a new release.
