#!/usr/bin/env python3
"""Compare original and corrected optional fixtures with an HTTP spy only."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
from unittest.mock import patch


def check(root, filename, fixture_name, label, url):
    sys.path[:0] = [str(root), str(root / 'tests'), str(root / 'src')]
    path = root / 'tests/real_zabbix' / filename
    spec = importlib.util.spec_from_file_location('repro_' + root.name + fixture_name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    observed = {'case': label, 'fixture': fixture_name, 'client_constructions': 0,
                'post_calls': 0, 'token_reads': 0, 'actual_network_calls': 0,
                'fixture_module_sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

    class SpyClient:
        def __init__(self, *args, **kwargs):
            observed['client_constructions'] += 1

        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

        def post(self, target, **kwargs):
            observed['post_calls'] += 1
            request = kwargs['json']
            assert request['method'] == 'apiinfo.version'
            return SimpleNamespace(raise_for_status=lambda: None,
                                   json=lambda: {'jsonrpc': '2.0', 'id': request['id'], 'result': '7.0.10'})

    with tempfile.TemporaryDirectory(prefix='ackline-guard-repro-') as directory:
        fixture_path = Path(directory) / 'fixture.json'
        token_path = Path(directory) / 'token-never-opened'
        fixture_path.write_text(json.dumps({'isolated_lab': True, 'fresh_instance_no_notifications': True,
            'url': url, 'token_file': str(token_path),
            'end_to_end': {'zabbix_event_id': '1001', 'zabbix_trigger_id': '1002'}}))
        read_text = Path.read_text

        def guarded_read(path, *args, **kwargs):
            if path == token_path:
                observed['token_reads'] += 1
                raise AssertionError('Token must not be opened')
            return read_text(path, *args, **kwargs)

        env = {'ACK_TEST_REAL_ZABBIX_FIXTURE': str(fixture_path),
               'ACK_TEST_REAL_ZABBIX_LAB': 'YES_ISOLATED_LAB',
               'ACK_TEST_REAL_ZABBIX_WRITE': 'ACKNOWLEDGE_SYNTHETIC_LAB_EVENT'}
        with patch.dict(os.environ, env), patch.object(module.httpx, 'Client', SpyClient), patch.object(Path, 'read_text', guarded_read):
            try:
                getattr(module, fixture_name).__wrapped__()
                observed['fixture_result'] = 'returned_fixture'
            except BaseException as error:
                observed['fixture_result'] = type(error).__name__
    return observed


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--original', type=Path, required=True)
    parser.add_argument('--fixed', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    results = []
    for tree, root in [('original-a4', args.original), ('proposed-fixture-fix', args.fixed)]:
        for filename, fixture, label, url in [
            ('test_end_to_end.py', 'real_lab', 'remote-version-probe', 'http://192.0.2.1:58080/api_jsonrpc.php'),
            ('test_contract.py', 'real_fixture', 'userinfo-before-endpoint-validation',
             'http://synthetic-user:synthetic-secret@127.0.0.1:58080/api_jsonrpc.php'),
        ]:
            observed = check(root, filename, fixture, label, url)
            observed['tree'] = tree
            expected = 1 if tree == 'original-a4' else 0
            assert observed['client_constructions'] == expected and observed['post_calls'] == expected
            assert observed['token_reads'] == 0
            results.append(observed)
    report = {'layer': 'mocked fixture behavior; no network or credentials transmitted',
              'status': 'REPRODUCED_AND_GUARDED', 'results': results}
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
