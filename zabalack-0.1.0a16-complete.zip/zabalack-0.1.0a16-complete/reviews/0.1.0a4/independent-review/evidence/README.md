# Evidence attribution

- `independent-a4/`: this review's fresh execution of the unmodified a4 candidate.
- `proposed-correction/`: fresh full reference suite with the seven-file tooling patch.
- `supplied-a4-services/`: original native and real-Zabbix reports, inspected and internally consistent; not independently rerun here and not new execution of the patched fixtures.
- `verification/`: source/build/packaging checks, scans and explicitly mocked defect reproductions. Expected reproduction failures are not suite passes.

The original source archive's own `evidence/` remains the release preparer's supplied record. Fresh review evidence is kept here. Repeat/focused executions are not added to the full-suite totals. All G1–G8 remain pending.
