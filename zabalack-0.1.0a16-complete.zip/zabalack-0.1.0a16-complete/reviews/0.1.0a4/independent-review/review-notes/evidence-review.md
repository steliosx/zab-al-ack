# a4 release-evidence review

Reviewed the supplied candidate `36f8df8ba52bc53243eff3363a86711e080bc8cf`
without starting services or modifying the attachment. This is source review,
inspection of supplied evidence, and mocked validator tests; it is not a fresh
native PostgreSQL or real-Zabbix run.

## Verified closure and attribution

- The four native JUnit reports independently total **22 passed / 0 failed /
  0 skipped**, matching `native-run.json`: PostgreSQL 10, worker 4, Alerta 6,
  performance 2. Every phase records cleanup exit 0. The PostgreSQL report names
  both the migration-006 seven-scenario wrapper and the forward-upgrade wrapper.
- Real-Zabbix XML independently totals **5 / 0 / 0**, matching its JSON. All
  five record API version 7.0.10; the added end-to-end test records the native
  PostgreSQL backend and real-client evidence layer. The supplied evidence
  correctly distinguishes the source-built lab from the unexecuted Compose form.
- The compatibility manifest now reflects those runs and database schema 2.
  The acceptance mapping has 38 partial reference passes and two manual rows;
  every deployment result and G1–G8 remains pending. The ten publication inputs
  remain unset. No claim of production acceptance was found.
- Native runner startup/cleanup invalidation and SQL manifest checks from the
  independent a3 correction are retained.

## Concrete remaining findings

1. **Medium — real-source evidence validation can promote contradictory input.**
   `tools/update_acceptance.py` accepted a real-Zabbix run with status `FAIL`
   while selecting old all-passing XML, and ignored a JSON count of five failed
   tests when XML contained a pass. `build_acceptance.py` then sees only the XML.
   Isolated probes reproduced both paths; the supplied a4 reports themselves
   are consistent. The proposed correction requires a successful run, nonempty
   passing XML and exact integer count agreement. Explicit `NOT_RUN` selects no
   XML and cannot contain execution counts.
2. **Medium — absent native cleanup evidence was treated as success.**
   `phase.get('shutdown_exit_code', 0)` allowed a nominally passing manual run
   with no cleanup outcome. The correction requires explicit integer exit 0.
   Current supplied a4 records already meet this rule.
3. **Medium — the new end-to-end fixture accesses its URL before enforcing the
   declared lab boundary.** `tests/real_zabbix/test_end_to_end.py::real_lab`
   performs the version request directly against fixture `url`; it omits the
   exact loopback/port/path check in `test_contract.py`. The production endpoint
   validator is reached later and is intentionally broader than this lab's
   `127.0.0.1:58080` boundary. A wrong fixture can therefore cause a non-lab read
   before validation, or later select another local API port. Shared upfront
   validation and no-network negative tests are warranted. Root's separate
   lab-guard review handles this correction.

## Focused correction and executed evidence

Proposed patch: `evidence-fixes.patch`. It changes only the updater and its
release tests; there is no application or SQL change.

- Three selected new regressions **failed on unmodified a4**, proving the two
  real-report errors and missing-cleanup error before correction.
- After correction, the two focused test files passed **44 / 0 / 0**.
- The full release-test directory passed **96 / 0 / 0**, including **24 new
  cases** (22 real-report cases and two native cleanup cases).
- Regenerating the acceptance mapping against the actual supplied a4 reports
  succeeds and changes no acceptance/evidence bytes. `git diff --check` passes.
- `evidence-fix-validation.json` records these results. They are mocked
  release-tooling evidence, not native service evidence.

## Existing limitations still correctly open

The negative visibility case still accepts a generic permission/request RPC
error or an empty filtered result without independently proving the outside
event exists and matches the supplied group. The new positive end-to-end case
does not prove that negative fixture's existence. This is an acknowledged a3
follow-up and remains necessary for stronger permission evidence; it does not
invalidate the observed five lab-test passes or close G5.

Source/test digest binding, retained-ledger query plans, hosted CI/Gitleaks,
media import/macro/update-notification tests, external security review, SBOM
licence-label review and publication assignments remain open. The evidence
README's blanket “Every record ... exact tree” is broader than the intentionally
historical `pip-audit-before-tooling-fix.json`; R1 labels that old scan correctly,
so the README should exempt explicitly historical records.
