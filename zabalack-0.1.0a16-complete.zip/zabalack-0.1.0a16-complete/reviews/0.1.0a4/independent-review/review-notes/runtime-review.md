# Ackline 0.1.0a4 runtime and lab-source review

Reviewed source commit: `36f8df8ba52bc53243eff3363a86711e080bc8cf`.
Comparison baseline: corrected a3 review commit
`9a22f93493194e183a9da8fd7f8f3f842614cc0b`. File comparisons were used because
the histories differ. This review read the development contract, design revision
1.2, final-review interpretations and source amendments. It did not start native
services, access production or execute a real source acknowledgement.

## Result

The a3 delivery-safety correction is retained unchanged. Of 25 tracked files
under `src/` and `sql/`, only `src/ackline/__init__.py` differs: its package version
is now 0.1.0a4. All 12 SQL/migration/installation/rollback files match the corrected
a3 review. No new production-runtime defect was found in this change comparison.

A concrete safety regression exists in the new optional real-Zabbix end-to-end
fixture: it can contact an undeclared target before validating the lab URL. A
small proposed test-harness patch fixes that boundary and strengthens the common
version-response check. No production module, migration or grant is changed by
the patch.

## Finding: validate optional-lab targets before any HTTP construction

**Priority: medium; test-harness safety.** In supplied
`tests/real_zabbix/test_end_to_end.py`, `real_lab()` checks fixture booleans and
then sends `apiinfo.version` to the supplied URL (lines 48–54). It has no literal
loopback/port/path check. The older contract fixture does check those parsed
components, but initially accepts URL userinfo, query and fragment.

The production worker's endpoint validator still rejects remote plaintext
writes and requires a CA for HTTPS. That later boundary does not prevent the
earlier fixture version request. It also permits other loopback ports and the
`localhost`/`::1` names in general lab mode, whereas this optional suite declares
one exact API at `http://127.0.0.1:58080/api_jsonrpc.php`. This finding does not
establish that the supplied run contacted any incorrect target.

The original and corrected fixture functions were executed with an HTTP spy:

| Case | Original a4 | Proposed correction |
|---|---|---|
| E2E fixture with a synthetic remote URL | Constructs client, invokes `post`, returns fixture | Fails before constructing client |
| Contract fixture with synthetic URL userinfo | Constructs client and invokes `post`; later endpoint validation rejects | Fails before constructing client |

There were **zero actual network calls and zero token reads**. The record is
`lab-guard-reproduction.json`; the executable reproducer is
`reproduce-lab-guard.py`. The latter accepts explicit original/fixed source roots
and an output path, and records the fixture-module hashes used.

The proposed shared helper accepts only the canonical literal-loopback URL,
rejecting userinfo, query, fragment, other ports/hosts/paths, malformed values
and control characters without echoing the supplied URL. Both optional fixtures
call it before constructing a client or reading a token. They also require a
JSON-RPC 2.0 version response with the matching request ID, no `error`, and a
string `7.0.x` result. The old read-only versus write-opt-in behavior is retained.

**Executed regression evidence:** 46 passed, 0 failed, 0 skipped, all mocked.
This is fixture-boundary evidence, not native-service or source-permission
evidence. The prior 44-case development run is superseded by the final 46-case
run and must not be added to that total.

Changed files in `lab-guard-fix.patch`:

- `lab/real_zabbix_safety.py`
- `tests/real_zabbix/test_contract.py`
- `tests/real_zabbix/test_end_to_end.py`
- `tests/security/test_real_zabbix_lab_boundary.py`

From a corrected checkout with the pinned test environment:

```bash
python -m pytest tests/security/test_real_zabbix_lab_boundary.py -q
python reproduce-lab-guard.py --original /path/to/supplied-a4 \
  --fixed /path/to/corrected-a4 --output /path/to/lab-guard-reproduction.json
```

## Migration 006 and native coverage

`006_late_response_fencing.sql` preserves the reviewed behavior:

- Late callback evidence does not count as settled remote delivery. The private
  `attempt_unsettled(uuid)` helper has no PUBLIC/worker/probe/operator grant.
- Expired callbacks, delivery-lease replacement and replacement-worker shutdown
  preserve uncertainty. Completed or explicitly settled work is protected from
  duplicate callbacks. Explicit settlement and an additional deliberate retry
  remain separate operations.
- The forward repair holds affected unresolved late-response work across old
  lease generations. It retains evidence and performs no external operation.
- Schema version 2 remains required by `ProbeConfig` and worker health checks.
  Migration 006 deliberately invalidates the sealed function fingerprints and
  does not grant or invoke the installation principal's reseal authority.
- Deployment instructions preserve 001–005 and require a fenced upgrade and
  separate reseal. Rollback retains schema 2, migration 006 and ledger data;
  old schema-1 binaries remain health-gated.

The native runner explicitly includes both tests in
`tests/postgres/test_late_response.py`. One invokes the seven-scenario SQL
regression group; the second temporarily restores the old function in a
rolled-back fixture, reproduces two damaged pre-006 states, applies 006, verifies
uncertainty and blocked delivery, verifies unhealthy function fingerprints, then
explicitly reseals under the installation role. This is meaningful upgrade and
coordination coverage beyond merely checking that migration DDL succeeds.

The lease cases use synthetic ledger rows and explicit timestamp adjustment.
Executing them on a native PostgreSQL engine verifies its SQL/role behavior;
it does not turn them into a simultaneous two-worker remote-write failover test.
Other native tests separately cover actual restricted login identities,
multisession verification claims, native timeout cancellation and transaction
pool reuse. Those scopes should remain separately attributed.

## What the added end-to-end case establishes

The new test drives the real Alerta `/action` route, real PostgreSQL persistence
and capture, the production worker's verifier and endpoint registry, the real
Zabbix client and API, and ledger/projection readback. It requires one write
attempt, a successful ledger outcome, preserved event identity, one matching
neutral comment, and an empty second delivery pass. A fresh second synthetic
problem keeps this case separate from the existing API-write contract case.

The case reuses `persisted_api`, which injects a healthy signer probe, and
`RoleSelectedLabPostgres`, which connects through the lab administrator and
executes runtime statements under the restricted role. Its HTTP client is
Flask's in-process test client. Thus it does not by itself establish deployed
signer-probe wiring, actual worker-login authentication, reverse-proxy behavior,
Zabbix media ingestion, macro expansion, notification actions or HA. The alert
is seeded through the Alerta model rather than a real media-type ingestion.

The readback uses deprecated `select_acknowledges`; the cached pinned Zabbix
`CEvent.php` explicitly accepts it and maps it to `selectAcknowledges`. This is
not a demonstrated API incompatibility. Using the canonical name later would
remove unnecessary reliance on the deprecated alias.

## Remaining specific test-evidence improvement

`test_T11a_real_negative_visibility_scoped_token` still accepts an empty result
or generic `api_permission_or_request_rejected` without independently verifying
the outside event exists and belongs to the stated outside group. The added
positive E2E success with the same token does not establish that separate fixture
fact. A nonexistent event, incorrect group filter or general request rejection
can still satisfy the negative test.

Require independently recorded positive existence/association evidence for the
outside synthetic event and distinguish a valid empty visibility result from a
generic RPC failure. This remains a focused improvement to fixture evidence;
the current source does not claim it closes the deployment G5 permission gate.
All G1–G8 remain environment-specific deployment gates.
