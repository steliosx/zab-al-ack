# Ackline 0.1.0a4 — independent verification

**a4 preserves the reviewed delivery-safety correction and builds reproducibly.**
The new native and real-Zabbix evidence is meaningful and internally consistent.
This pass found two remaining issues in test/lab tooling and supplies a tested
seven-file patch. No new production runtime regression was found by this change
review. The patch is an unreleased proposal; no version, tag or publication changed.

## Independent results

| Check | Executed here | Result |
|---|---|---|
| Original a4 reference suite | Unit/mocked plus PostgreSQL WASM | **250 passed, 0 failed, 13 skipped** |
| Proposed correction reference suite | Same phases, with 70 new regression cases | **320 passed, 0 failed, 13 skipped** |
| SQL assertion groups | PostgreSQL 18.3 WASM | **8 passed**, including migration 006 and the late-response group |
| Synthetic Zabbix webhook contracts | Node fixtures | **12 groups passed** |
| Quickstart | Alerta HTTP, PostgreSQL WASM, mocked Zabbix | Exit 0 |
| Clean-venv rebuilt wheel | 12 submodules, both Alerta entry points, CLI, inert configuration, pip check | PASS |
| Python advisory lookup | Exact 50-package lock | 0 advisories, 0 skipped |
| Node advisory lookup | Pinned lab lock | 0 vulnerabilities |
| Supplied SBOM | Offline CycloneDX 1.6 strict schema | Valid, 53 components; not licence clearance |
| Targeted original-source export audit | 209 files; 12 SQL manifest entries | 0 findings; 10 publication inputs still pending |
| Static site | Local references, anchors, script elements | 26 references valid, no script; no browser/rendering or publication test |

The baseline total is 236 unit/mocked plus 14 PostgreSQL WASM passes; the proposed
correction total is 306 plus 14. The 13 skips comprise eight native-only cases
and five real-Zabbix cases. The reference runner intentionally clears service
fixture variables. PostgreSQL WASM does not establish native login, pooling,
concurrency, cancellation or HA behavior. Focused reruns are not added to totals.

Native execution was attempted with `native_ci.py --isolated-lab` and returned
NOT_RUN/exit 2 because Docker is unavailable. This environment also has no
usable native lab binaries or ability to switch to the required non-root user.
Real Zabbix and Gitleaks were not independently executed. The security command's
overall exit 2 correctly records Gitleaks NOT_RUN despite the passing Python scan.
Hosted CI, Compose-form labs, deployment and external security review remain open.

## Findings and proposed corrections

### 1. Enforce the lab target before any HTTP access

The new end-to-end fixture posts `apiinfo.version` to the fixture URL before
checking the declared loopback API. Its production client later enforces its
own endpoint restrictions, but those do not protect that first request. The
older contract fixture also accepts URL userinfo before its later client check.
The E2E version probe additionally omitted JSON-RPC request-ID/envelope checks.

The patch gives both fixtures one canonical lab URL validator, run before HTTP
client construction or token access. It rejects alternate hosts/ports/paths,
userinfo, query/fragment and malformed inputs, and validates the matching
JSON-RPC version response. Existing read and explicit write opt-ins are preserved.
Errors omit supplied URL/response contents. Production endpoint policy is unchanged.

**Evidence:** 46 new mocked regressions pass. A separate behavioral reproducer
shows original fixtures reaching an HTTP spy for unsafe targets, while patched
fixtures reject before constructing a client. No real network calls or token
reads occurred in this reproduction. The patched fixtures still need their next
real-service run on the prepared isolated lab.

### 2. Reject inconsistent service evidence before mapping acceptance

`update_acceptance.py` accepts a real-Zabbix run marked FAIL when the selected
XML still contains passing cases. It also ignores mismatches between the run's
counts and XML. The native path treats a missing cleanup result as exit zero.
These can turn an interrupted or stale run into apparently passing evidence.

The patch requires explicit native cleanup success and consistent real-Zabbix
PASS status, nonempty all-passing XML and exact counts. NOT_RUN contributes no
service passes; an absent record never selects an old XML merely because it exists.

**Evidence:** three selected regression tests fail against original a4, as
expected, and pass after correction. There are 24 new evidence-validator cases;
the corrected release-test subset has 96 passes. The stricter mapper accepts the
actual supplied native/Zabbix reports and regenerates the same acceptance outputs.
This finding does **not** imply those supplied reports contain false passes.

## What the supplied native and Zabbix evidence establishes

I independently counted **22 native passes** and **five real-Zabbix passes** in
the supplied XML. JSON agrees, every native phase records cleanup exit zero,
and the native PostgreSQL group includes migration 006 and both upgrade scenarios.
The compatibility manifest now describes those runs and preserves the distinction
between source-built labs and unexecuted Compose workflows. The stale wording
identified in your packaging pass is corrected.

The E2E test exercises the Alerta action route, native capture/ledger/projection,
production worker verifier/registry/client and real Zabbix acknowledgement/readback.
Its setup injects the signer's health probe, supplies the test's actor context,
seeds the alert through the model, and uses a SET ROLE database adapter. It does
not establish complete ingestion/media behavior, deployed authentication, real
signer-probe configuration, runtime database login identity or update notifications.
It is useful core-path evidence, with those boundaries.

The reviewed migration and all other SQL files are byte-identical to the corrected
a3 review. Of the 13 runtime Python files, only `__init__.py` changes, for a4's
version. Schema version 2, the private helper and separate readiness reseal remain.

## Remaining improvements

1. Apply the tooling patch before the next candidate's lab/CI run; rerun the real
   service cases and perform hosted CI/Gitleaks when the private repository exists.
2. Bind every run record to source and test digests. This packet records input,
   patch and artifact hashes, but supplied run records are not cryptographic
   attestations of their source tree.
3. Strengthen the outside-scope Zabbix test with independent positive proof that
   the excluded event exists and belongs to its stated group. Empty results or a
   generic request rejection alone do not prove a tenant-permission boundary.
4. Retain the outstanding production inventories, G1–G8, named owners and ten
   publication inputs. Native lab fixtures close none of those deployment gates.
   Retained-ledger performance and ambiguous licence labels still need review.

## Package integrity and use

Input ZIP SHA-256:
`5540e1dd7399a1c83b1f2cbcd3a79cab124c0912dae7af61430eb9bdfee712e8`.
Candidate commit: `36f8df8ba52bc53243eff3363a86711e080bc8cf`.

All 322 outer checksum entries verify, including nested lists. The two outer
handoff/source lists also cover all their contents except themselves. The inner
four-entry build manifest covers its declared build products; the Git bundle
and SBOM validation record are additionally covered by outer manifests.

The bundle, source tree and source ZIP agree across all 209 files; sdist `src/`
and `sql/` agree. I built the wheel, normalized sdist and source ZIP twice, and
all three are byte-identical to the supplied artifacts. The rebuilt wheel hash is
`aea610397c6c233cb7441b64676a6e8decd5d91a889bc03a00ec16ee2a2ef651`.
Build environment: Python 3.12.14, setuptools 83.0.0, wheel 0.46.2; Node 24.19.0.
The supplied preparation used Python 3.12.3 and Node 22. Node dependencies were
reused locally after exact lock-entry and installed-version checks; fresh npm
installation/tarball verification was not executed. No lifecycle scripts ran.

`dist/` contains the independently rebuilt **unmodified a4** artifacts and the
original Git bundle. The tested changes are in `a4-tooling-corrections.patch`
and `proposed-files/`; they do not change the production wheel or SQL. The exact
original complete ZIP and unchanged website are included. Evidence is separated
by origin in `evidence/README.md`. No raw lab logs or private fixtures are exported.

From the extracted review-packet root, on an isolated development host:

```bash
sha256sum -c SHA256SUMS
git clone --branch candidate/v0.1.0a4 dist/ackline-0.1.0a4-public.git.bundle reviewed
git -C reviewed remote remove origin
git -C reviewed apply --check ../a4-tooling-corrections.patch
git -C reviewed apply ../a4-tooling-corrections.patch
cd reviewed
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements.lock
.venv/bin/python -m pip install --no-deps --no-build-isolation -e .
npm ci --prefix lab --legacy-peer-deps --ignore-scripts --no-audit --no-fund
TZ=UTC .venv/bin/python tools/run_reference_suite.py --wasm
```

The packet validates patch application against a fresh clone of the supplied
bundle. No production deployment, migration, restart, acknowledgement, push or
publication was performed. Keep the shipped a4 tag and migrations immutable;
select a new version when preparing the next published candidate. Deployment and
rollback instructions remain in the source archive's `docs/`; this tooling patch
requires no database migration or production rollout.
