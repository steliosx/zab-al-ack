# Ackline a4 independent review packet

Start with ACKLINE_A4_REVIEW.md. Verify SHA256SUMS after extraction.

- dist/: independently rebuilt original a4 wheel, sdist and full source ZIP, plus original candidate Git bundle.
- a4-tooling-corrections.patch / proposed-files/: seven-file tested lab/evidence correction, not a new published version.
- evidence/: fresh independent and separately attributed supplied service evidence.
- supplied-a4/: exact original complete attachment.
- website/: unchanged static a4 site.
- reproduce-lab-guard.py: parameterized HTTP-spy reproducer; no network or token reads.

Original source and supplied service results remain intact. Apply the patch to a local a4 checkout using the commands in the review. Do not treat lab fixtures as G1–G8 approval.
