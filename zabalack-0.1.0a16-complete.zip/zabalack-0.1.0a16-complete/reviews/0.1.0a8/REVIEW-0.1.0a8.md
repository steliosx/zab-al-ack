# Review — Ackline 0.1.0a8 (2026-09-11)

Input: `ackline-0.1.0a7-complete.zip` (SHA-256
`0a0fe268b52f55ad1826d17060184d9095961674d7a2fc0e5257a7d2023f732b`), the
a6/a7 candidate produced with another tool (commits `55a64856…`, `67f84543…`
on my a5 candidate `3dcc4188…`). Reviewer environment: Ubuntu 24.04,
Python 3.12.3, Node 22, source-built PostgreSQL 18.3 and PgBouncer 1.24.1,
source-built Zabbix 7.0.10 (two instances) on PostgreSQL 16 + PHP 8.3; no
Docker daemon with registry access, no Go toolchain. Output: this candidate,
commit `e9bc2448280afa33ff766e232bb3f7be18e43914` on branch `candidate/0.1.0a8`.

## Verdict

Ready to push to a private repository as the eighth alpha candidate. The a7
packet was internally consistent and its reference, quality and mutation
results reproduced exactly. Executing its service suites for the first time
found one product defect that had been present since 0.1.0a1 — the reference
media webhook rejected every cause-less problem from a real Zabbix 7.0.x
(A3) — and three lab/test-harness faults; all are corrected, and every
service suite now passes on this tree. No code defect is open. Owner-side
items are listed in `docs/BETA_READINESS.md`.

## The a7 packet, verified

| Check | Result |
|---|---|
| Outer `SHA256SUMS` (287 entries), `plugin/RELEASE_SHA256SUMS` (274), `plugin/dist/SHA256SUMS` (4) | All OK |
| Bundle `ackline-0.1.0a7.bundle` branch `candidate/0.1.0a7` | Commit `67f84543…` on `55a64856…` on `3dcc4188…` (my a5); tree identical to `plugin/source` and the source ZIP |
| Wheel `bf1ba855…`, sdist `9bf9f24b…`, source ZIP `32a293a4…` | Wheel `ackline/` byte-identical to `src/ackline/` (13 modules); `tools/verify_release.py` PASS |
| Reference suite in a fresh pinned environment (`requirements.lock` + hash-verified `requirements-quality.lock`) | 719 passed, 22 skipped, 0 failed; digests equal the manifest (`2f9b9f78…`/`e337b925…`) |
| `tools/run_quality.py` (ruff, mypy, pip check) | PASS |
| `tools/run_mutation_checks.py` PR and nightly | 12/12 and 20/20 killed on a 107-test baseline |
| `tools/run_sql_checks.py`, `zabbix/v1/test_webhook.cjs`, quickstart, export audit | 8 groups, 12 groups, PASS, 262 files / 0 findings |
| pip-audit / npm audit | 58 packages, 0 advisories / 0 vulnerabilities |
| a5→a7 `src/`/`sql/` diff read | Typed identity/intent shapes with casts after existing validation, `WRITE_TIMEOUTS` constant, schema-3 gates, migration 007 narrow and consistent with 006's guards; no behavioural regression found |

## Service execution (never run before a8)

| Suite | Result on the final a8 tree |
|---|---|
| Native PostgreSQL 18.3 + PgBouncer 1.24.1, five fresh-cluster phases, same targets and environment as `tools/native_ci.py` | 36 passed, 0 failed, 0 skipped (`postgres` 19, `delivery_faults` 5, `worker` 4, `alerta` 6, `performance` 2); cleanup exit 0 per phase; `tree_unchanged` true |
| Real Zabbix 7.0.10 through `tools/record_real_zabbix.py --run` | 5 passed, 0 failed, 0 skipped; observed version 7.0.10; no lab material in the public report |
| Deployment-path lab (`tests/deployment_e2e` through the unmodified `lab/deployment_e2e_runtime.py`) | 4 passed, 13/13 observations true; second fresh Zabbix instance, fresh PostgreSQL 18.3 cluster with `scram-sha-256` host logins, hostnames `postgres`/`zabbix-web`/`runner` on loopback; recorded with `not_docker: true` (R12) |

## Findings (all corrected before packaging)

1. **Product — reference media webhook (A3).** First real delivery failed with
   `Invalid numeric identifier: cause`: Zabbix 7.0.10 renders
   `{EVENT.CAUSE.ID}` as `*UNKNOWN*` for a problem without a cause
   (`expression.c`, `STR_UNKNOWN_VARIABLE`, confirmed in the built source).
   The 0.1.0a1 reading that the resolver leaves the macro unexpanded was
   wrong and the synthetic Node contract asserted the wrong behaviour. Fixed
   in `webhook.js`, artifact rebuilt, Node contract corrected (14 groups),
   amendment A3, deployment note to re-import.
2. **Native phase pollution.** `test_T37` left 32 live verification leases;
   the a6 settled-expiry tests after it failed on `claim_verification`
   returning `None`. T37 now releases its flood.
3. **Lab media check.** Imported script compared byte for byte; Zabbix stores
   CRLF. Normalized comparison; five offline cases.
4. **Lab configuration-cache race.** Problem raised before the server cache
   held the new action → no escalation, no webhook, timeout. Bounded 12 s
   grace; offline case.

Environmental, not repository faults: `zabbix_server`'s libcurl honours the
sandbox's `HTTPS_PROXY`, so the lab server must run with a clean environment
(the Compose form does); the deployment lab's `$ZBX_SERVER_NAME` and image
identities do not apply outside Docker.

## Verified from the packaged zip

| Check | Result |
|---|---|
| Outer `SHA256SUMS`, `plugin/RELEASE_SHA256SUMS`, `plugin/dist/SHA256SUMS` | All OK (nested lists included) |
| Wheel `de5eb61e…` `ackline/` vs `src/ackline/`; vs a7 source only `__version__` differs | Byte-identical; identical across the builds of this preparation |
| sdist `src/`/`sql/` and nested source ZIP vs tree | Identical (handoff metadata excluded) |
| Bundle restore, `tools/verify_release.py --dist ../dist`, `tools/public_audit.py` from the clone | Tree identical; PASS; PASS with every run record bound to the clone |
| Fresh venv from the clone: reference suites, bare `pytest` collection | See `verification/handoff-checks.json` |
| Identifier sweep of the whole handoff | No lab paths, token files, sandbox identifiers, personal names or e-mail addresses beyond the release-preparation placeholder; tool author identities only in the a6/a7 commit metadata |
| Website | No `<script>`, external links limited to the canonical URL and the two upstream projects; local links resolve; copy states a8 results and A3 |

## Residual observations (not blockers)

- The Docker Compose forms of both labs and every hosted workflow remain
  unexecuted; the first private push is where that happens.
- The deployment lab is fresh and synthetic; media/notification behaviour on
  a production-like instance, A2 transport remediation, query plans at scale,
  licence review and external security review remain owner items.
- Signed attestation has not been issued; local provenance is consistency only.
