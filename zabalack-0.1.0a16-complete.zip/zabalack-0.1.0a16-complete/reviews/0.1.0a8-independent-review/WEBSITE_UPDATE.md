# Published website update

The reviewed static site is live at https://ackline.stel.chatgpt.site.

- Eight candidate blog posts, with corrected claims and an independent-review
  follow-up in the a8 post.
- Homepage, technical guide and alpha brief now distinguish original service
  reports from independent reference evidence.
- Eleven HTML pages, 234 local references and the inert configuration example
  checked. No scripts, forms, credentials or monitoring-system connections.
- Exact static files in website/ match the uploaded deployment archive.
  Deployment status was confirmed successful. Browser visual QA was not run.

Only the informational Site source was pushed. The plugin review branch, wheel,
sdist, source ZIP, Git bundle and test evidence are unchanged from the preceding
independent-review handoff. No plugin package was published or production system
accessed. The original a8 packet and prior review evidence remain included.

Website source revision: c38a87dbc881e2863e0f49266456cdcd9a5c2536.
Previous website version remains available through Sites version history.
Detailed changes and the publication record are in website-notes/.
