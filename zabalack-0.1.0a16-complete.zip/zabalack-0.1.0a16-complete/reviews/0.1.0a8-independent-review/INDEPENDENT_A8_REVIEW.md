# Independent a8 review correction

This working tree is a proposed tooling correction on candidate
`e9bc2448280afa33ff766e232bb3f7be18e43914`; it is not a separately versioned
or published release. The complete review handoff retains the original a8
packet, independent original-tree execution, this patch and corrected-tree
execution as separate evidence. Runtime Python, SQL, media artifacts and
dependency pins are unchanged by the correction.

## F1: contradictory deployment evidence passed the export gate

The a8 export audit checked the deployment record's PASS label and source/harness
digests but not its reported tests, observations, cleanup or runtime. On a copy
of the supplied source, changing every observation to false, reducing the pass
count to zero, failing cleanup, declaring a changed tree or wrong versions, or
retaining only status and digests still produced a clean export audit. Rehashed
synthetic source/sdist archives with contradictory reports also passed the
unsigned release verifier. This could distribute misleading service evidence;
it is not a defect in acknowledgement delivery.

`tools/deployment_evidence.py` now provides the shared consistency check. It
requires exactly four passing service cases, all thirteen required observations,
explicit integer-zero cleanup for the runner and project, expected reference
versions and layer, pending deployment gates, consistent timezone-aware run
timestamps and a source/harness binding with `tree_unchanged: true`. The bounded
JSON reader rejects duplicate fields and non-JSON numbers. A NOT_RUN record
cannot retain executed counts or observations. The export/build gate and archive
verifier both call it; the service runner applies it after cleanup before PASS.

Docker records require the four expected image SHA-256 identities. R12 local
records require `not_docker: true`, separate component/runner descriptions and
no Docker image claim. Validation does not turn one runtime into another.
It checks consistency, not authorship or cryptographic provenance; an entirely
fabricated but internally consistent unsigned record remains inside the trusted
release-author boundary. Execution-owned runners and hosted provenance remain
separate controls.

The new regression file first produced **53 expected failures and 3 passes**
against unchanged a8 validation. After the correction its 56 cases passed;
combined with the existing native-support helper tests, the focused run passed
119 cases. Full reference/mutation results for the final tree are recorded in
the accompanying independent review. These are offline regression results,
not service runs or deployment permission evidence.

## F2: local-process evidence is not an installed-wheel service reproduction

The supplied a8 deployment record identifies an editable source installation in
the local reference environment. The checked-in Dockerfile builds and installs
a wheel, but its execution is still NOT_RUN. The runtime checks installed plugin
entry points; it does not establish that the local application's imported code
came from the packaged wheel. The local bootstrap/equivalent recorder described
in R12 is not in the source packet. Its reported service results can be reviewed,
but cannot be reproduced by a supplied one-command local runner.

The service-lab documentation now distinguishes the intended Docker/wheel path
from that supplied local-process evidence. Before claiming repeatable packaged
service coverage, run the shipped Docker path on a supported isolated host, or
provide and inspect the local bootstrap/recorder, exact component identities and
an import-origin check for the wheel. No old service report is rebound to this
corrected harness. Original a8 service evidence stays in the supplied packet;
native/real-Zabbix/deployment service execution remains NOT_RUN in this review.

G1–G8, A2 transport remediation, hosted CI/CodeQL/Gitleaks, signed attestations
and external security review remain separate open gates. No production or public
website change was made by this review.
