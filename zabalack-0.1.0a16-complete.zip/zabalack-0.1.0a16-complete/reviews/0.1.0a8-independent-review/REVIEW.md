# Independent a8 review and proposed tooling correction

This report records the plugin review completed before the website update. See
WEBSITE_UPDATE.md for the subsequent publication of the informational site.

This is a review checkout of `e9bc2448280afa33ff766e232bb3f7be18e43914`,
not a newly versioned release. The original a8 ZIP and its author's service
reports are retained separately in the complete review handoff. No production
system or public website was changed; nothing was pushed or published.

## Results executed in this review

| Check | Unmodified a8 | Corrected tree | Evidence limit |
|---|---|---|---|
| Reference pytest suite | 725 passed / 22 skipped / 0 failed | 781 passed / 22 skipped / 0 failed | Unit/mock, actual Alerta with WASM persistence, and explicit optional-service skips |
| Unit/mock/property/offline portion | 702 passed | 758 passed | Includes release/harness checks, not native service coverage |
| PostgreSQL 18.3 WASM portion | 23 passed / 4 skipped | 23 passed / 4 skipped | Sequential SQL and Alerta persistence; no native authentication/concurrency proof |
| Optional native/real-service portion | 18 skipped | 18 skipped | No independent service execution |
| Expanded property profile | 46 passed | 46 passed | Nightly profile, fixed seed 20260912; separate from reference totals |
| Curated nightly mutations | 20/20 killed | 20/20 killed | 107-case baseline; assertion failures required; Python/mock scope |
| Ruff / strict mypy scope / pip check | PASS | PASS | Existing gradual quality scope unchanged |
| Supplemental SQL | 8 groups passed | 8 groups passed | Actual WASM engine, separate from pytest total |
| Synthetic webhook | 14 groups passed | 14 groups passed | No real macro delivery or notification claim |
| Isolated quickstart | PASS | Runtime unchanged | Original run uses WASM and mocked source effects |
| Python / Node advisory queries | 58 packages / 0 advisories; npm 0 vulnerabilities | Same exact dependency locks | Known-advisory queries, not a security clearance |
| Native PostgreSQL / PgBouncer | NOT_RUN | NOT_RUN | Docker/native runtime unavailable |
| Real Zabbix / deployment service lab | NOT_RUN | NOT_RUN | Supplied author results are not independent passes |

All **803** discovered corrected-tree pytest cases were selected, with no missing
or extra cases after UUID/proof-label normalization retaining multiplicity.
The acceptance mapping retains 38 reference PASS rows and two manual rows;
**G1–G8 remain MANUAL_GATE_PENDING**. Repeat/profile/regression executions
are not added together into a misleading unique-test total.

The original wheel, sdist and source ZIP rebuilt byte-for-byte. The original
wheel was installed into a fresh environment: three entry points, CLI, inert
configuration, dependency consistency and installed Python bytes passed.
Corrected build verification and wheel-smoke records accompany the handoff.
The corrected wheel has updated README metadata; its runtime Python bytes are
unchanged. SBOM schema validation passed for 61 reference/tooling components;
licence and independent security clearance remain pending.

## Findings and changes

**F1 — corrected:** the export audit and unsigned archive verifier accepted
contradictory deployment PASS reports. A shared bounded validator now checks
counts, thirteen observations, versions, cleanup, timestamps, runtime identities,
source/harness binding and unchanged-tree status. The service recorder checks its
final record too. Fifty-six regression cases cover malformed and valid reports;
against unmodified a8, 53 failed as expected and three passed. After the patch,
all 56 passed, and the combined focused helper run passed 119 cases.

**F2 — documented, still open:** the supplied local-process deployment report
identifies an editable source installation. The shipped Docker/wheel service
path was not executed, and the local bootstrap/recorder described in R12 is not
included. Those runs cannot establish reproducible installed-wheel service
coverage. See [full reasoning](docs/INDEPENDENT_A8_REVIEW.md).

The a8 cause-macro amendment A3 was checked against the exact upstream 7.0.10
source revision: a cause-less event reaches `STR_UNKNOWN_VARIABLE`. The webhook's
bounded handling of `*UNKNOWN*` is supported by that source and synthetic tests.
All runtime Python, SQL, media artifacts and dependency pins remain unchanged
by this review. No architectural amendment or new migration is introduced.

A2 webhook transport remediation remains a deployment blocker. Gitleaks,
hosted CI/CodeQL, signed attestations, external security review and production
permission/operational tests remain NOT_RUN or pending. Targeted export checks
and unsigned build consistency do not replace those controls.

## Reproduction and operations

Use the Python 3.12 reference lock, hash-pinned quality lock and fresh npm install
with `--ignore-scripts`; follow `docs/RELEASING.md`. The review handoff includes
commands, original/corrected evidence, patch, Git bundle, wheel, sdist, source ZIP
and checksums. Preserve the review branch separately from the original a8 tag.

Deployment and non-destructive rollback remain in `docs/deployment.md`,
`docs/rollback.md` and `docs/runbook.md`. There is no schema or source-write
behavior change to roll back in this correction. Production examples remain
disabled with empty cohorts and endpoints. `docs/INPUTS_REQUIRED.md` remains
the consolidated operator/publication input register. Never use lab results to
close the deployment gates.
