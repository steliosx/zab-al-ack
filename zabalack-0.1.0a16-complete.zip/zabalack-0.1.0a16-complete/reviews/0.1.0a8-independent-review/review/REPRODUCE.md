# Reproduce the independent review

Use a disposable development checkout restored from the included bundle.
Python 3.12 and Node 22 are the reference targets. Network access is needed to
download the pinned public dependencies when they are not already cached.
These commands do not authorize production access.

```bash
cd ackline-reviewed
export TZ=UTC
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements.lock
.venv/bin/python -m pip install --require-hashes --only-binary=:all: -r requirements-quality.lock
.venv/bin/python -m pip install --no-deps --no-build-isolation -e .
npm ci --prefix lab --legacy-peer-deps --ignore-scripts
.venv/bin/python tools/run_quality.py
.venv/bin/python tools/run_sql_checks.py --isolated-lab
node zabbix/v1/test_webhook.cjs
.venv/bin/python tools/run_reference_suite.py --wasm
.venv/bin/python tools/run_mutation_checks.py --profile pr
# Copy evidence/mutation-run.json if you want to retain both profile results.
.venv/bin/python tools/run_mutation_checks.py --profile nightly
ACK_HYPOTHESIS_PROFILE=nightly ACK_HYPOTHESIS_SEED=20260912 .venv/bin/python lab/pglite_exec.py --isolated-lab -- .venv/bin/python -m pytest tests/property tests/postgres/test_stateful_ledger.py -q
.venv/bin/python tools/update_acceptance.py
.venv/bin/python tools/public_audit.py
.venv/bin/python tools/build_release.py
.venv/bin/python tools/verify_release.py
```

The review used fresh reference/quality environments and a fresh npm install.
`requirements.lock` pins versions but is not a hash lock; the quality lock is
hash-pinned. Do not apply `--require-hashes` to the version-only reference lock.
No dependency lock or test exclusion was weakened to get a pass.

Focused correction:

```bash
.venv/bin/python -m pytest tests/release/test_deployment_evidence.py tests/native_support -q
```

The executed result was 119 passes (56 new regression cases and 63 helper cases).
To reproduce the negative demonstration, create a disposable checkout of original
commit `e9bc2448280afa33ff766e232bb3f7be18e43914` and copy only the new regression
test there. Its 53 failures and three passes are expected with old validation.
Do not overwrite the preserved original packet or turn these expected failures
into reference-suite failures/passes. The focused tooling patch and full patch
are supplied separately for review.

The full reference run selected all 803 collected cases, as recorded in
`collection-corrected.json`. Optional service skips remain skips. The extra
property run and mutation profiles overlap reference cases and are not added
together as a unique test total.

## Native and deployment runs

On a supported disposable Docker host, inspect the lab before starting it:

```bash
.venv/bin/python tools/run_deployment_e2e.py --isolated-lab --plan
.venv/bin/python tools/native_ci.py --isolated-lab
.venv/bin/python tools/run_deployment_e2e.py --isolated-lab
```

In this review workspace, the native and deployment runners exited **2** and
recorded **NOT_RUN** because Docker was unavailable. A native source-built
fallback was also unavailable; the workspace cannot drop root privileges to an
unprivileged PostgreSQL account. No access controls or PostgreSQL root checks
were bypassed. The real-Zabbix recorder ran with `--not-run`; its exit zero
records unavailability, not a passing service test. No real Zabbix fixture was
invented. Follow `plugin/source/lab/README.md` and the service-lab docs for a
proper disposable fixture and restricted/witness tokens on a supported host.

## Package installation and extra checks

The included `tools/wheel_smoke.py` must run with a newly created environment's
Python from outside the checkout. Install the reference lock and the desired
wheel into that environment first, then invoke:

```bash
/path/to/fresh-venv/bin/python /path/to/review/tools/wheel_smoke.py /path/to/plugin/source /path/to/plugin/dist/pypi/ackline-0.1.0a8-py3-none-any.whl /path/to/smoke-result.json
```

It checks actual import origin, all 13 Python module bytes against source and
wheel, the three entry points, dependency consistency and disabled configuration.
It never starts delivery. The original and exact final corrected wheels passed
in separate fresh environments. Installed-wheel service coverage remains open.

Additional executed checks: original isolated quickstart; Node webhook contract;
Python advisory scan (58 packages, zero reported advisories); npm audit (zero
reported vulnerabilities); CycloneDX 1.6 schema validation (61 components,
jsonschema 4.25.1); source/bundle/artifact equality and targeted export audit.
The security runner exited **2** overall because Gitleaks was unavailable, even
though its pip-audit step passed. Hosted CodeQL/CI and signed attestations were
not executed. Raw operational/pytest logs are not exported; redacted JUnit,
structured records and normalized results are supplied instead.

Setup retries are not product findings or passing tests: an offline npm install
initially lacked two packages, then the normal pinned install succeeded; an
over-strict reference-lock hash invocation was corrected; a mistyped pytest path
collected no tests before the correct focused command ran; schema validation
used the available Python 3.12 interpreter after an old environment launcher was
unavailable. Provisional wheel checks are not used as final-artifact evidence.
