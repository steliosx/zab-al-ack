# Independent execution of unmodified a8

These are this review's runs against the original source and harness, separate
from the author's service reports inside the original complete ZIP. Reference:
725 passed, 22 skipped, zero failed. SQL 8 groups; synthetic webhook 14 groups;
nightly property 46 passed; curated nightly mutation 20/20 killed. The original
wheel passed a fresh-environment import/byte/CLI check. Native, real Zabbix and
deployment service execution are NOT_RUN. Reports are not rebound to the corrected
harness. The rebuilt-dist folder reproduces original artifact bytes and therefore
retains the original author's packaged evidence without changing its meaning.
