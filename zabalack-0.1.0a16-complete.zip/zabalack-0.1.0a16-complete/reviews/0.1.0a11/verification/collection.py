from pathlib import Path
from collections import Counter
import subprocess,json,re,sys
R=Path(sys.argv[1]).resolve();sys.path.insert(0,str(R/'tools'))
from evidence_utils import cases,code_digests
run=json.loads((R/'evidence/reference-run.json').read_text())
raw=subprocess.run([str(R/'.venv/bin/python'),'-m','pytest','--collect-only','-q'],cwd=R,capture_output=True,text=True,check=True).stdout
collected=[s for s in raw.splitlines() if s.startswith('tests/') and '::' in s]
def norm(s):
 s=s.replace('/','.').replace('.py::','::')
 s=re.sub(r'\[zabalack:v1 action=[^\]]+\]', '[redacted-signing-proof]', s)
 # JUnit truncation/redaction normalises reserved marker values and dynamic UUIDs.
 s=s.replace('::','.')
 return re.sub(r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}','<uuid>',s)
recorded=[x['nodeid'] for phase in run['phases'] for x in cases(R/phase['junit'])]
a=Counter(map(norm,collected));b=Counter(map(norm,recorded))
# Evidence may redact marker parameters; retain exact counts and report any disagreement.
missing=a-b;extra=b-a
report={'collected':len(collected),'recorded':len(recorded),'counts_equal':len(collected)==len(recorded),'code_digests':code_digests(R),'missing':sum(missing.values()),'extra':sum(extra.values()),'status':'PASS' if not missing and not extra else 'FAIL'}
(R/'evidence/collection-check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
