# Verification records

These records describe the a11 preparation. Source-run evidence and the
acceptance map live in plugin/source/evidence. final-checks.json reports actual
exit codes: NOT_RUN service results are not passes. The underlying commands are
in the source tools and ALPHA_REPORT.md. Repeated profiles overlap.

release-verification.json verifies the four build subjects. The Git bundle is
covered separately by plugin/RELEASE_SHA256SUMS and the complete checksum list.
wheel-smoke.json uses wheel_smoke.py with arguments SOURCE WHEEL OUTPUT, run
from outside SOURCE with a fresh non-editable installed-wheel environment.

collection.py takes the source root and expects its .venv; it compares pytest
collection with the selected JUnit cases, normalising UUIDs and redacted marker
labels. sbom.py uses jsonschema==4.26.0 and the included CycloneDX schema snapshots.
The preparation's local helper paths are not deployment inputs.

site-validation.json records static checks, not browser QA. PNG images are
renders of the corresponding SVG illustrations; no browser screenshot is claimed.
