import json,hashlib,importlib.metadata
from pathlib import Path
from jsonschema import Draft7Validator,RefResolver
B=Path(__file__).resolve().parent;r=B.parent/'plugin/source';schema=json.loads((B/'schemas/bom-1.6.schema.json').read_text());spdx=json.loads((B/'schemas/spdx.schema.json').read_text())
store={schema['$id']:schema,spdx['$id']:spdx,'http://cyclonedx.org/schema/spdx.schema.json':spdx,'https://cyclonedx.org/schema/spdx.schema.json':spdx}
def denied(uri):raise RuntimeError('Unexpected external schema request')
resolver=RefResolver.from_schema(schema,store=store,handlers={'https':denied,'http':denied})
sbom=json.loads((r/'evidence/sbom.cdx.json').read_text());Draft7Validator(schema,resolver=resolver).validate(sbom)
report={'status':'PASS','schema':'CycloneDX 1.6','validator_version':importlib.metadata.version('jsonschema'),'component_count':len(sbom['components']),'schemas':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (B/'schemas').glob('*.json')},'schema_source':'https://raw.githubusercontent.com/CycloneDX/specification/1.6/schema/','scope':'Schema validity only, not licence or vulnerability clearance; downloaded schema snapshots retained in complete ZIP verification/schemas'}
(r/'evidence/sbom-validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
