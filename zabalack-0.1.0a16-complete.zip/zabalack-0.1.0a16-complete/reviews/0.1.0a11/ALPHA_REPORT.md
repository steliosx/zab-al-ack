# Zab-al-ack 0.1.0a11 — illustrated documentation

Based on the attached a10 complete archive, SHA-256
`da037fc2140779ac0626f194b8a952bae2b987511c9f5c2a9e03db465070a748`,
whose nested checksum lists were verified. The a10 Git bundle was cloned
locally; no plugin source was pushed. The complete original archive is included
under `history/` in the a11 handoff.

The docs and the a10/a11 blog posts now have three illustrations of actual lab
output, with copyable examples and reproduction instructions. **These are not
browser or application UI screenshots.** Browser policy blocked local capture
pages. The SVG illustrations and PNG renders are explicitly labelled; authentic
UI captures remain a follow-up. See [visual guide](docs/visual-guide.md).

| Executed layer | Result | What it establishes |
|---|---|---|
| Reference | 808 passed / 22 skipped / 0 failed | 779 unit/mock/property/offline and 29 real PostgreSQL WASM passes; all 830 collected cases selected |
| SQL / webhook | 8 / 15 groups passed | WASM SQL semantics and synthetic Node payload contracts |
| Documentation capture | 1 passed | New T1/T36 case, also in the reference count; real Alerta action/capture/worker, synthetic JWT, injected probe, SET ROLE and mocked Zabbix |
| Quickstart | PASS | Inert CLI plus overlapping synthetic/Alerta/WASM examples |
| Quality | PASS | Pinned Ruff, gradual strict mypy and pip check |
| Mutation | PR 12/12; nightly 20/20 detected | Each profile has a passing 111-case baseline; unit/mock scope |
| Additional generated profile | 46 passed / 0 skipped / 0 failed | Fixed-seed nightly property/WASM profile, overlapping the reference count |
| Python / Node advisory queries | 58 Python packages / 0 advisories; npm 0 vulnerabilities | Known-advisory queries only |
| SBOM validation | PASS; 61 components | CycloneDX 1.6 schema, no licence/security clearance |
| Website static checks | 14 pages; 330 local references; 7 figure instances | Asset/link/dimension/alt-text checks; 9 historical posts byte-identical |
| Native PostgreSQL/PgBouncer | NOT_RUN | Required binaries not configured; native runner exits 2 |
| Real Zabbix | NOT_RUN | No a11 disposable instance/fixture supplied |
| Installed-service deployment lab | NOT_RUN | Docker unavailable; operator-provided local service topology not supplied |
| Browser screenshots / site browser QA | NOT_RUN | File navigation blocked; buildless static site has no compatible managed preview |
| Hosted CI, CodeQL, Gitleaks, attestations | NOT_RUN | No hosted or cryptographic provenance claim |

Repeated checks overlap. Never add them to the unique reference total. Four
skips are native-only checks selected in the WASM phase; eighteen need optional
services. Historical a10 native 41, real Zabbix 5 and installed-wheel 4 cases
remain preserved, but are not a11 results. The a10 R14 local runners remain
available; their earlier successful execution is not rescinded by this
workspace's missing services.

The package builder checks two byte-identical wheels and normalized sdists, and
repeats source-ZIP generation. The complete ZIP's `verification/` includes
fresh-wheel import/entry-point/byte checks, archive consistency and checksums.
The wheel contains runtime modules; the sdist/source ZIP also contain docs,
illustrations, SQL, tests, deployment tooling and reference manifests.

Runtime Python differs from a10 only in the version constant. All SQL, media
artifacts and dependency pins are unchanged. No migration is needed for this
version; retain the separate fresh-namespace boundary for old Ackline installs.
[Deployment](docs/deployment.md), [rollback](docs/rollback.md) and the consolidated
[input register](docs/INPUTS_REQUIRED.md) remain part of the package. Production
examples have writes disabled, zero active cohorts and zero endpoints. G1–G8,
A2, release-owner inputs and independent review remain open.

The informational website is the only external publication in this turn.
No package publication, plugin repository push, production monitoring access,
credentials, migrations, service restarts, notifications or real acknowledgements
were performed.
