# Zab-al-ack 0.1.0a11 — complete handoff

The updated informational site is https://zabalack.stel.chatgpt.site/.
The technical guide and a10/a11 blog posts contain three output illustrations:
configuration, single-alert acknowledgement, and the ledger/projection result.
These are observed-output figures, **not UI screenshots**. Browser capture was
blocked; the image captions and visual guide explain the fallback and how to
capture authentic UI screens in a suitable isolated lab.

## Contents

- plugin/source: installable source, all SQL/migrations, roles/grants, workers,
  collectors, media types, deployment/rollback tooling, tests and documentation.
- plugin/dist/pypi: built wheel and normalized source distribution.
- plugin/dist: deterministic source ZIP, Git bundle and build provenance.
- website: complete static site, docs, all eleven blog posts and SVG figures.
- visual-previews: PNG renders of the SVG figures for convenient viewing.
- CHANGELOG.md: full historical changelog with a11 changes and their rationale.
- verification and reviews/0.1.0a11: current records and the complete a10→a11 diff.
- history: byte-exact original a10 ZIP, retaining all prior reviews and releases.

## Verify and restore

From this complete directory:

```bash
sha256sum -c SHA256SUMS
(cd plugin && sha256sum -c RELEASE_SHA256SUMS)
(cd plugin/dist && sha256sum -c SHA256SUMS)
git clone -b candidate/0.1.0a11 plugin/dist/zabalack-0.1.0a11.bundle zabalack-lab
```

The bundle's candidate commit is
79cf4fe70492be76c8e44c81b34177c3bf48db14, dated in UTC. Its tree matches the
included source. Keep any existing deployment and ledger separate.

## Run the illustrated example

Use a disposable Linux workspace, Python 3.12, Node 22 and npm. From the source
root, follow README.md to install the pinned dependencies (reference lock first,
hash-verified quality lock separately), then:

```bash
npm ci --prefix lab --legacy-peer-deps --ignore-scripts
TZ=UTC .venv/bin/python tools/capture_docs.py --isolated-lab
```

For a non-editable wheel smoke environment, install the reference dependencies
then the matching wheel with --no-deps. Documentation and SQL are in the source
package; the wheel registers the CLI and both Alerta entry points.

## Evidence and deployment

Reference: 808 passed, 22 skipped, none failed. The new illustration test is
one of the 29 WASM passes. Source/harness digests, exact counts and other checks
are in plugin/source/ALPHA_REPORT.md and evidence/. Native PostgreSQL/PgBouncer,
real Zabbix, deployment services and hosted checks were NOT_RUN for a11. a10's
service reports remain historical. The built wheel passed a fresh non-editable
install and was byte-identical across repeated builds.

No production access or package/repository publication was performed. All
production examples retain disabled external writes and no active cohort.
G1–G8 and the reference webhook transport issue A2 remain open. Use
plugin/source/docs/INPUTS_REQUIRED.md as the single consolidated deployment and
publication input register; do not send passwords or tokens in chat.

For deployment and non-destructive rollback, read docs/deployment.md,
docs/rollback.md and docs/runbook.md under plugin/source. a11 adds no migration;
all SQL is byte-identical to a10. Older Ackline installations still require the
fresh-namespace procedure and preservation of their ledgers/proofs. Rollback
must stop new delivery under the documented operator procedure and retain queues,
action history and in-flight outcome evidence; do not drop the schema.
