# a11 preparation notes

Requested: screenshots in documentation and blog posts. Browser security
rejected local-file navigation. No browser workaround was attempted. The
implemented fallback is three explicitly labelled SVG output illustrations,
PNG renders, HTML transcript sources and a reproduction/capture guide.
Actual product UI screenshots remain open.

The demonstration test initially looked for state pending immediately after
verification. SQL actually reports authorised before delivery; the fixture now
looks up the specific alert regardless of state and uses a unique synthetic
event to avoid confusing another test's action with its own. The workflow and
existing assertions are unchanged. The completed fixture passed alone and in
the full reference suite.

Two initial release tests caught the export gate still expecting a10. Its
expected version was bumped without relaxing validation; a full rerun passed.
Final packaging initially added the bundle to dist/SHA256SUMS, which the strict
four-subject verifier correctly refused. The original checksum layout was
restored. The bundle is covered by the outer release checksum lists instead.

Final reference: 808 passed, 22 skipped, zero failures. Historical a10 service
successes were not rebound to a11. G1–G8 and A2 remain open. Runtime code and SQL
are unchanged from a10 apart from the Python version string.
