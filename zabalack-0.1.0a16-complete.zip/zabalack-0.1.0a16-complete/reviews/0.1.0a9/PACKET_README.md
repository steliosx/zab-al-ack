# Zab-al-ack 0.1.0a9 — complete handoff

Formerly Ackline. Public brand: **Zab-al-ack**; package, Python import, CLI and
installation namespace: **`zabalack`**.

Website: https://zabalack.stel.chatgpt.site

| Contents | Location |
|---|---|
| Complete source: plugins, SQL, workers, CLI, collectors, labs, deployment and tests | `plugin/source/` |
| Built wheel, sdist, source ZIP, provenance and artifact checksums | `plugin/dist/` |
| Full local Git history through a9 | `plugin/zabalack-0.1.0a9.bundle` |
| Cumulative changelog including all earlier 1–8 upgrades and a9 justification | `plugin/source/CHANGELOG.md` and `plugin/source/docs/RELEASE_AMENDMENTS.md` |
| Rename compatibility, transition, old/new SQL hashes | `plugin/source/docs/RENAME.md`, `plugin/source/docs/rename_manifest.json` |
| Executed results and individual reports | `plugin/source/ALPHA_REPORT.md`, `plugin/source/evidence/` |
| Deployment and non-destructive rollback | `plugin/source/docs/deployment.md`, `plugin/source/docs/rollback.md` |
| Consolidated deployment inputs (including a9 transition requirements) | `plugin/source/docs/INPUTS_REQUIRED.md` |
| Publication-owner inputs | `plugin/source/config/publication.pending.json` |
| Reference and compatibility manifests | `plugin/source/docs/reference_manifest.json`, `plugin/source/docs/compatibility_manifest.json` |
| Published static pages, docs, nine blog posts and assets | `website/` |
| Site changelog, checks and publication record | `website-notes/` |
| Release verification, smoke helper and complete a8→a9 patch | `validation/` |
| Unmodified previous complete Ackline handoff | `history/` |
| Checksums for every file in this handoff except the checksum list itself | `SHA256SUMS` |

**Compatibility:** a9 uses a fresh installation namespace and refuses a database
containing the old `ackline` schema. This release does not provide an in-place
Ackline upgrade. Keep old ledgers, signatures and immutable migration checksums
intact. Old proofs cannot validate under the new HMAC domain. Consult the
transition guide before any existing-installation change; do not bypass guards.

**Fresh a9 results:** 796 reference passes, 22 explicit skips, zero failures;
8 SQL groups; 15 synthetic webhook groups; 46 additional property passes;
PR 12/12 and nightly 20/20 curated mutations detected; quality, quickstart,
reproducible builds, installed-wheel smoke and unsigned release checks passed.
Native PostgreSQL/PgBouncer, real Zabbix and the installed service path were not
run for a9. Gitleaks and hosted checks were not run. All G1–G8 remain pending.
Historical service reports are not reassigned to this release.

## Verify and recover the source locally

From this directory on Linux:

```bash
sha256sum --check SHA256SUMS
git clone --branch candidate/0.1.0a9 plugin/zabalack-0.1.0a9.bundle zabalack
cd zabalack
```

Follow `README.md` in that clone to install the exact local lab dependencies and
run its tests. The bundle and source export describe the same a9 commit; no
plugin source was pushed to a remote. Dependency wheelhouses, virtual
environments and raw private logs are intentionally not release files.

The website can be previewed independently by serving `website/` with a static
HTTP server; it has no scripts, forms or monitoring connections. The public
Site retains its original project and public audience with the new slug.
No claim is made that the old URL redirects. The plugin remains an alpha
candidate: no package upload, production migration, service restart,
acknowledgement, notification or credential change was performed.
