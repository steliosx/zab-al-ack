# Zab-al-ack 0.1.0a9 — execution and rename report

This candidate renames the reviewed Ackline a8 parent
`aaadf4919f837b4a003a8fc57c469f70ca98d08c`. It introduces a fresh `zabalack`
namespace and retains the independent review's deployment-evidence validator.
See `docs/RENAME.md`, `docs/rename_manifest.json` and release amendment R13.
Historical Ackline artifacts and reports remain separate, without rebinding.

## Executed on the a9 tree

| Check | Result | Evidence scope |
|---|---|---|
| Reference suite | **796 passed / 22 skipped / 0 failed** | 768 unit/mock/property/offline and 28 actual PostgreSQL WASM passes |
| Collection coverage | 818 collected, 818 selected; zero missing/extra | UUID/proof labels normalized, multiplicity retained |
| New rename regressions | 15 passed within the reference total | 10 unit/security and 5 PostgreSQL-engine guard cases |
| Additional generated profile | 46 passed / 0 skipped / 0 failed | Nightly seed 20260912; overlaps reference cases |
| Curated PR mutations | 12/12 detected | 111-case passing baseline; assertion failures only |
| Curated nightly mutations | 20/20 detected | Same scope; profiles overlap |
| Supplemental SQL | 8 groups passed | Real PostgreSQL 18.3 WASM engine, sequential SET ROLE checks |
| Synthetic media contract | 15 groups passed | Node payload and early echo filtering; no real notification claim |
| Quality | Ruff, gradual strict mypy, pip check passed | Existing pinned scope |
| Isolated quickstart | Passed | Actual Alerta HTTP and WASM persistence; mocked source effects |
| Python advisory query | 58 packages / zero advisories / zero skipped | Exact reference and quality locks; known advisories only |
| Node advisory query | Zero reported vulnerabilities | Pinned lab dependencies |
| SBOM schema | Valid CycloneDX 1.6; 61 components | Schema validity is not licence or security clearance |

The 22 reference skips comprise four native-only cases in the WASM phase and
18 optional service cases. Every skip remains visible in JUnit. Supplemental
runs overlap and are not added to the unique reference total. T1–T39 retain
traceability, including T11a/T11b: 38 reference PASS rows, two manual rows.
**G1–G8 remain MANUAL_GATE_PENDING.**

The first rename run failed one harness count expectation: adding the historical
neutral-comment echo regression raised the Node groups from 14 to 15. The exact
expected count was updated; the final full run passed. No test was removed or
weakened to hide a product failure. The native installer guards were executed
against a synthetic retained schema inside rollback-only lab transactions.

## Packaging checks

`dist/BUILD_PROVENANCE.json` records the two-build wheel, normalized sdist and
source ZIP comparisons. The fresh-venv smoke test checks installed import origin,
all 13 Python modules against source and wheel, all three entry points, dependency
consistency, CLI help and inert configuration. `evidence/wheel-smoke.json` gives
the exact installed wheel hash. `validation/wheel_smoke.py` in the complete
handoff contains its reproduction helper. `tools/verify_release.py` checks the
final artifacts; the complete handoff also verifies its checksum lists and Git
bundle/source equivalence. This is unsigned consistency, not signed provenance.

## Not executed for a9

Native PostgreSQL login/concurrency, PgBouncer, real Zabbix and the complete
installed-wheel deployment service path are **NOT_RUN**: Docker Compose is not
available in this workspace. The native/deployment runners refuse execution
and record that limitation. Original Ackline service successes are historical,
not a9 passes. Gitleaks is unavailable; the security runner returns 2 despite
successful advisory queries. Hosted Actions, CodeQL and attestation issuance
remain unexecuted. Browser visual QA is not claimed for the static-site rename.

The A2 webhook transport remedy and deployment negative tests remain open.
The Alerta startup identity, installed routing/privacy, actual tenant permissions,
media/update operations, batch measurements, maintainers and records policy
remain deployment or publication inputs. F2 from the a8 review (missing local
service bootstrap and unexecuted complete wheel service path) remains open.

No plugin repository or package was pushed or published. Only the informational
website is published under the new brand; it has no monitoring-system connection.
No production database, acknowledgement, notification or credential was touched.
