from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit,unquote
import json,re,subprocess,sys,tempfile,hashlib
site,plugin,out=map(lambda s:Path(s).resolve(),sys.argv[1:])
root=site/'dist'
class Page(HTMLParser):
 def __init__(self,text):
  super().__init__(convert_charrefs=True);self.ids=[];self.refs=[];self.meta={};self.scripts=0;self.forms=0;self.codes={};self.active=None;self.feed(text)
 def handle_starttag(self,t,attrs):
  a=dict(attrs)
  if a.get('id'):self.ids.append(a['id'])
  if t=='script':self.scripts+=1
  if t=='form':self.forms+=1
  if t=='img':assert 'alt' in a
  for k in ('href','src'):
   if a.get(k):self.refs.append(a[k])
  if t=='meta':self.meta[a.get('name') or a.get('property')]=a.get('content')
  if t=='code' and a.get('id'):
   self.active=a['id'];self.codes[self.active]=''
 def handle_endtag(self,t):
  if t=='code':self.active=None
 def handle_data(self,s):
  if self.active:self.codes[self.active]+=s
pages={p:Page(p.read_text()) for p in root.rglob('*.html')}
checks=0
for p,doc in pages.items():
 assert len(doc.ids)==len(set(doc.ids)),str(p)+' duplicate ID'
 assert not doc.scripts and not doc.forms
 assert doc.meta.get('description') and doc.meta.get('og:title') and doc.meta.get('og:description')
 for ref in doc.refs:
  u=urlsplit(ref)
  if u.scheme or u.netloc:continue
  target=(p.parent/unquote(u.path)).resolve() if u.path else p
  if target.is_dir():target=target/'index.html'
  assert target.is_relative_to(root) and target.is_file(),f'{p.name}: {ref}'
  if u.fragment and target in pages:assert unquote(u.fragment) in pages[target].ids,f'{p.name}: missing {ref}'
  checks+=1
 assert 'https://ackline.stel.chatgpt.site' not in p.read_text()
# Historical articles are byte-identical apart from their explicit name-history note.
history=0
for p in (root/'blog').glob('0-1-0a[1-8].html'):
 original=subprocess.run(['git','show','c38a87dbc881e2863e0f49266456cdcd9a5c2536:dist/blog/'+p.name],cwd=site,check=True,capture_output=True,text=True).stdout
 article=lambda x:x[x.index('<article'):x.index('</article>')+len('</article>')]
 current=re.sub(r'\n      <p class="historical-note">.*?</p>','',article(p.read_text()))
 assert current==article(original),p.name+' historical article modified'
 history+=1
python=plugin/'.venv/bin/python';doc=pages[root/'docs.html']
with tempfile.TemporaryDirectory() as d:
 config=Path(d)/'disabled.json';config.write_text(doc.codes['example-disabled'])
 result=subprocess.run([str(plugin/'.venv/bin/zabalack'),'--config',str(config),'config-check'],check=True,capture_output=True,text=True)
 data=json.loads(result.stdout);assert data['valid'] and not data['configuration']['enabled'] and not data['configuration']['external_writes_enabled']
 assert data['configuration']['cohort_count']==data['configuration']['instance_count']==0
code='import json; from zabalack.config import Settings; c=json.loads('+repr(doc.codes['example-cohort'])+'); assert c["enabled"] is False; print("disabled cohort parsed")'
subprocess.run([str(python),'-c',code],check=True,capture_output=True,text=True)
files=list(root.rglob('*'));regular=[p for p in files if p.is_file()]
report={'status':'PASS','html_pages':len(pages),'files':len(regular),'local_references_checked':checks,'historical_articles_preserved':history,'scripts':0,'forms':0,'current_brand':'Zab-al-ack','config_example':'PASS_WITH_ACTUAL_A9_CLI','browser_visual_qa':'NOT_RUN','file_sha256':{p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(regular)}}
out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='file_sha256'}))
