"""Run with the clean wheel environment's Python, from outside the source tree."""
from pathlib import Path
import hashlib
import importlib.metadata as metadata
import json
import os
import subprocess
import sys
import zipfile

source, wheel, output = map(lambda value: Path(value).resolve(), sys.argv[1:])
import zabalack

package = Path(zabalack.__file__).resolve().parent
assert package.is_relative_to(Path(sys.prefix).resolve())
assert not package.is_relative_to(source)
dist = metadata.distribution('zabalack')
assert dist.version == '0.1.0a9'
loaded = []
for entry in dist.entry_points:
    if entry.group in {'alerta.plugins', 'console_scripts'}:
        assert callable(entry.load())
        loaded.append(entry.name)
assert sorted(loaded) == ['zabalack', 'zabalack_zabbix_ack', 'zabalack_zabbix_normalise']
with zipfile.ZipFile(wheel) as archive:
    files = [name for name in archive.namelist() if name.startswith('zabalack/') and name.endswith('.py')]
    for name in files:
        assert archive.read(name) == (source / 'src' / name).read_bytes()
        assert archive.read(name) == (package.parent / name).read_bytes()
env = dict(os.environ, TZ='UTC')
env.pop('PYTHONPATH', None)
cli = str(Path(sys.executable).parent / 'zabalack')
subprocess.run([sys.executable, '-m', 'pip', 'check'], env=env, check=True, capture_output=True)
subprocess.run([cli, '--help'], env=env, check=True, capture_output=True)
check = subprocess.run([cli, '--config', str(source / 'config/production.example.json'), 'config-check'],
                       env=env, check=True, capture_output=True, text=True)
data = json.loads(check.stdout)
assert data['valid'] is True
config = data['configuration']
assert config['enabled'] is False and config['external_writes_enabled'] is False
assert config['cohort_count'] == config['instance_count'] == 0
record = {
    'status': 'PASS', 'version': dist.version, 'fresh_venv': True,
    'wheel_sha256': hashlib.sha256(wheel.read_bytes()).hexdigest(),
    'review_harness_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'installed_entry_points': sorted(loaded), 'installed_modules_checked': len(files),
    'imports_from_venv_site_packages': True, 'package_bytes_equal_source': True,
    'package_bytes_equal_wheel': True, 'pip_check': 'PASS', 'cli_help': 'PASS',
    'inert_configuration': 'PASS',
    'scope': 'Fresh wheel environment, import origin, package bytes and inert CLI only; no service run',
}
output.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
