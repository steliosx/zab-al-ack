# Zab-al-ack a15 reviewed handoff

One ZIP contains the exact supplied `zabalack-0.1.0a15-complete.zip` and the
independent review, fresh test evidence, byte-identical rebuilt wheel/sdist/source
ZIP, proposed documentation corrections and ten reusable writer regressions.
The original release, website and cumulative changelog remain unchanged inside
the supplied complete ZIP. This is a review packet, not a new alpha version.

Start with `independent-review/REVIEW.md` and `RESULTS.json`. Reproduction commands
are in `independent-review/REPRODUCE.md`. The proposed patch applies cleanly but
has not been applied to the retained release or live website. Its extra tests
are separate from the supplied package harness.

Independent reference results: **855 passed, 23 skipped, 0 failed**; 8 SQL groups,
15 webhook groups, 12/20 mutation kills, 46 overlapping nightly property passes,
quality and quickstart passed. Ten additional permission checks passed on a15;
four deliberate a14 reproductions failed and are retained. The supplied native
42 / real Zabbix 6 / installed-wheel pipeline 4 records were validated, not rerun
here. G1–G8 and A2 remain open.

Verify this packet with `sha256sum -c SHA256SUMS`, then extract and verify the
supplied complete release using its own checksum lists. Checksums and local
build provenance establish consistency, not a signature or deployment approval.
No source, live site or production service was changed by this review.
