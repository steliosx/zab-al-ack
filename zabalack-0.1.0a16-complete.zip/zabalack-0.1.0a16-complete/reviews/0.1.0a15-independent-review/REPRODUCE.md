# Reproduce this review

Extract the supplied complete ZIP, then clone its bundle into a disposable
checkout. Use Python 3.12 and set `TZ=UTC`. Install `requirements.lock`, then
`requirements-quality.lock` with `--require-hashes --only-binary=:all:`, and the
editable project. Install the lab with
`npm ci --prefix lab --ignore-scripts --legacy-peer-deps`.

Before modifying any evidence, verify and build from the original checkout:

```bash
python -B tools/public_audit.py
python -B tools/verify_release.py --dist /path/to/supplied/plugin/dist
python -B tools/build_release.py
```

Compare wheel/sdist/source ZIP SHA-256 values against the supplied artifacts.
The provenance also identifies the actual Python version; it can legitimately
differ when artifact bytes match across Python patch releases. Preserve the
supplied records and use a separate working checkout for fresh tests:

```bash
python tools/run_review.py --isolated-lab --phase quality --phase sql \
  --phase reference --phase mutation-pr --phase mutation-nightly \
  --phase property-nightly --phase quickstart
node zabbix/v1/test_webhook.cjs
```

For the additional tests, run from this review's `review-tests/` directory using
the same pinned Python interpreter. Select an absolute checkout path:

```bash
ZABALACK_REVIEW_SOURCE=/path/to/a15 python -m pytest -q test_evidence_modes.py
ZABALACK_REVIEW_SOURCE=/path/to/a14 python -m pytest -q test_evidence_modes.py -k public_record
```

The second invocation is an intentional old-version reproduction: four public
mode assertions fail on a14. The complete ten-case selection passes on a15.
These tests create only synthetic temporary JSON; no token, database or service
is required. Do not reinterpret that intentional baseline failure as an a15
failure or the deselected baseline cases as passes.

To inspect the proposed corrections from an extracted complete a15 packet:

```bash
git apply --check /path/to/review/proposed/documentation-corrections.patch
```

Use `python -B` for read-only artifact inspections to avoid writing bytecode into
the supplied source. Fresh reference tests run in the disposable checkout and
retain their own identity. Never rebind the original service records to changed
source/harness digests. Follow the package's existing release guide before
adopting changes in a new candidate. Nothing in this review authorises public
upload, a website deployment or a production operation.
