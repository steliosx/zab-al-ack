# Independent review of Zab-al-ack 0.1.0a15

**Verdict: the candidate reproduces, and the evidence-writer permission fix is
valid. No blocking runtime or SQL defect was found in this review.** The changes
I recommend are precise documentation corrections and additional direct writer
regressions. The supplied a15 ZIP is retained unchanged, including its complete
source, website, cumulative changelog, artifacts, prior reviews and service
records. No a16 release or modified a15 package is being issued here.

## What was independently executed

| Check | Result |
|---|---|
| Archive integrity | All 998 outer checksum subjects, 320 plugin subjects and four distribution subjects match; 999 original files |
| Source and lineage | All 308 source files match Git commit 14b8c72f34d93b16c102013a232a995d75f7a6eb; base is our exact c2b7fb58 a14, input ZIP e59045a3… |
| Build from source | Wheel, normalized sdist and source ZIP match supplied bytes exactly; two local builds match each other |
| Build provenance | Only the Python patch version differs: supplied 3.12.3, this review 3.12.14. The regenerated provenance retains that difference |
| Reference suite | **855 passed / 23 skipped / 0 failed**: 826 unit/mock/property/offline and 29 actual PostgreSQL WASM passes |
| Supplemental SQL / webhook | 8 PostgreSQL WASM groups and 15 synthetic Node contract groups pass |
| Mutation PR / nightly | 12/12 and 20/20 assertion kills, no other outcomes |
| Nightly properties / quality / quickstart | 46 overlapping passes; Ruff, gradual strict mypy, pip check and isolated quickstart pass |
| Additional writer regressions | Four public-record cases fail against unmodified a14; all ten cases pass against unmodified a15 |
| Local secret scan | Gitleaks 8.24.3 reports zero findings on supplied plugin source and Git history through the a15 commit |

Repeated and supplementary checks overlap; these totals are not added together.
The reference suite's 23 skips remain skips. Raw logs remain private; redacted
outcomes and the failed a14 reproductions are retained under `executed/`.

## Recommended corrections

### 1. Distinguish generated files from archive permissions

The fix is real: both original a14 public writers produce 0600 files, regardless
of whether the process umask is 000 or 077. The a15 writers produce 0644 public
records and preserve 0600 private diagnostics. Replacement of an existing
restrictive file is covered too.

However, the delivered a14 complete ZIP, source ZIP and sdist already stored all
four relevant public records as **0644**. The a13 complete ZIP did retain a 0600
mutation record. Consequently, “every handoff since a7” and the blog's general
claim that the a14 archive was unreadable to another account overstate the
history. Describe the fix as correcting fresh working-tree records; distinguish
older archives that retained restrictive modes from a14's normalised archives.
See `archive-mode-comparison.json` and the before/after regression reports.

The real-Zabbix recorder's NOT_RUN branch also uses this writer. A live Zabbix
fixture was not necessary to reproduce its old 0600 mode. The writer tests in
this review use only synthetic JSON; they check permission bits and content,
not an actual second operating-system identity reading the file.

### 2. Match release claims to the actual contracts

The two profile-specific mutation reports are **optional when absent and
validated when present**. The review and alpha report describe both as required.
A disposable copy with just those two reports removed produced no findings from
`evidence_binding_findings`, confirming the current rule. The proposed wording
matches the implementation without changing or weakening that rule.

Also distinguish a15 service execution from inferred a14 behaviour. Runtime,
SQL and executable service-path code are unchanged apart from the package
version, which supports an inference about shared behaviour. It does not turn
a14's original NOT_RUN records into executions on that release.

The patch additionally corrects the “Still owner-only” heading to “Still pending”,
labels the two preserved historical owner-only records accurately, and removes
the claim that the verifier is stdlib-only: it imports PyYAML through the agent
validation helper, supplied by the reference dependency lock.

### 3. Keep the additional writer regressions

The two tests added by a15 cover the mutation writer and export-audit rule. The
ten separate review cases also exercise the real-Zabbix writer and the shared
review JSON writer, private/public modes, permissive/restrictive umasks and
replacement of an existing file. They passed without changing product source.
The reusable test file is included under `review-tests/` for future adoption.

`proposed/documentation-corrections.patch` applies cleanly to the extracted a15
complete packet (`git apply --check` executed). It is a review proposal, not a
rewrite of the delivered release. Apply changes in a future candidate and
regenerate that candidate's checksums/artifacts; do not patch signed or retained
historical artifacts in place. The proposed patch changes documentation and
static copy only; the extra tests remain separate from the supplied harness.

## Supplied service evidence

The supplied native JSON and five JUnit reports reconcile to **42 passes**;
real-Zabbix JSON and JUnit reconcile to **6 passes** on 7.0.10. The deployment
record validates its **4 passes and 13 observations** and identifies the same
installed wheel reproduced here. All applicable source/harness bindings match
the a15 tree. These are inspections of supplied execution records, not fresh
service runs by this reviewer. Docker, QEMU and native service binaries were
unavailable here. No service success is inferred from the WASM tests.

G1–G8, A2, production account permissions, hosted workflows, signed attestation
and external security review remain open. No new advisory query, service
installation, live website update, remote push or production operation was
performed. The fresh local Gitleaks result is separate from the supplied a15
scanner record, which correctly remains NOT_RUN for its original environment.

See `RESULTS.json` for current review scope and `process-corrections.json` for
two review setup corrections. The supplied source and original ZIP bytes remain
unchanged. The full deployment and rollback instructions and consolidated input
register are inside the retained complete a15 release.
