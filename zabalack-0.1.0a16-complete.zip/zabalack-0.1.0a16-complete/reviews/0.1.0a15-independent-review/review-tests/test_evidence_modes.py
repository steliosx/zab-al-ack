"""Review regressions; select an unmodified checkout with ZABALACK_REVIEW_SOURCE.

Only synthetic JSON is written under pytest's temporary directory. No service,
fixture, token, network or candidate evidence is accessed by these tests.
"""
from __future__ import annotations

import importlib
import json
import os
from pathlib import Path
import stat
import sys

import pytest


@pytest.fixture
def source():
    root = Path(os.environ["ZABALACK_REVIEW_SOURCE"]).resolve()
    sys.path.insert(0, str(root / "tools"))
    sys.path.insert(0, str(root))
    return root


def module_from(root, name):
    module = importlib.import_module(name)
    assert Path(module.__file__).resolve() == root / "tools" / f"{name}.py"
    return module


@pytest.mark.parametrize("mask", [0o000, 0o077])
@pytest.mark.parametrize("writer", ["mutation", "real_zabbix"])
def test_public_record_is_readable_after_atomic_replace(source, tmp_path, mask, writer):
    module_name = "run_mutation_checks" if writer == "mutation" else "record_real_zabbix"
    module = module_from(source, module_name)
    write = module._atomic_json if writer == "mutation" else module.write_record
    target = tmp_path / "public.json"
    payload = {"status": "SYNTHETIC_REVIEW_RECORD"}
    previous = os.umask(mask)
    try:
        for existing_mode in (None, 0o600):
            if existing_mode is not None:
                target.chmod(existing_mode)
            write(target, payload)
            assert json.loads(target.read_text()) == payload
            assert stat.S_IMODE(target.stat().st_mode) == 0o644
    finally:
        os.umask(previous)


@pytest.mark.parametrize("mask", [0o000, 0o077])
@pytest.mark.parametrize("writer", ["mutation", "review"])
def test_private_diagnostic_stays_private(source, tmp_path, mask, writer):
    module_name = "run_mutation_checks" if writer == "mutation" else "review_runs"
    module = module_from(source, module_name)
    write = module._atomic_json if writer == "mutation" else module.atomic_json
    target = tmp_path / "private.json"
    previous = os.umask(mask)
    try:
        write(target, {"kind": "synthetic private diagnostic"}, mode=0o600)
        assert stat.S_IMODE(target.stat().st_mode) == 0o600
    finally:
        os.umask(previous)


@pytest.mark.parametrize("mask", [0o000, 0o077])
def test_shared_writer_can_explicitly_publish(source, tmp_path, mask):
    module = module_from(source, "review_runs")
    previous = os.umask(mask)
    try:
        path = tmp_path / "explicit-public.json"
        module.atomic_json(path, {"kind": "synthetic public diagnostic"}, mode=0o644)
        assert stat.S_IMODE(path.stat().st_mode) == 0o644
    finally:
        os.umask(previous)
