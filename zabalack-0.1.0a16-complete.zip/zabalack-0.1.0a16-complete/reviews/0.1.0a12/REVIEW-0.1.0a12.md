# Review — Zab-al-ack 0.1.0a12 (2026-09-12)

Input: `zabalack-0.1.0a11-complete.zip` (SHA-256
`e8d206c4965fe3b7657a729fd34e48bc3601068f13cb2bc24e36728b3f339532`), the
illustrated-documentation candidate produced with another tool: commit
`79cf4fe7…` on my a10 candidate `e84ce39f…`. Reviewer environment: Ubuntu
24.04, Python 3.12.3, Node 22, source-built PostgreSQL 18.3 and PgBouncer
1.24.1, source-built Zabbix 7.0.10 (two instances) on PostgreSQL 16 + PHP 8.3,
headless Chromium (Playwright); no Docker daemon with registry access. Output:
this candidate, commit `af03590226cd2b7b2100e7293d62e975d5549e4e` on branch `candidate/0.1.0a12`.

## Verdict

Ready to push to a private repository as the twelfth alpha candidate. a11 is
internally consistent, its offline results reproduce exactly, and its
additions are what they claim to be: a capture tool that accepts no target or
credential, a walkthrough test that reuses the existing Alerta/WASM fixture
with a mocked source, and SVG figures generated from that execution. a11 could
not run the service suites or a browser. a12 ran both on the a11 code: 42
native, 5 real-Zabbix and the deployment lab's 4 cases from the installed
wheel, plus browser captures including a real Zabbix frontend screenshot of the
lab's acknowledged event. No product defect; no runtime change.

## The a11 packet, verified

| Check | Result |
|---|---|
| Outer `SHA256SUMS` (338), `plugin/RELEASE_SHA256SUMS` (292), `plugin/dist/SHA256SUMS` (4), history archive | All OK; `history/` archive is my a10 zip byte for byte (`da037fc2…`) |
| Bundle `zabalack-0.1.0a11.bundle`, branch `candidate/0.1.0a11` | `79cf4fe7…` → `e84ce39f…` (a10) → `92bac446…` (a9) → `aaadf491…` → `e9bc2448…` → a7 → a6 → a5; tree identical to `plugin/source` and the source ZIP |
| Wheel `2c006651…` | Rebuilt byte-identically from the restored clone; `tools/verify_release.py` PASS and `tools/public_audit.py` 286 files / 0 findings against the packet's `dist/` (sdist and source ZIP differ only when evidence is regenerated, as designed) |
| Reference suite in a fresh pinned environment | 808 passed, 22 skipped, 0 failed; digests equal the manifest (`b3171722…`/`671aa8f3…`) |
| Quality, SQL, webhook, quickstart, mutation PR/nightly, property nightly, `capture_docs.py` | PASS, 8, 15, PASS, 12/12 and 20/20, 46, PASS |
| a10→a11 diff read | Documentation, `tools/capture_docs.py`, `tests/alerta/test_docs_walkthrough.py`, `MANIFEST.in` (svg/html/png), reference phase addition, version metadata; runtime Python differs only in `__version__`; SQL unchanged |
| a11 claims | Figures labelled as output illustrations, not UI; browser capture NOT_RUN and services NOT_RUN — both stated plainly, both closed here |

## Service execution on the a11 code

| Suite | On the unmodified a11 tree | On the final a12 tree |
|---|---|---|
| Native PostgreSQL 18.3 + PgBouncer 1.24.1 (`tools/native_local.py`) | 41 passed (24/5/4/6/2) | **42 passed** (24/5/4/**7**/2): the walkthrough test added to the native `alerta` phase |
| Real Zabbix 7.0.10 (`tools/record_real_zabbix.py --run`) | 5 passed | **5 passed** |
| Deployment-path lab (`tools/run_deployment_e2e_local.py`, installed wheel) | 4 passed, 13/13 (a11 wheel `2c006651…`) | **4 passed, 13/13** (a12 wheel `685475df…`, the release artifact) |

## Changes in a12 (no runtime code)

1. `tools/native_ci.py`: `tests/alerta/test_docs_walkthrough.py` in the
   `alerta` phase, so the documented walkthrough runs on a real cluster too.
2. Browser captures (R16): headless-Chromium renders of the three transcript
   pages and the Zabbix 7.0.10 frontend event details of the deployment lab's
   acknowledged event (source fact, `[zabalack]` acknowledgement, update fact,
   human update, recovery fact). PNGs are in this packet's `visual-previews/`
   and on the website; the source tree stores no binaries (its export audit
   rejects them), and `docs/visuals/browser-captures.json` records the tool
   and hashes. The capture script is `verification/browser_capture.mjs`.
3. Regenerated figures and `walkthrough.json` on the final tree; visual guide
   section 4 and a browser-capture section; website and a12 blog post;
   changelog, ALPHA_REPORT, compatibility manifest, README; version 0.1.0a12.

Environmental notes, not repository faults: the Zabbix frontend needs an
`en_US.UTF-8` locale to render without a warning banner (generated here);
`/etc/hosts` aliases and reserved ports were restored after the a10 shutdown.

## Verified from the packaged zip

| Check | Result |
|---|---|
| Outer `SHA256SUMS`, `plugin/RELEASE_SHA256SUMS`, `plugin/dist/SHA256SUMS` | All OK (nested lists included) |
| Wheel `685475df…` `zabalack/` vs `src/zabalack/`; vs a11 only `__version__` differs | Byte-identical; identical across the two builds of this preparation and the deployment-lab runner wheel |
| Bundle restore, `tools/verify_release.py --dist ../dist`, `tools/public_audit.py` from the clone | Tree identical; PASS; PASS with every run record bound to the clone |
| Fresh venv from the clone: quality, fast suites, bare collection | See `verification/handoff-checks.json` |
| Identifier sweep of the whole handoff | No lab paths, token files, private keys, sandbox identifiers, personal names or e-mail addresses beyond synthetic `.invalid` fixtures and placeholder author identities; the canonical site URL is the only non-upstream host |
| Website | No `<script>`/forms; external links limited to the two upstream projects and one pinned Zabbix source link; 15 pages, 354 local references resolve; copy states a12 results |

## Residual observations (not blockers)

- No Alerta UI screenshot: the Alerta Web UI is a separate project the lab
  does not install.
- The Docker Compose forms of both labs and every hosted workflow remain
  unexecuted; local-process records say so.
- A2 transport remediation, production-like Zabbix behaviour, query plans at
  scale, licence review, external security review and G1–G8 remain owner items.
- Signed attestation has not been issued; local provenance is consistency only.
