# Review — Zab-al-ack 0.1.0a15 (2026-09-13)

Input: `zabalack-0.1.0a14-complete.zip` (SHA-256
`e59045a3e376dffd16c26a883506c24ab1f23bbd117073d3f4623a66d0f66751`), a
candidate built on my a13: commits `7de1839` → `95ccbca` → `c2b7fb58…` on
`a4ccf3a2…`. Reviewer environment: Ubuntu 24.04, Python 3.12.3, Node 22,
source-built PostgreSQL 18.3 + PgBouncer 1.24.1, source-built Zabbix 7.0.10
(two instances) on PostgreSQL 16 + PHP 8.3; no Docker daemon with registry
access. Output: this candidate, commit `14b8c72f34d93b16c102013a232a995d75f7a6eb` on branch
`candidate/0.1.0a15`.

## Verdict

a14 is sound and is kept as delivered: its agent guidance, three repository
skills, guidance fingerprint, retained review runs and separated mutation
profiles are well-built, honestly scoped and reproduce exactly. a15 executes the
three service suites a14 recorded as NOT_RUN, and fixes one defect that
verification exposed — published evidence records were shipping owner-only, in
two different tools, since a7 and a5 respectively. No runtime or SQL change.

## a14, verified

| Check | Result |
|---|---|
| Outer `SHA256SUMS` (464 entries), `plugin/dist/SHA256SUMS` (4) | All OK |
| Retained `previous-release/zabalack-0.1.0a13-complete.zip` | `bfb06eca…` — byte-identical to my a13 deliverable |
| Bundle, branch `candidate/0.1.0a14` | `c2b7fb58…` → `95ccbca` → `7de1839` → `a4ccf3a2…` (my a13); tree identical to `plugin/source` |
| Wheel `e0c27cdf…`, sdist, source ZIP | `tools/verify_release.py` PASS; `tools/public_audit.py` 301 files / 0 findings |
| Reference, SQL, webhook, mutation PR/nightly, property, quality, quickstart, capture in a fresh pinned environment | 853/23/0 (824 unit + 29 WASM), 8, 15, 12/12 and 20/20, 46, PASS, PASS, PASS |
| a13→a14 diff | Release tooling, tests, docs, version metadata; **no** `src/` change beyond the version string, no SQL, no service-path file under `lab/` or `tests/` |
| New controls read | `agent_guidance.inspect` validates skill frontmatter, name/description bounds and curated internal links, and fingerprints 16 files outside the code digests; `review_runs` gives private per-attempt directories, symlink/traversal refusal and a non-blocking `flock`; `run_review` runs phases serially, snapshots only changed evidence and distinguishes INTERRUPTED from FAIL; PR and nightly mutation records are now separate and both required by the audit |

## Finding: published evidence shipped owner-only (R20)

`tempfile.mkstemp` creates its file 0600 and `os.replace` preserves that mode,
so a record written through that pair is published owner-only. Observed here:

| Observation | Result |
|---|---|
| `evidence/*.json` modes on a14's tree after a fresh run | all 0644 except the three mutation records, which are 0600 |
| An unprivileged account reading them | `quality-run.json` readable; `mutation-pr-run.json` **permission denied** |
| The delivered a13 archive | carries `plugin/source/evidence/mutation-run.json` at 0600 inside the zip |
| Origin | a7 (`67f8454`), where the mutation runner was added; shipped in every handoff since, including my own a12 and a13 |
| a14's contribution | enlarged it from one record to three, two of them now required by the export audit |

The fix names the intended mode at each writer, and — because patching one call
site would leave the next writer free to repeat it — adds
`public_audit.export_mode_findings`, which reports any exported file that is not
readable to group and other. That rule immediately found a **second** instance
in a different tool: `tools/record_real_zabbix.py` had published
`evidence/real-zabbix-run.json` 0600 since a5, invisible until a candidate could
actually run the suite. All four temporary-file writers in the repository are
now explicit about the mode they intend, and both public records are produced
0644 by a fresh run, not by a `chmod`.

## Executed on the final tree

| Suite | Result |
|---|---|
| Reference | **855 passed / 23 skipped / 0 failed** (826 unit/mock/property/offline + 29 WASM; 878 collected, all selected) |
| Native PostgreSQL 18.3 + PgBouncer 1.24.1 | **42 passed** (`postgres` 24, `delivery_faults` 5, `worker` 4, `alerta` 7, `performance` 2); cleanup exit 0 per phase |
| Real Zabbix 7.0.10 through `tools/record_real_zabbix.py --run` | **6 passed**, including the A4 excluded-action denial |
| Deployment-path lab from the installed a15 wheel | **4 passed, 13/13 observations** |
| Quality, SQL, webhook, quickstart, property, mutation, capture | PASS, 8, 15, PASS, 46, 12/12 and 20/20, PASS |
| pip-audit / npm audit / export audit / wheel smoke / SBOM / release verifier | 58 packages 0 advisories / 0 / 0 findings / PASS / CycloneDX 1.6 61 components / PASS |

a14 changed no service-path file, so the three service runs describe its code as
well as this candidate's.

## Verified from the packaged zip

| Check | Result |
|---|---|
| Outer `SHA256SUMS`, `plugin/RELEASE_SHA256SUMS`, `plugin/dist/SHA256SUMS` | All OK (nested lists included) |
| Every exported file's mode | Readable to group and other; no owner-only record in the handoff |
| Wheel `zabalack/` vs `src/zabalack/`; vs a14 | Byte-identical to the source; differs from a14 only in `__version__`; identical across two builds and to the deployment-lab runner wheel |
| Bundle restore, `verify_release.py --dist ../dist`, `public_audit.py` from the clone | Tree identical; PASS; PASS with every run record bound to the clone |
| Fresh venv from the clone: quality, fast suites, bare collection | See `verification/handoff-checks.json` |
| Identifier sweep | No tokens, private keys, personal names or e-mail addresses beyond synthetic `.invalid` fixtures, schema examples and placeholder author identities |
| Website | No scripts or forms; 18 pages, 421 local references resolve; copy states a15 results |

## Residual observations (not blockers)

- The quality gate runs `ruff check src`; `tools/` and `tests/` carry four
  pre-existing style findings outside that scope. Documented as gradual, not a
  regression, and untouched here.
- a14's qualitative agent evaluations are retained as received. They are
  forward-tests, not benchmarks, and packaging skill files does not establish
  that any host discovers them — a14 says so itself.
- G5 still requires effective-role read-back and permission tests on the
  approved installed account (A4). A2, the Docker Compose forms, hosted
  workflows, CodeQL, Gitleaks, the signed attestation, an Alerta Web UI capture
  and external security review remain open. No in-place Ackline upgrade exists.
