# Review — Zab-al-ack 0.1.0a10 (2026-09-12)

Input: `zabalack-0.1.0a9-complete.zip` (SHA-256
`e065fd6664d82c258786d48aba9cc529919e8f948cf623237e26e3093d645dfc`), the
rename candidate produced with another tool: commit `92bac446…` on the
reviewed a8 parent `aaadf491…` (an independent a8 review commit on my a8
candidate `e9bc2448…`). Reviewer environment: Ubuntu 24.04, Python 3.12.3,
Node 22, source-built PostgreSQL 18.3 and PgBouncer 1.24.1, source-built
Zabbix 7.0.10 (two instances) on PostgreSQL 16 + PHP 8.3; no Docker daemon
with registry access. Output: this candidate, commit `e84ce39f58f7418f29e4a75dc331ea1ecd206646` on
branch `candidate/0.1.0a10`.

## Verdict

Ready to push to a private repository as the tenth alpha candidate. The a9
rename is complete, internally consistent and reproduces exactly. Its service
suites, which a9 recorded as NOT_RUN, pass on the renamed namespace on real
services: 41 native, 5 real-Zabbix and the deployment lab's 4 cases from the
installed wheel. No product defect was found. a10 adds no runtime change; it
adds the non-Docker runners that make those runs repeatable, which closes the
independent a8 review's F2 (editable install, missing bootstrap/recorder).

## The a9 packet, verified

| Check | Result |
|---|---|
| Outer `SHA256SUMS` (307 entries), `plugin/dist/SHA256SUMS` (4), history archive hash | All OK; `history/` archive equals the manifest's `historical_archive_sha256` |
| Bundle `zabalack-0.1.0a9.bundle`, branch `candidate/0.1.0a9` | `92bac446…` → `aaadf491…` (a8 independent review) → `e9bc2448…` (my a8) → a7 → a6 → a5; tree identical to `plugin/source` and the source ZIP |
| Wheel `84e6c42b…`, sdist `008a302e…`, source ZIP `24a47be2…` | Rebuilt byte-identically from the restored clone (`tools/build_release.py`); wheel `zabalack/` equals `src/zabalack/`; `tools/verify_release.py` PASS; `tools/public_audit.py` 271 files, 0 findings |
| Reference suite in a fresh pinned environment | 796 passed, 22 skipped, 0 failed; digests equal the manifest (`69c13347…`/`08cfa51a…`) |
| Quality, SQL, webhook, quickstart, mutation PR and nightly | PASS, 8 groups, 15 groups, PASS, 12/12 and 20/20 |
| Rename completeness | Every remaining `ackline` string is a deliberate legacy reference (schema guards, proof rejection/redaction, echo recognition, transition docs, tests). A mechanically renamed a8-reviewed tree differs from a9 only in those guards, the build epoch and version metadata; no other behavioural change |
| a8 independent review (in `history/`) | Its evidence validator (`tools/deployment_evidence.py`, 56 regressions) is in a9 and is what validated the a10 deployment record; its F2 is addressed in a10 |

## Service execution on the renamed namespace

All three suites first ran on the unmodified a9 tree (same results), then on
the final a10 tree through the runners a10 adds; the packet carries the latter.

| Suite | Result on the final a10 tree |
|---|---|
| Native PostgreSQL 18.3 + PgBouncer 1.24.1 (`tools/native_local.py`, phase table imported from `tools/native_ci.py`) | 41 passed, 0 failed, 0 skipped (`postgres` 24 incl. the a9 legacy-schema guards, `delivery_faults` 5, `worker` 4, `alerta` 6, `performance` 2); cleanup exit 0 per phase; `tree_unchanged` true |
| Real Zabbix 7.0.10 (`tools/record_real_zabbix.py --run`) | 5 passed; observed version 7.0.10; `[zabalack]` acknowledgement comments read back from the disposable instance |
| Deployment-path lab (`tools/run_deployment_e2e_local.py`, unmodified `lab/deployment_e2e_runtime.py`) | 4 passed, 13/13 observations; runner environment with the a10 wheel `f25df5fe…` installed non-editably, installed bytes verified against the wheel; the same wheel is the release artifact |

## Changes in a10 (no runtime code)

1. `tools/native_local.py` and `tools/run_deployment_e2e_local.py` — the
   non-Docker forms of the two Compose runners (R14, `docs/local-services.md`);
   records carry `not_docker: true`, service identities and, for the deployment
   lab, the wheel SHA-256; NOT_RUN with a reason when inputs are absent.
2. `tools/run_property_nightly.py` — execution-owned recorder for the nightly
   generated profile (`evidence/property-nightly-run.json`, previously written by
   an external script).
3. Eleven offline regressions (`tests/release/test_local_service_runners.py`).
4. Documentation: R14, `docs/local-services.md`, ALPHA_REPORT, README rows,
   compatibility manifest, deployment-e2e / native / stateful docs, BETA_READINESS,
   CHANGELOG; version 0.1.0a10.

Environmental notes, not repository faults: the sandbox's `/etc/hosts` aliases
and reserved ports do not survive a container restart; `php` now resolves to
8.4 without bcmath, so the frontends run under `php8.3`; `zabbix_server` must
run with a clean environment (libcurl honours `HTTPS_PROXY`).

## Verified from the packaged zip

| Check | Result |
|---|---|
| Outer `SHA256SUMS`, `plugin/RELEASE_SHA256SUMS`, `plugin/dist/SHA256SUMS` | All OK (nested lists included) |
| Wheel `f25df5fe…` `zabalack/` vs `src/zabalack/`; vs a9 only `__version__` differs | Byte-identical; identical across the two builds of this preparation and the deployment-lab runner wheel |
| Bundle restore, `tools/verify_release.py --dist ../dist`, `tools/public_audit.py` from the clone | Tree identical; PASS; PASS with every run record bound to the clone |
| Fresh venv from the clone: reference suite, new offline tests | See `verification/handoff-checks.json` |
| Identifier sweep of the whole handoff | No lab paths, token files, sandbox identifiers, personal names or e-mail addresses beyond the release-preparation placeholder and the author identities in earlier commits |
| Website | No `<script>`/forms; external links limited to the canonical URL and the two upstream projects plus the pinned Zabbix source link; local links resolve; copy states a10 results |

## Residual observations (not blockers)

- The Docker Compose forms of both labs and every hosted workflow remain
  unexecuted; local-process records say so.
- A2 transport remediation, media/notification behaviour on a production-like
  Zabbix, query plans at scale, licence review, external security review and
  G1–G8 remain owner items (`docs/BETA_READINESS.md`).
- No in-place Ackline → Zab-al-ack upgrade exists (`docs/RENAME.md`).
- Signed attestation has not been issued; local provenance is consistency only.
