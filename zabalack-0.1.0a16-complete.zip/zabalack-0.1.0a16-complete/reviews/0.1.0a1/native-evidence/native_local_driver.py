#!/usr/bin/env python3
"""Local-cluster equivalent of tools/native_ci.py (Docker unavailable here).

Same phases, same targets, same ACK_TEST_* environment, fresh cluster per phase,
JUnit redaction through the release's own tools/evidence_utils. Differences from
native_ci.py: PostgreSQL 18.3 + PgBouncer 1.24.1 built from verified source and
run as `nobody` on loopback instead of Compose containers.
"""
import json, os, shutil, signal, socket, subprocess, sys, time
from datetime import datetime, timezone
from pathlib import Path

REPO = Path('/var/tmp/ack/repo')
RUNTIME = Path('/var/tmp/ack/runtime')
PGB_DIR = Path('/var/tmp/ack/pgb')
VENV_PY = sys.executable
sys.path.insert(0, str(REPO / 'tools'))
from evidence_utils import redact_junit, cases  # noqa: E402

PHASES = {
    'postgres': ['tests/postgres/test_postgres.py', 'tests/postgres/test_native_login.py'],
    'worker': ['tests/postgres/test_worker_path.py'],
    'alerta': ['tests/alerta/test_postgres_http.py', 'tests/alerta/test_health_postgres.py'],
    'performance': ['tests/performance/test_reference_batches.py'],
}
PSQL = RUNTIME / 'pg18/bin/psql'


def sh(cmd, **kw):
    return subprocess.run(cmd, text=True, capture_output=True, cwd=REPO, **kw)


def wait_port(port, timeout=30):
    end = time.time() + timeout
    while time.time() < end:
        with socket.socket() as s:
            s.settimeout(0.5)
            if s.connect_ex(('127.0.0.1', port)) == 0:
                return True
        time.sleep(0.3)
    return False


def cluster_start():
    sh([VENV_PY, 'lab/local_runtime.py', 'stop', '--isolated-lab'])
    shutil.rmtree(REPO / '.lab', ignore_errors=True)
    r = sh([VENV_PY, 'lab/local_runtime.py', 'start', '--isolated-lab'])
    if r.returncode:
        raise RuntimeError(r.stdout + r.stderr)
    assert wait_port(55432)


def cluster_stop():
    sh([VENV_PY, 'lab/local_runtime.py', 'stop', '--isolated-lab'])


def port_free(port):
    with socket.socket() as s:
        s.settimeout(0.5)
        return s.connect_ex(('127.0.0.1', port)) != 0


def pgbouncer_start():
    PGB_DIR.mkdir(exist_ok=True)
    assert port_free(56432), 'port 56432 already in use before start'
    for stale in (PGB_DIR / 'pgbouncer.pid', PGB_DIR / '.s.PGSQL.56432'):
        stale.unlink(missing_ok=True)
    ini = (REPO / 'lab/pgbouncer.ini').read_text()
    ini = (ini.replace('host=postgres port=5432 dbname=alerta', 'host=127.0.0.1 port=55432 dbname=postgres')
              .replace('listen_addr = 0.0.0.0', 'listen_addr = 127.0.0.1')
              .replace('listen_port = 6432', 'listen_port = 56432')
              .replace('auth_file = /etc/pgbouncer/users.txt', f'auth_file = {PGB_DIR}/users.txt')
              .replace('unix_socket_dir = /tmp', f'unix_socket_dir = {PGB_DIR}')
              .replace('pidfile = /tmp/pgbouncer.pid', f'pidfile = {PGB_DIR}/pgbouncer.pid'))
    (PGB_DIR / 'pgbouncer.ini').write_text(ini)
    shutil.copy(REPO / 'lab/pgbouncer_users.txt', PGB_DIR / 'users.txt')
    for p in (PGB_DIR, PGB_DIR / 'pgbouncer.ini', PGB_DIR / 'users.txt'):
        shutil.chown(p, 'nobody', 'nogroup')
    log = open(PGB_DIR / 'pgbouncer.log', 'a')
    proc = subprocess.Popen(['runuser', '-u', 'nobody', '--', str(RUNTIME / 'pgbouncer/bin/pgbouncer'),
                             str(PGB_DIR / 'pgbouncer.ini')], stdout=log, stderr=subprocess.STDOUT)
    assert wait_port(56432), 'pgbouncer did not listen'
    return proc


def pgbouncer_stop(proc):
    pidfile = PGB_DIR / 'pgbouncer.pid'
    try:
        os.kill(int(pidfile.read_text().strip()), signal.SIGINT)
    except (OSError, ValueError):
        proc.send_signal(signal.SIGINT)
    try:
        proc.wait(15)
    except subprocess.TimeoutExpired:
        proc.kill()
    end = time.time() + 15
    while not port_free(56432) and time.time() < end:
        time.sleep(0.3)
    assert port_free(56432), 'pgbouncer still listening after stop'


def main():
    evidence = REPO / 'evidence'
    raw = REPO / 'build/evidence-raw'
    raw.mkdir(parents=True, exist_ok=True)
    report = {'layer': 'native_postgres18_pgbouncer', 'status': 'NOT_RUN', 'phases': [],
              'real_zabbix': 'NOT_RUN', 'deployment_gates': 'MANUAL_GATE_PENDING',
              'runner': 'local source-built cluster (Docker unavailable); admin DSN dbname=postgres because tests hard-code database_name=postgres; see COWORK_TEST_REPORT.md'}
    for phase, targets in PHASES.items():
        started = datetime.now(timezone.utc).isoformat()
        result = {'phase': phase, 'exit_code': 1, 'status': 'FAIL', 'started_at': started}
        print(json.dumps({'phase': phase, 'layer': 'native_postgres18_pgbouncer'}), flush=True)
        pgb = None
        try:
            cluster_start()
            pgb = pgbouncer_start()
            env = {k: v for k, v in os.environ.items() if not k.startswith('ACK_TEST_')}
            env.update(ACK_TEST_ADMIN_DSN='postgresql://lab_admin@127.0.0.1:55432/postgres',
                       ACK_TEST_DESTRUCTIVE_LAB='YES_ISOLATED_LAB',
                       ACK_TEST_PGBOUNCER_DSN='postgresql://alerta_capture_probe@127.0.0.1:56432/alerta')
            raw_xml = raw / f'native-{phase}.xml'
            public_xml = evidence / raw_xml.name
            with (raw / f'native-{phase}.log').open('w') as log:
                code = subprocess.run([VENV_PY, '-m', 'pytest', *targets, '-q', '-rs', f'--junitxml={raw_xml}'],
                                      cwd=REPO, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=600).returncode
            result['exit_code'] = code
            if raw_xml.exists():
                redact_junit(raw_xml, public_xml, REPO)
                rows = cases(public_xml)
                result['counts'] = {s: sum(r['status'] == s for r in rows) for s in ('passed', 'failed', 'skipped')}
                result['skips'] = sorted({r.get('message', '') for r in rows if r['status'] == 'skipped'}) if rows and 'message' in rows[0] else None
                result['junit'] = str(public_xml.relative_to(REPO))
                if code == 0 and rows and all(r['status'] == 'passed' for r in rows):
                    result['status'] = 'PASS'
        except Exception as error:  # noqa: BLE001
            result['reason'] = f'{type(error).__name__}: {error}'[:500]
        finally:
            if pgb:
                pgbouncer_stop(pgb)
            cluster_stop()
        result['finished_at'] = datetime.now(timezone.utc).isoformat()
        report['phases'].append(result)
        print(json.dumps(result), flush=True)
        if result['status'] != 'PASS':
            break
    report['status'] = 'PASS' if len(report['phases']) == len(PHASES) and all(
        p['status'] == 'PASS' for p in report['phases']) else 'FAIL'
    (evidence / 'native-run.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'overall': report['status']}))
    return 0 if report['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
