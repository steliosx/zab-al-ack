# Independent review — Alerta Zabbix Ack 0.1.0a1 (2026-09-09)

Reviewer environment: Linux container, Python 3.12.3, no Docker, no native PostgreSQL 18. Scope: artifact integrity, public-export hygiene, licensing, CI definitions, SQL conformance to design baseline rev 1.2, and reproduction of the non-native test suites.

## Verdict

Code and packaging are clean enough to push to a GitHub repository. Not ready to be published as an open-source release until the ten publication inputs in `config/publication.pending.json` are recorded. Recommended path: push the bundle to a private repository, get CI green, complete the register, then make public and tag `v0.1.0a1`.

## Verified

| Check | Result |
|---|---|
| SHA-256 of release zip, wheel, alpha report, build provenance | Match `SHA256SUMS-0.1.0a1.txt` |
| Wheel `msp_alerta_ack/` vs source `src/msp_alerta_ack/` | Byte-identical |
| Public git bundle | One commit, placeholder author, 193 tracked files, `dist/` and `node_modules/` untracked |
| Site names, secret-manager names, emails, real IPs/hostnames, home paths, key material, `.env`, AI/chat markers | None found; only `example.invalid`, `192.0.2.1`, `REVIEWED-HOST` placeholders |
| Evidence JUnit files | No hostnames or local paths |
| Licensing | Apache-2.0, NOTICE, vendored Alerta schema attributed to commit `f4312727…`, THIRD_PARTY.md, SBOM, non-affiliation disclaimer |
| CI | Actions SHA-pinned, `permissions: contents: read`, `persist-credentials: false`, Dependabot present |
| SQL vs baseline rev 1.2 | `WHEN` predicate on new head `ack` entry (`IS DISTINCT FROM`, bounded marker match); cohort lookup inside `SECURITY DEFINER` function with pinned `search_path`; `msp_owner` column-level grants only, no `TRIGGER`; separate trigger installation script; break-glass `DISABLE TRIGGER`; capture-bypass flag; `REVOKE … FROM PUBLIC` |
| Non-native test suites (`tests/unit tests/security tests/release tests/alerta tests/rpc`) in a clean venv from `requirements.lock` | 181 passed, 6 skipped (native DSN not supplied) — matches ALPHA_REPORT |
| `tools/public_audit.py --publication` | Reports the same ten missing publication inputs |

## Blockers before public release (decisions, not code)

1. Publication register: `repository_url`, `package_owner`, primary/backup maintainers, private conduct contact, verified private vulnerability reporting, rights review, content review, PyPI namespace, upload authorisation. `SECURITY.md` and `CODE_OF_CONDUCT.md` have no contact; `pyproject.toml` has no `[project.urls]`.
2. Naming: project "Alerta Zabbix Ack", PyPI `msp-alerta-zabbix-ack`, module `msp_alerta_ack`, schema `msp`, roles `msp_owner`/`msp_worker`, proof marker `[msp-ack:v1`. Schema, role names and marker are persisted/signed formats; renaming after first publication is a breaking change. Confirm PyPI name availability and Zabbix/Alerta trademark guidelines for package naming.
3. Copyright holder "Alerta Zabbix Ack contributors", DCO, no CLA. Confirm the employer authorises release and holds the intended rights, including for `docs/DESIGN.md` and `docs/final_review_notes.md`.

## Recommended before first push (non-blocking)

- `native` CI job (Docker Compose) and `security.yml` (Go + Gitleaks) have never executed. Run in a private repo first or gate `native` on `workflow_dispatch` until green.
- Evidence files are committed to git and will go stale; release assets are the better home.
- Docs reference non-public artifacts ("private implementation packet", "final-review interpretations"); reword for public readers.
- `AGENTS.md` publishes the AI-agent development contract; publish deliberately.
- Prerelease notes must state: 12 native/real-source tests skipped, Gitleaks and hosted CI not run, external security review pending, G1–G8 open, no production use validated.

## Not verified

Native PostgreSQL 18 / PgBouncer suites, PGlite/WASM lab, real Zabbix fixture, Ansible/Compose execution, cross-platform reproducibility, legal review.
