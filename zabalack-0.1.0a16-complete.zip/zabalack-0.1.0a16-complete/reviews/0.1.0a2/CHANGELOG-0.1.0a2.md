# Alerta Zabbix Ack 0.1.0a2 — changelog and reasoning

Release zip `alerta-zabbix-ack-0.1.0a2-release.zip` SHA-256: `95d44df052995d431266e745069de5fdba8a72b00a6373437fe0d67ed3535d96`

Inside the zip, `RELEASE_SHA256SUMS` covers every file (207 entries) and `dist/SHA256SUMS` covers the wheel, sdist, source zip and build provenance.

## 0.1.0a2 — 2026-09-10

Second public alpha candidate, prepared locally and not yet published. Corrects
the findings of the first independent review of 0.1.0a1, which executed the
native PostgreSQL 18 / PgBouncer phases for the first time. Reasoning for each
change is in `docs/RELEASE_AMENDMENTS.md` R3.

### Fixed

- Native test phases could not pass against the lab database that
  `tools/native_ci.py` and `lab/compose.postgres.yml` create (`alerta`):
  `tests/postgres/test_worker_path.py` and
  `tests/performance/test_reference_batches.py` hard-coded the worker's expected
  `database_name` as `postgres`, so `Worker.check_health()` returned false and
  the `worker` and `performance` phases failed. The `pg_lab` fixture now yields
  the observed `current_database()` and both tests use it. Verified on a native
  PostgreSQL 18.3 cluster with database `alerta`: 20 passed, 0 failed, 0 skipped.
- `lab/local_runtime.py` could not start a cluster from a checkout path longer
  than about 90 characters ("Unix-domain socket path is too long"); the socket
  now lives in a short per-checkout directory under the system temp directory.

### Changed (SQL, corrected in place — no 0.1.0a1 installation exists)

- `sql/migrations/004_controls.sql`: `msp_worker` no longer receives direct
  `EXECUTE` on `msp.capture_health()`. The worker reads health through
  `msp.worker_call('doctor')` inside the `SECURITY DEFINER` boundary, so the grant
  was unused and wider than design baseline §12 ("claim, completion and
  projection functions only"). `alerta_capture_probe` and `msp_operator` keep
  their grants. `docs/sql_manifest.json` hashes updated.
- `sql/migrations/002_capture.sql`: when the reserved `[msp-ack:` prefix is
  present but the marker does not parse, `msp.captures.marker` is stored as
  `NULL` instead of up to 256 characters of the following text, which could
  include the operator's free-text note excluded by the §5.3/§12 capture
  allowlist. `diagnostic_reason = 'marker_malformed'` and all other columns are
  unchanged; T14 assertions are unaffected.

### Changed (evidence hygiene)

- `tools/evidence_utils.redact_junit` renders JUnit `timestamp` attributes in UTC;
  `tools/run_reference_suite.py` and `tools/native_ci.py` run pytest with
  `TZ=UTC`. Batch evidence records `platform.system()-platform.machine()`
  (`Linux-x86_64`) instead of the kernel/glibc build string. All committed
  evidence regenerated; the public Git bundle commit is dated in UTC.
- `tools/build_acceptance.py` accepts `--native-xml` (repeatable) and
  `tools/update_acceptance.py` passes every executed native phase recorded in
  `evidence/native-run.json`, so `docs/acceptance_matrix.csv` and
  `evidence/acceptance-results.*` show native PASS where a native check ran
  instead of a blanket `BLOCKED_ENVIRONMENT`.
- `evidence/native-*.xml` and `evidence/native-run.json` now contain executed
  results (PostgreSQL 18.3, PgBouncer 1.24.1, four phases, 20 cases).

### Changed (CI and supply chain)

- `.github/workflows/security.yml` installs pip-audit 2.9.0 and its 26
  transitive dependencies from the new `requirements-scanner.lock` with
  `--require-hashes` (hashes for the hosted `ubuntu-24.04` / CPython 3.12 runner;
  the pip-audit wheel hash equals `docs/scanner_reference_manifest.json`), builds
  Gitleaks from the commit recorded in `docs/gitleaks_reference_manifest.json`
  rather than a movable tag, and asserts `gitleaks version` is 8.24.3.
- `.github/workflows/ci.yml` and `release/publish.yml.example` run
  `python -m pip check` after installation to surface `pyproject.toml` /
  `requirements.lock` drift, since Dependabot tracks only the pyproject pins
  (`.github/dependabot.yml` documents this).
- `README.md` and `lab/README.md` use `npm ci … --ignore-scripts`, matching CI.
- `lab/build_postgres.sh` accepts PostgreSQL 18.3 in addition to the 18.0 pin,
  each verified against its published SHA-256, and derives the version from the
  archive name.

### Documentation

- `docs/DESIGN.md` §12 lists the `msp_operator` role and its rights.
- `docs/deployment.md` (G1) records that `005_readiness.sql` grants
  `capture_ack()`/`seal_installation()` to the observed `alerts` owner, so an
  application that connects as that owner can re-seal the readiness manifest;
  a dedicated installation principal is preferred.
- `docs/runbook.md` documents the fail-closed exceptions of `msp.capture_ack()`
  (missing `msp.installation` row or failed capture insert → acknowledgement
  rolled back, HTTP 500) and the repair path.
- `CONTRIBUTING.md` scopes the "never edit migrations" rule to tagged or applied
  migrations, and documents manual lock refresh and evidence regeneration.
- `lab/README.md` replaces the sandbox-specific paragraph with the actual
  runtime requirements (second OS identity, socket path, accepted 18.x archives).
- `docs/RELEASE_AMENDMENTS.md` R3 records every change above with its reason.

### Unchanged by decision (owner items, not defects)

- The ten publication inputs in `config/publication.pending.json`, `SECURITY.md`
  and `CODE_OF_CONDUCT.md` contacts, `[project.urls]`.
- `msp` schema, `msp_*` role and `[msp-ack:v1` marker names.
- Per-file licence headers; committed evidence remains in the repository.
- `requirements.lock` / `requirements-runtime.lock` stay version-pinned without
  `--hash` lines so they remain installable on developer platforms other than
  the CI runner.

### Not executed in this release preparation

- The Docker form of the native job (`tools/native_ci.py`) and the hosted
  `security.yml` (Gitleaks) — both need the private repository's first push.
- Real Zabbix fixture tests, Ansible/Compose execution, external security
  review, deployment gates G1–G8.


---

# Reasoning (docs/RELEASE_AMENDMENTS.md)

## R3 — 0.1.0a2 corrections from the independent native run

0.1.0a1 was never tagged, published, or installed anywhere; an independent
review executed the native PostgreSQL 18 / PgBouncer phases for the first time
(on a source-built 18.3 cluster) and found the items below. They are corrected
in place rather than by forward migration, following the usual pre-release rule
for schema migrations: a migration is immutable from the moment it has been
applied to a tracked installation or shipped in a tagged release, and neither
had happened. `sql/migrate.py` still refuses to rerun a changed file on any
installation that already recorded it, so an evaluator who applied 0.1.0a1 SQL
to a lab database must recreate that disposable database.

| Change | Reason |
|---|---|
| `tests/conftest.py` yields the observed `database_name`; `tests/postgres/test_worker_path.py` and `tests/performance/test_reference_batches.py` use it instead of the literal `postgres` | `tools/native_ci.py` and `lab/compose.postgres.yml` create database `alerta`; with the literal name `Worker.check_health()` compared `alerta` with `postgres` and the `worker` and `performance` phases failed 4/4 and 1/1. The hosted `native` job could not have passed. |
| `sql/migrations/004_controls.sql`: `msp_worker` no longer receives direct `EXECUTE` on `msp.capture_health()` | Design baseline §12 grants the worker claim/completion/projection functions only; the worker reads health through `msp.worker_call('doctor')`, which calls `capture_health()` inside the `SECURITY DEFINER` boundary, so the direct grant was unused and wider than the design. The probe (`alerta_capture_probe`) and `msp_operator` keep their grants. |
| `sql/migrations/002_capture.sql`: `marker` is stored as `NULL` when the reserved prefix is present but the marker does not parse | A well-formed marker is exactly the bounded proof string. A malformed one is up to 256 characters of whatever followed `[msp-ack:`, which can be the operator's free-text note that §5.3/§12 exclude from the capture record. The diagnostic reason (`marker_malformed`) and all other allowlisted columns are unchanged; T14 assertions count diagnostics, not marker bytes. |
| `tools/evidence_utils.py` renders JUnit `timestamp` attributes in UTC; `tools/run_reference_suite.py` and `tools/native_ci.py` set `TZ=UTC`; batch evidence records `platform.system()-platform.machine()` instead of `platform.platform()` | Committed 0.1.0a1 evidence carried a `+05:00` offset and the lab host's kernel/glibc string (also in `docs/compatibility_manifest.json` `build_environment`, now reduced to interpreter version and OS/CPU). Neither is secret, but both fingerprint the build environment in a public repository. |
| `lab/local_runtime.py` places the Unix socket in a short per-checkout temp directory | `unix_socket_directories` pointed at the checkout's `.lab` directory; paths over ~107 bytes made `postgres` refuse to start. |
| `lab/build_postgres.sh` accepts PostgreSQL 18.3 in addition to the 18.0 pin, each with its published SHA-256 | 18.0 is no longer mirrored by common package archives; 18.3 is the engine inside the pinned PGlite and was used for the native evidence in this release. |
| `.github/workflows/security.yml` installs pip-audit from `requirements-scanner.lock` with `--require-hashes` and builds Gitleaks from the commit recorded in `docs/gitleaks_reference_manifest.json`, then asserts `gitleaks version` | The scanner and its 26 transitive dependencies were previously version-pinned only; Gitleaks was tag-pinned. |
| `.github/workflows/ci.yml` and the publishing template run `python -m pip check` after installation | Dependabot tracks `pyproject.toml` pins but not the `*.lock` files; `pip check` surfaces pyproject/lock drift. |
| `README.md` and `lab/README.md` add `--ignore-scripts` to `npm ci` | Matches the CI invocation; the two lab packages do not need install scripts. |
| `docs/DESIGN.md` §12 lists `msp_operator`; `docs/deployment.md` records the installation-principal/runtime-role question under G1; `docs/runbook.md` documents the fail-closed capture exceptions; `CONTRIBUTING.md` scopes the migration-edit rule and documents lock/evidence refresh | Documentation gaps found by comparing the SQL with baseline §5.3, §5.7, §8 and §12. |

Naming (`msp` schema, `msp_*` roles, `[msp-ack:v1` marker), the ten publication
inputs, licence headers and moving committed evidence to release assets are
deliberately unchanged: they are owner decisions, not defects.
