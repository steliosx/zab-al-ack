# a2 verification and review corrections

The supplied a2 implementation reproduced successfully in the available reference
lab. The review found release-tooling defects and prepared an **unreleased review
patch**, with complete source and rebuilt artifacts. It does not replace, retag
or publish the supplied a2 release. No production access or changes occurred.

Base candidate: `a6bba3130b54d119056a942f7fb9f578af64c639`.
Review commit: `73d046b218afe2b883cc11e856ddbf668a822231`, on
`review/a2-corrections`, dated `2026-09-10T01:05:24+00:00`.
All application source and migration files are byte-identical to supplied a2.

## Corrections made

1. **Gitleaks CI would fail before scanning.** A bare commit-pinned `go install`
   leaves the version as `version is set by build process`; the new assertion
   requires `8.24.3`. The workflow now supplies the exact version linker symbol
   used by upstream and retains the commit pin and version assertion. Source
   inspected: [pinned version command](https://github.com/gitleaks/gitleaks/blob/107a41827bb6698dbbff756b2300537774a1d84c/cmd/version.go)
   and [pinned release build](https://github.com/gitleaks/gitleaks/blob/107a41827bb6698dbbff756b2300537774a1d84c/.goreleaser.yml).
   Workflow/manifest regression passed; actual Go/Gitleaks and hosted execution
   remain NOT_RUN here.
2. **Native passes were masked by duplicate skips.** The supplied matrix still
   marked T34 native/PgBouncer NOT_RUN, T35/T37/T38 native BLOCKED_ENVIRONMENT,
   and T39 native NOT_RUN despite their supplied native passes. Aggregation now
   resolves only the same test in the same evidence layer. Failures retain
   priority, other skipped tests remain skipped, and missing/failed selected
   native reports stop mapping. Re-aggregation of the supplied reports corrects
   those six cells; this is not fresh native execution or deployment acceptance.
3. **A failed runner could reuse old JUnit.** Both runners now remove their own
   previous phase reports before launching the child. The reference runner also
   rejects a successful process with no test report. Mocked crashes, timeouts and
   missing reports verify that stale passes are not counted. The UTC setting is
   preserved and tested; timestamp conversion does not invent a zone for naive
   timestamps.
4. **The nested source ZIP contained stale handoff metadata.** Its 198 source
   files matched the bundle, but three extra handoff files were included. The
   nested manifest named commit `e66f31c1c9ee86d8cc83d1d39737389fb574a31d`,
   while the final bundle used the base candidate above; its checksum list was
   also stale. Root handoff metadata is now excluded from source exports. The
   corrected source ZIP matches all 200 tracked files, including the new tests
   and review-status note.
5. **The lab no longer needs a Unix socket path.** All clients already use
   loopback TCP. Startup now sets `unix_socket_directories=''`, including a
   command-line override for a previously initialised, stopped lab cluster. This
   avoids both deep checkout/temporary paths and the predictable temporary
   directory ownership change. The supported empty setting was checked in the
   [pinned PostgreSQL configuration source](https://github.com/postgres/postgres/blob/3d6a828938a5fa0444275d3d2f67b64ec3199eb7/doc/src/sgml/config.sgml).
   Mocked tests cover deep paths, the root branch and preservation of existing
   data; actual native startup remains unexecuted because the environment lacks
   a usable second OS identity.
6. **SQL corrections have direct regression coverage.** T14 now checks that no
   malformed marker bytes or synthetic free-text sentinel enter a capture.
   T38 requires direct worker access to `capture_health()` to be denied while
   `worker_call('doctor')` still works. Both passed on the real PostgreSQL WASM
   engine; these additional assertions still need a native run.

The migration rationale was also narrowed: a1 had a local
`candidate/v0.1.0a1` tag and disposable test installations. No public release or
tracked operational installation has been reported. Applied a1 lab databases
must be recreated deliberately; an operational installation instead requires a
reviewed forward migration. Never rewrite its checksum ledger or discard its
data to accept a2. This review makes no further migration edits.

## Evidence and limits

| Check | Independently observed in this review | Scope |
|---|---|---|
| Supplied outer ZIP | 207 checksum entries matched; ZIP CRC and outer SHA-256 matched | Integrity, not authenticity or approval |
| Supplied Git bundle | 198 source files matched outer source; one UTC commit; no remote | Original candidate preserved |
| Unmodified a2 suite | **193 passed, 12 skipped, 0 failed** | 181 unit/mocked + 12 PostgreSQL WASM checks |
| Corrected review suite | **214 passed, 12 skipped, 0 failed** | 202 unit/mocked + 12 PostgreSQL WASM checks; includes 21 new release regressions |
| SQL groups | 7 passed before and after corrections | Actual Alerta composite schema, PostgreSQL SQL/roles via SET ROLE; not native role authentication |
| Synthetic webhook groups | 12 passed | Node contract fixtures, not real Zabbix macro/API evidence |
| Isolated quickstart | Exit 0 | Actual Alerta HTTP/persistence and PostgreSQL WASM, mocked source; repeated tests excluded from totals |
| Dependency consistency | `pip check` exit 0 | Exact reference lock installed from local wheels |
| Package build | Wheel, normalized sdist and source ZIP each twice byte-identical | Final build succeeded; wheel also matches the supplied a2 wheel |
| Targeted export audit | Zero findings; ten publication inputs pending | Common-secret/inert-default checks, not Gitleaks or legal clearance |
| Native PostgreSQL/PgBouncer | **NOT_RUN here** | Supplied a2 reports contain 20 passes; inspected and separately attributed |
| Hosted CI, Gitleaks, real Zabbix, Ansible, external security review | **NOT_RUN/PENDING here** | No claim of execution or approval |

The twelve reference skips are eight native-only checks and four real-Zabbix
checks. The supplied native results cover the original a2 tests, not the new
native SQL assertions. All G1–G8 deployment gates remain open. The supplied
pip-audit 50/0 and npm-audit 0 results were not rerun in this review; dependency
locks were unchanged.

One initial packaging attempt stopped when a transient workspace-copy file
disappeared during source enumeration. After the workspace settled, the final
build completed and all three reproducibility comparisons passed. That failed
attempt is recorded separately in `review-evidence/artifact-verification.json`.

`source/ALPHA_REPORT.md` and `source/evidence/` retain the supplied a2's historical
records. Fresh baseline and corrected review results are separately under
`review-evidence/baseline/` and `review-evidence/corrected/`. The remapped supplied
native matrix is explicitly labelled as supplied evidence. The review packet
contains no raw operational logs or credentials.

## Artifacts and commands

The packet contains `source/`, `dist/` (wheel, sdist, source ZIP, build provenance
and review Git bundle), the patch, fresh review evidence and `REVIEW_SHA256SUMS`.
The source ZIP and sdist contain review changes under version `0.1.0a2`; they are
review artifacts, not a new published release. The wheel is unchanged:

```text
1f904f871cd2e769c79ab59b8732e1085f3bfcf928d9f4add1170c04d4ebd1a7  msp_alerta_zabbix_ack-0.1.0a2-py3-none-any.whl
```

Supplied a2 outer ZIP SHA-256:
`95d44df052995d431266e745069de5fdba8a72b00a6373437fe0d67ed3535d96`.
Fresh packet/artifact hashes are in `SHA256SUMS-a2-review.txt`.

Restore the review branch from the packet root:

```bash
sha256sum -c REVIEW_SHA256SUMS
git clone --branch review/a2-corrections dist/alerta-zabbix-ack-a2-review.git.bundle restored-review
cd restored-review
git remote remove origin
```

Or apply the patch in a clean checkout of the exact base candidate:

```bash
git apply --check /path/to/alerta-zabbix-ack-0.1.0a2-review.patch
git apply /path/to/alerta-zabbix-ack-0.1.0a2-review.patch
```

Reference commands, with no inherited live fixture, are:

```bash
python -m venv .venv
.venv/bin/python -m pip install -r requirements.lock
.venv/bin/python -m pip install --no-deps --no-build-isolation -e .
.venv/bin/python -m pip check
npm ci --prefix lab --legacy-peer-deps --ignore-scripts --no-audit --no-fund
.venv/bin/python tools/run_reference_suite.py --wasm
node lab/pglite_checks.mjs --isolated-lab
node zabbix/v1/test_webhook.cjs
.venv/bin/python tools/public_audit.py
.venv/bin/python tools/build_release.py
```

Use `tools/native_ci.py --isolated-lab` on an authorised development host with
local Docker Compose. That does not require a GitHub push. Hosted workflow
execution does require a repository destination and separately authorised push.
Before public release, rerun those jobs against the reviewed commit, regenerate
evidence deliberately, review the resulting artifacts and select the release
version/tag. No public tag or publication is created by this packet.

To undo an applied review patch in a clean development checkout, check and apply
`git apply --reverse` to the same patch. This affects source files only. For an
installed integration, retain the existing ordered hold/rollback procedure in
`source/docs/rollback.md`; the review adds no SQL rollback, ledger deletion,
source unacknowledgement or automatic service action.

## Inputs still required

The consolidated deployment register remains `source/docs/INPUTS_REQUIRED.md`:
installed versions/routing/ownership; real redacted Zabbix media, payload and
update-operation evidence; tenant permissions and approved pilot cohorts;
staging/deployment and protected secret references; measured native, pooling,
HA and batch acceptance; named operators/responders; records policy; and the
approved enablement/change record. No live credentials are requested in chat.

The same ten publication inputs remain pending in
`source/config/publication.pending.json`: repository URL, package owner, primary
and backup maintainers, private conduct contact, verified private security
reporting, copyright/third-party approval, public-content approval, confirmed
PyPI namespace, and explicit publication authorization. No new owner identity,
remote destination or approval has been invented.
