# Zab-al-ack a15 website update

- Base: the a13 site, which a14 deliberately preserved byte-for-byte.
- Homepage, documentation and alpha brief now state the a15 results: 855
  reference passes, 42 native cases, six real Zabbix 7.0.10 contract cases and
  the installed-wheel pipeline's four tests with 13 observations, plus a14's
  guidance additions and the a15 export-mode correction.
- Added the a15 article ("The evidence file nobody else could read"); fourteen
  earlier articles, including the independent reviewer's own, are unchanged.
- No scripts, forms, trackers, credentials or plugin downloads; 18 pages, 421
  local references and fragments checked; three pages screenshotted at 1280 px
  (not a full visual QA). Nothing was published by this handoff.

---

# Zab-al-ack a13 website update

- Base: the independent reviewer's published a12 site, including its
  "Testing the integration against Zabbix 7.0.30" article, which is kept as its
  own record.
- Homepage, documentation and alpha brief now state the a13 results: 820
  reference passes, 42 native cases, six real Zabbix 7.0.10 contract cases
  (including the new excluded-action denial) and the installed-wheel pipeline's
  four tests with 13 observations. The review's 7.0.30 and supplemental API
  layers are described as the review's evidence, not restated as a13 results.
- Added the a13 article ("What a review is for"); thirteen earlier articles are
  unchanged.
- No scripts, forms, trackers, credentials or plugin downloads; 17 pages, 402
  local references and fragments checked; three pages screenshotted at 1280 px
  (not a full visual QA). This copy is a local update of the published site;
  nothing was published by this handoff.

---

# Zab-al-ack a12 website update

- Homepage, documentation and alpha brief state the a12 results: 808 reference
  passes, 42 native cases, five real Zabbix cases and the deployment lab's four
  cases from the installed wheel; the "historical a10 / not rerun for a11"
  wording is gone.
- The illustrated workflow uses the a12-generated SVG figures
  (`assets/visuals/a12/`) and gains a fourth view: a real Zabbix 7.0.10
  frontend screenshot of the deployment lab's acknowledged event, with browser
  renders of the three transcript pages beside the SVGs. The a11 figures stay
  in place for the a11 article.
- Added the a12 release article and its index entry; eleven earlier articles
  are unchanged.
- No scripts, forms, trackers, credentials or plugin downloads; 15 pages, 354
  local references and fragments checked; three pages screenshotted at 1280 px
  (not a full visual QA). This copy is a local update of the published site;
  nothing was published by this handoff.

---

# Zab-al-ack a10 website update

- Homepage, documentation and alpha brief now state the a10 results: 807
  reference passes, 41 native PostgreSQL/PgBouncer cases, five real Zabbix
  cases and the deployment lab's four cases from the installed wheel, all on
  local services and labelled as such; Compose forms and G1–G8 remain open.
- Documentation names the non-Docker runners (`tools/native_local.py`,
  `tools/run_deployment_e2e_local.py`) beside the Compose commands and points
  to `docs/local-services.md`; upgrade table rows 4 and 6 reflect execution.
- Added the a10 release article and its index entry; nine earlier articles are
  unchanged.
- No scripts, forms, trackers, credentials or plugin downloads; local links and
  fragments checked; three pages screenshotted at 1280 px (not a full visual QA).
  This copy is a local update of the published a9 site; nothing was published.

---

# Zab-al-ack a9 website rename

- Renamed current branding, metadata, public URLs, wordmark, icon title, asset
  filename and brief; kept the existing Alerta-inspired mark and visual theme.
- Updated practical commands, Alerta entry points, schema/service names and
  current evidence to the renamed a9 source.
- Added a9 release article and transition guidance. Preserved eight Ackline
  articles as historical records, with a clear note on each.
- Explained the fresh namespace, legacy-installation guard, proof rejection,
  privacy compatibility, retained evidence and outstanding deployment checks.
- Allowed the longer wordmark to wrap safely with the header at narrow widths.
- Static site remains informational, with no scripts, forms or plugin downloads.

Validation records and publication details are included in the complete a9
handoff. Browser visual QA was not executed for this update.

---

# Website update — a8 blog and independent review

- Added the supplied blog index and eight release notes, preserving the existing
  site branding and static architecture.
- Narrowed the a1 delivery wording: bounded acknowledgement is not an exactly-once
  guarantee. Renamed the a5 post so a source digest is not presented as proof of
  truthful authorship. Corrected the a2 index summary: one grant and one diagnostic
  retention change, rather than two grants.
- Updated the a8 article with the cause-macro fix, an exact upstream source link,
  the independent evidence-validation finding and its 56 regression cases.
- Distinguished original service reports from the independent review's 781/22/0
  reference result. Described the editable-install/local-bootstrap gap explicitly.
- Updated the homepage, technical evidence table and downloadable brief; removed
  stale a7 evidence labels. Practical SQL validation now uses the execution-owned
  runner. Added the A3 media-artifact note beside deployment guidance.
- Added the necessary blog heading and metadata styles and kept all pages free of
  scripts, forms, trackers, credentials and plugin release downloads.

Validation: content checked against original a8 and the independent review;
static entrypoints, local links/fragments, metadata and inert configuration
examples checked before publishing. Browser visual QA not executed. Plugin
runtime, SQL, package artifacts and recorded tests are unchanged by this update.
