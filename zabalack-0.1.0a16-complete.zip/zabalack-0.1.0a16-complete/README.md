# Zab-al-ack 0.1.0a16 — complete handoff

One archive: the 0.1.0a16 plugin candidate with built artifacts, the matching
static website, the review of this candidate, and the review history of every
earlier candidate (a1–a15, including all three independent reviews as received).
Start with `plugin/START_HERE.md`.

| Location | Contents |
|---|---|
| `plugin/source/` | Complete source tree of the candidate (plugins, SQL, worker, CLI, labs, tests, tooling, agent guidance, documentation, digest-bound evidence). |
| `plugin/dist/` | Wheel `zabalack-0.1.0a16-py3-none-any.whl`, normalized sdist, source ZIP, build provenance, `SHA256SUMS`, and the Git bundle `zabalack-0.1.0a16.bundle` (branch `candidate/0.1.0a16`, lineage a5 → … → a14 → a15 → a16). |
| `plugin/REVIEW-0.1.0a16.md` | What was verified in the independent a15 review, how each of its corrections was reproduced before adoption, what was executed here, and what remains open. |
| `plugin/CHANGELOG-0.1.0a16.md`, `plugin/source/CHANGELOG.md` | This candidate's changes; the cumulative changelog. |
| `plugin/source/docs/RELEASE_AMENDMENTS.md` R21 | The a15 review verified and adopted: what each correction was, how it was reproduced, and what was deliberately not restated as this candidate's evidence. R20 above it carries the corrected account of the evidence-mode defect. |
| `plugin/a15-to-a16.diff` | Source diff from the a15 candidate (evidence and the Node lock excluded). |
| `plugin/RELEASE_MANIFEST.json`, `RELEASE_VERIFICATION.json`, `RELEASE_SHA256SUMS` | Candidate identity and digests; unsigned release-consistency verification; checksums of every file under `plugin/` including nested lists. |
| `reviews/0.1.0a15-independent-review/` | The review packet as received: its report, results, reproduction notes, rebuilt artifacts, proposed patch, its ten writer regressions and its executed evidence. Its copy of the a15 archive is omitted because `reviews/0.1.0a15` and this candidate's lineage already carry it. |
| `reviews/0.1.0a16/` | This review and `a15-review-verification.json`, the record of reproducing each claim before adopting it. |
| `reviews/0.1.0a1` … `0.1.0a15`, `0.1.0a8-independent-review`, `0.1.0a12-independent-review` | Earlier reviews, independent reviews, packets as received, patches and reproduction records. |
| `visual-previews/`, `verification/browser_capture.mjs` | The a12 browser captures and the script that took them. Nothing was recaptured for a16. |
| `verification/archive-modes.json` | The measured stored mode of the published evidence records in every delivered handoff — the evidence behind R20's corrected history. |
| `website/`, `website-notes/` | Static site (no JavaScript) with copy updated for a16, a sixteenth blog post and a correction on the a15 post; site changelog. Nothing was published by this handoff. |
| `verification/` | Checks performed on this combined archive and on the website copy. |
| `SHA256SUMS` | SHA-256 of every file in this archive except itself, nested checksum lists included. |

Verify: `sha256sum -c SHA256SUMS`, then `cd plugin && sha256sum -c RELEASE_SHA256SUMS`.

Two files in this archive are not readable to group and other:
`reviews/0.1.0a7/plugin/evidence-a7/mutation-run.json` and `real-zabbix-run.json`,
retained exactly as received and the original instances of the defect R20
corrected. Everything this candidate produces is 0644.

Status in one line: sixteenth public alpha candidate; the independent review of
a15 verified — its retained a15 archive byte-identical to the delivered one, its
rebuilt artifacts matching, its offline results matching mine — and adopted in
full: ten writer regressions covering both public writers, both private writers
and both umasks, and five precise corrections to release prose (what the
evidence-mode defect actually reached, that the profile mutation records are
optional when absent, that a service run belongs to the candidate that ran it,
that the release verifier needs PyYAML, and that two owner-only records do remain
in the handoff); no runtime or SQL change; all suites re-executed here (reference
865/23/0, native 42, real Zabbix 7.0.10 6, deployment-path lab 4 with 13/13
observations from the installed wheel); A2, the Docker Compose forms, hosted
workflows, Gitleaks, attestation, an Alerta UI capture, G5's effective-role
evidence, external security review and the publication inputs remain open;
production gates G1–G8 are per deployment. Nothing here authorises production
access or a public release.
