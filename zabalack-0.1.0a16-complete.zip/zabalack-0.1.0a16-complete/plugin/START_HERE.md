# Zab-al-ack 0.1.0a16 candidate

Read REVIEW-0.1.0a16.md and source/ALPHA_REPORT.md first. This is a local alpha;
hosted results and all deployment gates remain explicitly limited.

From this packet root, verify every file (including nested checksum lists):

```bash
sha256sum -c RELEASE_SHA256SUMS
```

Restore the exact local repository from its bundle, selecting its branch:

```bash
git clone --branch candidate/0.1.0a16 dist/zabalack-0.1.0a16.bundle restored
cd restored
```

The checkout equals `source/` and the source ZIP; its history is the a5 → a6 →
a7 → … → a13 → a14 → a15 → a16 lineage with no configured hosted remote. No tag
or public upload was performed.

Use Python 3.12 and the commands in README.md / docs/RELEASING.md. Install the
reference lock, hash-pinned quality lock and editable project. For the WASM lab:
`npm ci --prefix lab --legacy-peer-deps --ignore-scripts`. Then run quality,
mutation, SQL, reference, property, mapping and build commands in their
documented order. Native, real-Zabbix and deployment-path suites were executed
for this candidate on source-built local services through the local runners
(docs/local-services.md, docs/RELEASE_AMENDMENTS.md R14, R16); the Docker
Compose forms remain unexecuted.

To verify the supplied artifacts against the extracted source without services:

```bash
cd source
python3.12 tools/verify_release.py --dist ../dist
python3.12 tools/public_audit.py          # recomputes the evidence bindings
```

This verifier needs the declared Python dependencies, PyYAML included: it
validates the packaged agent guidance through tools/agent_guidance.py. It
establishes unsigned consistency, not a signed attestation.

Two files in this packet are not readable to group and other:
reviews/0.1.0a7/plugin/evidence-a7/mutation-run.json and real-zabbix-run.json.
They are retained exactly as received from that handoff, and they are the
original instances of the writer defect corrected by R20. Every file this
candidate produces is 0644; see verification/handoff-checks.json.

Production deployment remains separately authorized: read docs/INPUTS_REQUIRED.md,
docs/RENAME.md (no in-place Ackline upgrade), SPEC_AMENDMENTS.md A2 and A3,
deployment.md and rollback.md. External writes are disabled and no production
cohort/endpoint is configured. Existing schema-3 `zabalack` installations require
no new SQL migration for a16. Preserve all capture/ledger records and do not
automatically undo or retry source acknowledgements.
