# Changelog — Zab-al-ack 0.1.0a16

## 0.1.0a16 — 2026-09-13

Sixteenth alpha candidate, prepared locally and not published. Base: a15
(`14b8c72f…`). It reproduces and adopts the independent review of a15, which
found no runtime or SQL defect and proposed no product change. Runtime Python
differs from a15 only in `__version__`; SQL, the media artifact and dependency
pins are unchanged, and there is no new migration.

### Verified about the review

- Its 46 checksum entries verify and the a15 packet it retains is byte-identical
  to the delivered one (`cf397f91…`), so it reviewed the release itself.
- Its independent execution matches this project's: reference 855/23/0, 8 SQL
  groups, 15 webhook groups, mutation 12/12 and 20/20, property 46, quality and
  quickstart, with the wheel, normalised sdist and source ZIP rebuilt to the
  supplied bytes. It inspected rather than re-ran the three service records.
- Its Gitleaks 8.24.3 result (zero findings over the source and the history
  through the a15 commit) is retained as the review's evidence;
  `evidence/security-scan.json` stays NOT_RUN for its own environment.

### Added

- `tests/release/test_evidence_modes.py`, the review's ten writer regressions:
  both public writers (`run_mutation_checks._atomic_json`,
  `record_real_zabbix.write_record`) and both private writers (the same one and
  `review_runs.atomic_json`) under a permissive (0o000) and a restrictive
  (0o077) umask, plus replacement of an existing 0600 file and an explicit
  publish through the private-by-default review writer. Against an unmodified
  a14 checkout the four public cases fail on the mode itself and the other six
  fail because a14's writers took no `mode` parameter; all ten pass here.
- Amendment R21 and `verification/archive-modes.json`, the measured stored mode
  of the published records in every delivered handoff.
- An accurate NOT_RUN reason in `docs/gitleaks_reference_manifest.json`. The
  build was attempted here: the pinned commit clones and a Go 1.24.7 toolchain
  is present, but three module hosts are outside this environment's egress
  allowlist and substituting mirrors would stop the binary being the pinned
  upstream build. The old reason ("Go toolchain unavailable") no longer held.

### Corrected

- **R20's history.** "Shipped in every handoff since a7" described the writer,
  not the handoffs. Measured from the archives: a3/a4/a5/a8 0644, a9 0644, a10
  **0600**, a11 0644, a12 **0600**, a13 **0600**, a14 0644, a15 0644. The writer
  was wrong throughout — a fresh a14 run still produced 0600 — but only packets
  assembled with mode-preserving copies carried it to a consumer.
- **The profile mutation records are optional when absent and validated when
  present**, not required. Removing both from a disposable copy produces an
  empty `evidence_binding_findings` list. The rule is unchanged; the description
  of it was wrong.
- **Service runs belong to the candidate that executed them.** Unchanged
  service-path code supports an inference about an earlier candidate; it does
  not convert its NOT_RUN records into executions.
- **The release verifier is not stdlib-only**: `tools/verify_release.py` reaches
  PyYAML through `tools/agent_guidance.py`. The handoff instructions say so.
- **Two owner-only records do remain in the handoff**, in
  `reviews/0.1.0a7/plugin/evidence-a7/`, retained as received and the only two
  of that directory's twenty-one records below 0644. One is a **NOT_RUN**
  real-Zabbix record, which disposes of a15's claim that the second writer
  instance was invisible until a candidate could run the suite: the NOT_RUN
  branch uses the same writer and the mode was already in a shipped artifact.
  `verification/handoff-checks.json` had recorded both accurately in a15; only
  the prose said there were none.
- The `Still owner-only` changelog headings are renamed `Still pending`
  throughout, so the phrase cannot be read as a file mode.

### Executed for this candidate (all bound to this tree)

- Reference 865 passed, 23 skipped, 0 failed; 8 SQL groups; 15 webhook groups;
  quality PASS; mutation PR 12/12 and nightly 20/20; property nightly 46;
  quickstart; documentation capture.
- Native PostgreSQL 18.3 + PgBouncer 1.24.1 **42 passed**; real Zabbix 7.0.10
  through the recorder **6 passed**; deployment-path lab from the installed a16
  wheel **4 passed, 13/13 observations**.
- pip-audit, npm audit, export audit, wheel smoke, SBOM schema, release
  verifier; artifacts reproduced byte-identically across two builds.

### Still pending

- A2 transport remediation; the Docker Compose forms of both labs; hosted
  CI/CodeQL/Gitleaks; attestation issuance; an Alerta Web UI capture; G5's
  effective-role evidence on the approved installed account; licence review;
  external security review; publication inputs; G1–G8.
