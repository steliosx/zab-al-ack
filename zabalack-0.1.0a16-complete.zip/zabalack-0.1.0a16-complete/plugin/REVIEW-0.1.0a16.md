# Review — Zab-al-ack 0.1.0a16 (2026-09-13)

Input: `zabalack-0.1.0a15-reviewed-complete.zip` (SHA-256
`17bd86b70b4931b6c660711431f6f9ccadaa3cf42076b3c75d7c75f38b6236d8`), an
independent review of my a15 candidate. Reviewer environment here: Ubuntu 24.04,
Python 3.12.3, Node 22, source-built PostgreSQL 18.3 + PgBouncer 1.24.1,
source-built Zabbix 7.0.10 (two instances) on PostgreSQL 16 + PHP 8.3; no Docker
daemon with registry access. Output: this candidate, commit `e9dc46d2202f0a60638b5506f75af2da11643357`
on branch `candidate/0.1.0a16`.

## Verdict

The review is correct on every point it raises, and every point is about how the
release was described rather than what it does. It found no runtime or SQL
defect, proposed no product change, and rebuilt the artifacts to the supplied
bytes. Each correction was reproduced here before adoption, two of them turning
up sharper evidence than the review had. Its ten writer regressions are adopted
as a repository test. No runtime Python or SQL change.

## The review, verified

| Check | Result |
|---|---|
| Outer `SHA256SUMS` (46 entries) | All OK |
| Retained `zabalack-0.1.0a15-complete.zip` | `cf397f91…` — byte-identical to my a15 deliverable |
| `REVIEW_MANIFEST.json` | `changes_to_supplied_release: false`, `new_version_created: false`; the bytes agree |
| Its independent execution | Reference 855/23/0, 8 SQL, 15 webhook, mutation 12/12 and 20/20, property 46, quality and quickstart; wheel, normalised sdist and source ZIP rebuilt to the supplied bytes |
| Its Gitleaks 8.24.3 run | Zero findings over source and history through the a15 commit — the review's evidence, retained as received, not restated as mine |
| Its service scope | Inspection of my supplied records, not fresh runs; it says so |
| `proposed/documentation-corrections.patch` | 322 lines, documentation and static copy only; no source, SQL or harness change |

## Each correction, reproduced before adoption

**R20's history.** I wrote that the owner-only mode "shipped in every handoff
since a7". Reading the stored mode out of each delivered archive: a3/a4/a5/a8
0644, a9 0644, a10 **0600**, a11 0644, a12 **0600**, a13 **0600**, a14 0644, a15
0644 (`verification/archive-modes.json`). The writer was wrong throughout — a
fresh a14 run still produced 0600 — but only some handoffs carried it to a
reader. The mechanism is mine: my packaging copies source files with
`shutil.copymode` and publishes whatever mode the writer left, while the other
producer's assembly normalised to 0644. The review said a14's archives were
normalised; the measurement says which packets were and why.

**"Both required by the audit."** Deleting both profile mutation records from a
disposable copy produced an empty `evidence_binding_findings` list. They are
validated when present and optional when absent. The rule is unchanged; only my
description of it was wrong.

**Service-run attribution.** a15's native, real-Zabbix and deployment runs are
a15's. Unchanged service-path code supports an inference about a14; it does not
convert a14's NOT_RUN records into executions. Corrected in R20, the a15
changelog entry, the a15 review copy carried forward and the website.

**"Stdlib verifier."** `tools/verify_release.py` reaches PyYAML through
`tools/agent_guidance.py`. Confirmed by import; `START_HERE.md` now names the
dependency.

**"No owner-only record in the handoff."** There are two, both in
`reviews/0.1.0a7/plugin/evidence-a7/`, retained exactly as received — and they
are the only two of that directory's twenty-one records below 0644, which is the
writer defect drawn in outline. One is a **NOT_RUN** real-Zabbix record at 0600.
That settles a15's other loose claim, that the second writer instance was
"invisible while no candidate could run the suite": the NOT_RUN branch uses the
same writer, the mode had been in a shipped artifact since a7, and nothing had
examined exported modes as a class until R20 added the rule.
`verification/handoff-checks.json` had recorded both files accurately in a15;
only the prose said otherwise.

## Adopted

- `tests/release/test_evidence_modes.py` — the review's ten cases: both public
  writers and both private writers, each under a permissive (0o000) and a
  restrictive (0o077) umask, plus replacement of an existing 0600 file and an
  explicit publish through the private-by-default review writer. Verified to
  discriminate: against an unmodified a14 checkout the four public cases fail on
  the mode itself (0600 observed, 0644 required) and the other six fail because
  a14's writers took no `mode` parameter. All ten pass here.
- Every documentation correction above, plus the `Still owner-only` changelog
  headings renamed `Still pending` throughout so the phrase cannot be read as a
  file mode, and amendment R21 recording the reproduction.

## Executed on the final tree

| Suite | Result |
|---|---|
| Reference | **865 passed / 23 skipped / 0 failed** (836 unit/mock/property/offline + 29 WASM; 888 collected, all selected) |
| Native PostgreSQL 18.3 + PgBouncer 1.24.1 | **42 passed** (`postgres` 24, `delivery_faults` 5, `worker` 4, `alerta` 7, `performance` 2); cleanup exit 0 per phase |
| Real Zabbix 7.0.10 through `tools/record_real_zabbix.py --run` | **6 passed**, including the A4 excluded-action denial, on fresh unacknowledged synthetic problems |
| Deployment-path lab from the installed a16 wheel `151a4cfc…` | **4 passed, 13/13 observations** |
| Quality, SQL, webhook, quickstart, property, mutation, capture | PASS, 8, 15, PASS, 46, 12/12 and 20/20, PASS |
| pip-audit / npm audit / export audit / wheel smoke / SBOM / release verifier | 58 packages 0 advisories / 0 / 0 findings / PASS / CycloneDX 1.6 61 components / PASS |

## Verified from the packaged zip

| Check | Result |
|---|---|
| Outer `SHA256SUMS`, `plugin/RELEASE_SHA256SUMS`, `plugin/dist/SHA256SUMS` | All OK (nested lists included) |
| File modes in this handoff | Readable to group and other, except the two a7 records named above, retained as received; enumerated in `verification/handoff-checks.json` |
| Wheel `zabalack/` vs `src/zabalack/`; vs a15 | Byte-identical to the source; differs from a15 only in `__version__`; identical across two builds and to the deployment-lab runner wheel |
| Bundle restore, `verify_release.py --dist ../dist`, `public_audit.py` from the clone | Tree identical; PASS; PASS with every run record bound to the clone |
| Fresh venv from the clone: quality, fast suites, bare collection | See `verification/handoff-checks.json` |
| Identifier sweep | No tokens, private keys, personal names or e-mail addresses beyond synthetic `.invalid` fixtures, schema examples and placeholder author identities |
| Website | No scripts or forms; 19 pages, 392 local references resolve; copy states a16 results and carries the correction on the a15 post |

## Residual observations (not blockers)

- Gitleaks was attempted here and still cannot run: the pinned commit clones and
  a Go 1.24.7 toolchain is present, but `proxy.golang.org`, `golang.org/x`,
  `gopkg.in` and `dario.cat` are outside this environment's egress allowlist, and
  substituting mirrors would stop the binary being the pinned upstream build.
  `docs/gitleaks_reference_manifest.json` now says that instead of the stale "Go
  toolchain unavailable".
- The quality gate runs `ruff check src`; `tools/` and `tests/` carry four
  pre-existing style findings outside that scope. Unchanged here.
- a14's qualitative agent evaluations remain retained as received. They are
  forward-tests, not benchmarks.
- G5 still requires effective-role read-back and permission tests on the
  approved installed account (A4). A2, the Docker Compose forms, hosted
  workflows, CodeQL, Gitleaks, the signed attestation, an Alerta Web UI capture
  and external security review remain open. No in-place Ackline upgrade exists.
