// Headless-Chromium captures for the a12 documentation:
//   1. the three transcript pages produced by tools/capture_docs.py (file:// navigation);
//   2. the Zabbix 7.0.10 frontend "Event details" page of the deployment lab's acknowledged
//      event on the disposable lab instance (default Admin account, lab data only).
// usage: node browser_capture12.mjs <repo> <outdir> <zabbix-ui-url> <eventid> <triggerid>
import { chromium } from 'playwright';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
const [repo, outdir, zbxUrl, eventid, triggerid] = process.argv.slice(2);
const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium', args: ['--no-sandbox'] });
const version = browser.version();
const record = { tool: 'Playwright headless Chromium ' + version, captured_at_utc: new Date().toISOString(), captures: [] };
const sha = (p) => createHash('sha256').update(readFileSync(p)).digest('hex');
const page = await browser.newPage({ viewport: { width: 1000, height: 700 }, deviceScaleFactor: 1 });
for (const stem of ['01-config', '02-action', '03-ledger']) {
  const src = `${repo}/build/docs/${stem}.html`;
  await page.goto('file://' + src, { waitUntil: 'load' });
  const out = `${outdir}/${stem}-browser.png`;
  await page.screenshot({ path: out, fullPage: true });
  record.captures.push({ file: `${stem}-browser.png`, sha256: sha(out), source: `build/docs/${stem}.html`, source_sha256: sha(src), kind: 'browser render of the transcript page (file://), full page, 1000px wide' });
}
const zpage = await browser.newPage({ viewport: { width: 1600, height: 1000 }, deviceScaleFactor: 1 });
await zpage.goto(zbxUrl + '/index.php', { waitUntil: 'load' });
await zpage.fill('#name', 'Admin'); await zpage.fill('#password', 'zabbix'); await zpage.click('#enter');
await zpage.waitForLoadState('load');
await zpage.goto(`${zbxUrl}/tr_events.php?triggerid=${triggerid}&eventid=${eventid}`, { waitUntil: 'load' });
await zpage.waitForTimeout(1500);
const out = `${outdir}/04-zabbix-event-details.png`;
await zpage.screenshot({ path: out, fullPage: true });
record.captures.push({ file: '04-zabbix-event-details.png', sha256: sha(out), source: 'Zabbix 7.0.10 frontend, tr_events.php (Event details) on the disposable deployment-lab instance, default Admin session', event_id: eventid, trigger_id: triggerid, kind: 'real product UI screenshot of lab data, full page, 1600px wide' });
writeFileSync(`${outdir}/browser-captures.json`, JSON.stringify(record, null, 2) + '\n');
console.log(JSON.stringify(record.captures.map(c => [c.file, c.sha256.slice(0, 12)])));
await browser.close();
